@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1" -Action app
exit /b %ERRORLEVEL%
