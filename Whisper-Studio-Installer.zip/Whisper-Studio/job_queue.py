"""Thread-safe persistent queue. Workers communicate through immutable events."""

from __future__ import annotations

import copy
import json
import logging
import queue
import threading
import uuid
from pathlib import Path
from typing import Callable

from transcribe import (
    TranscriptionCancelled,
    atomic_write_text,
    check_cancelled,
    choose_defaults,
    create_model,
    detect_vram_gb,
    normalize_compute_type,
    normalize_language,
    select_device,
    transcribe_file,
    unload_model,
    validate_model_task,
)

LOGGER = logging.getLogger(__name__)
TERMINAL_STATUSES = {"done", "warning", "failed", "cancelled"}


class JobQueue:
    def __init__(
        self,
        state_path: Path,
        output_dir: Path,
        *,
        model_factory: Callable = create_model,
        transcriber: Callable = transcribe_file,
    ):
        self.state_path = state_path
        self.output_dir = output_dir
        self.model_factory = model_factory
        self.transcriber = transcriber
        self.events: queue.Queue = queue.Queue()
        self.condition = threading.Condition()
        self.jobs: list[dict] = []
        self.active_id: str | None = None
        self.cancel_event = threading.Event()
        self.stopping = False
        self.save_blocked = False
        self.paused = False
        self.cached_signature = None
        self.cached_model = None
        self._load()
        self.thread = threading.Thread(
            target=self._worker, name="whisper-transcription", daemon=True
        )
        self.thread.start()

    def _load(self) -> None:
        if not self.state_path.exists():
            return
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if (
                not isinstance(data, dict)
                or data.get("schema_version") != 1
                or not isinstance(data.get("jobs"), list)
            ):
                raise ValueError("Formato della coda non valido")
            identifiers = set()
            for job in data["jobs"]:
                if not isinstance(job, dict) or not all(
                    key in job for key in ("id", "path", "options", "status")
                ):
                    raise ValueError("Lavoro salvato non valido")
                if (
                    not isinstance(job["id"], str)
                    or not job["id"]
                    or job["id"] in identifiers
                    or not isinstance(job["path"], str)
                    or not isinstance(job["options"], dict)
                    or job["status"]
                    not in TERMINAL_STATUSES | {"queued", "running", "cancelling"}
                ):
                    raise ValueError("Dati o identificatori della coda non validi")
                identifiers.add(job["id"])
                if job["status"] == "running":
                    job["status"] = "queued"
                    job["message"] = "Da riprendere dopo l'interruzione"
                elif job["status"] == "cancelling":
                    job["status"], job["message"] = (
                        "cancelled",
                        "Annullato prima dell'interruzione",
                    )
                self.jobs.append(job)
            self.paused = any(job["status"] == "queued" for job in self.jobs)
        except (OSError, ValueError, TypeError) as exc:
            self.jobs = []
            try:
                backup = self.state_path.with_name(
                    f"queue.corrupt-{uuid.uuid4().hex}.json"
                )
                atomic_write_text(backup, self.state_path.read_text(encoding="utf-8"))
            except OSError:
                LOGGER.exception("Could not back up corrupt queue")
                self.stopping = True
                self.save_blocked = True
            self.events.put(("queue_error", {"message": f"Coda non caricata: {exc}"}))
            LOGGER.exception("Could not restore queue")

    def _save_locked(self) -> None:
        if self.save_blocked:
            return
        try:
            data = {"schema_version": 1, "paused": self.paused, "jobs": self.jobs}
            atomic_write_text(
                self.state_path, json.dumps(data, ensure_ascii=False, indent=2)
            )
        except OSError as exc:
            LOGGER.exception("Could not save queue")
            self.events.put(
                ("queue_error", {"message": f"Impossibile salvare la coda: {exc}"})
            )

    def snapshot(self) -> dict:
        with self.condition:
            return {
                "jobs": copy.deepcopy(self.jobs),
                "active_id": self.active_id,
                "paused": self.paused,
            }

    def enqueue(self, paths: list[Path], options: dict) -> int:
        with self.condition:
            if self.stopping:
                return 0
            pending = {
                Path(job["path"])
                for job in self.jobs
                if job["status"] in {"queued", "running", "cancelling"}
            }
            added = 0
            for raw_path in paths:
                path = raw_path.resolve()
                if path in pending:
                    continue
                self.jobs.append(
                    {
                        "id": uuid.uuid4().hex,
                        "path": str(path),
                        "options": copy.deepcopy(options),
                        "status": "queued",
                        "message": "In attesa",
                    }
                )
                pending.add(path)
                added += 1
            if added:
                self._save_locked()
                self.condition.notify_all()
            return added

    def set_paused(self, paused: bool) -> None:
        with self.condition:
            self.paused = paused
            self._save_locked()
            self.condition.notify_all()

    def cancel(self, job_ids: list[str]) -> None:
        with self.condition:
            for job in self.jobs:
                if job["id"] not in job_ids:
                    continue
                if job["status"] == "queued":
                    job["status"], job["message"] = "cancelled", "Rimosso dalla coda"
                elif job["id"] == self.active_id:
                    job["status"], job["message"] = (
                        "cancelling",
                        "Annullamento alla prossima fase",
                    )
                    self.cancel_event.set()
            self._save_locked()
            self.condition.notify_all()

    def retry(self, job_ids: list[str]) -> None:
        with self.condition:
            pending = {
                job["path"]
                for job in self.jobs
                if job["status"] in {"queued", "running", "cancelling"}
            }
            for job in self.jobs:
                if (
                    job["id"] in job_ids
                    and job["status"] in TERMINAL_STATUSES
                    and job["path"] not in pending
                ):
                    job["status"], job["message"] = "queued", "Nuovo tentativo"
                    job.pop("output_dir", None)
                    pending.add(job["path"])
            self._save_locked()
            self.condition.notify_all()

    def clear_history(self) -> None:
        with self.condition:
            self.jobs = [
                job for job in self.jobs if job["status"] not in TERMINAL_STATUSES
            ]
            self._save_locked()

    def shutdown(self) -> None:
        with self.condition:
            self.stopping = True
            self.cancel_event.set()
            self._save_locked()
            self.condition.notify_all()

    def runtime_config(self, options: dict) -> dict:
        device = select_device(options.get("device", "auto"))
        task = options.get("task", "transcribe")
        language = normalize_language(options.get("language"))
        defaults = choose_defaults(
            options.get("preset", "balanced"),
            detect_vram_gb() if device == "cuda" else None,
            device=device,
            task=task,
        )
        model_name = options.get("model") or defaults["model"]
        validate_model_task(model_name, language, task)
        return {
            **defaults,
            "model": model_name,
            "compute_type": normalize_compute_type(device, options.get("compute_type")),
            "device": device,
            "language": language,
            "task": task,
            "preset": options.get("preset", "balanced"),
        }

    def _get_model(self, config: dict, job_id: str):
        signature = (config["model"], config["device"], config["compute_type"])
        if signature == self.cached_signature:
            self.events.put(
                ("phase", {"id": job_id, "message": "Riutilizzo modello già caricato"})
            )
            return self.cached_model
        self.cached_signature = None
        old_model, self.cached_model = self.cached_model, None
        unload_model(old_model)
        del old_model
        check_cancelled(self.cancel_event)
        self.events.put(
            (
                "phase",
                {
                    "id": job_id,
                    "message": f"Caricamento {config['model']} su {config['device']} (download al primo uso)",
                },
            )
        )
        self.cached_model = self.model_factory(
            config["model"], config["device"], config["compute_type"]
        )
        self.cached_signature = signature
        return self.cached_model

    def _worker(self) -> None:
        try:
            while True:
                with self.condition:
                    self.condition.wait_for(
                        lambda: self.stopping
                        or (
                            not self.paused
                            and any(job["status"] == "queued" for job in self.jobs)
                        )
                    )
                    if self.stopping:
                        return
                    job = next(job for job in self.jobs if job["status"] == "queued")
                    self.cancel_event.clear()
                    job["status"], job["message"] = "running", "Preparazione"
                    self.active_id = job["id"]
                    self._save_locked()
                    job_id = job["id"]
                self.events.put(("job_started", {"id": job_id, "path": job["path"]}))
                try:
                    path = Path(job["path"])
                    if not path.is_file():
                        raise FileNotFoundError(f"File non trovato: {path}")
                    config = self.runtime_config(job["options"])
                    model = self._get_model(config, job_id)
                    check_cancelled(self.cancel_event)
                    self.events.put(("config", {"id": job_id, "config": config}))
                    result = self.transcriber(
                        path,
                        model,
                        preset=config["preset"],
                        model_name=config["model"],
                        device=config["device"],
                        compute_type=config["compute_type"],
                        beam_size=config["beam_size"],
                        batch_size=config["batch_size"],
                        language=config["language"],
                        task=config["task"],
                        output_dir=self.output_dir,
                        formats=["txt", "srt", "json"],
                        no_vad=job["options"].get("no_vad", False),
                        word_timestamps=job["options"].get("word_timestamps", False),
                        initial_prompt=job["options"].get("initial_prompt") or None,
                        cancel_event=self.cancel_event,
                        phase_callback=lambda message: self.events.put(
                            ("phase", {"id": job_id, "message": message})
                        ),
                        progress_callback=lambda percent, current, total: self.events.put(
                            (
                                "progress",
                                {
                                    "id": job_id,
                                    "percent": percent,
                                    "current": current,
                                    "total": total,
                                },
                            )
                        ),
                    )
                    if job["options"].get("audio_review", False):
                        from audio_review import attach_review

                        attach_review(result,
                            lambda name: self._get_model({**config, "model": name}, job_id),
                            device=config["device"],
                            model_name=job["options"].get("review_model") or None,
                            phase_callback=lambda message: self.events.put(
                                ("phase", {"id": job_id, "message": message})),
                            progress_callback=lambda percent, current, total: self.events.put(
                                ("progress", {"id": job_id, "percent": percent, "current": current, "total": total})),
                            cancel_event=self.cancel_event)
                    status = "warning" if result.get("warnings") else "done"
                    message = "; ".join(result.get("warnings", [])) or "Completato"
                    output_dir = str(result["output_base"].parent)
                except TranscriptionCancelled:
                    status, message, output_dir = "cancelled", "Annullato", None
                except Exception as exc:
                    LOGGER.exception("Transcription failed: %s", job["path"])
                    status, message, output_dir = "failed", str(exc), None
                with self.condition:
                    if (
                        self.stopping
                        and status == "cancelled"
                        and job["status"] != "cancelling"
                    ):
                        status, message = "queued", "Da riprendere al prossimo avvio"
                    job["status"], job["message"] = status, message
                    if output_dir:
                        job["output_dir"] = output_dir
                    self.active_id = None
                    self._save_locked()
                    completed = copy.deepcopy(job)
                self.events.put(("job_finished", completed))
        finally:
            unload_model(self.cached_model)
            self.cached_model = None
            self.cached_signature = None
