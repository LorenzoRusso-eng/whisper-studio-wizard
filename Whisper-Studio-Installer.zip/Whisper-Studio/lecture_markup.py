"""Durable labels, placeholders, cross-references and imported figure assets."""
from __future__ import annotations

import base64
import hashlib
import io
import re
from html.parser import HTMLParser
from pathlib import Path

MAX_IMAGE_BYTES = 10 * 1024 * 1024
LABEL = re.compile(r'[A-Za-z][A-Za-z0-9:_-]{0,99}\Z')
IDENTIFIER = re.compile(r'[A-Za-z][A-Za-z0-9_-]{0,119}\Z')
PREFIXES = {'figure':'fig', 'equation':'eq', 'table':'tab', 'other':'item'}
HTML_ATTRIBUTES = {'data-placeholder-kind', 'data-label', 'data-description',
                   'data-source', 'data-action', 'data-reference-target', 'data-reference-kind', 'data-math-display'}
IMAGE_ASSET = re.compile(r'assets/imported/[0-9a-f]{64}\.(?:png|jpg|webp)\Z')


def label_for(value, kind, fallback=''):
    value = str(value or fallback).strip()
    if not value:raise ValueError('Inserisci una label per questo elemento')
    if ':' not in value:value = PREFIXES[kind] + ':' + value
    if not LABEL.fullmatch(value) or value.endswith(':') or not value.startswith(PREFIXES[kind]+':'):
        raise ValueError('Label non valida: usa lettere, numeri, due punti, trattini e underscore, iniziando con una lettera')
    return value


def image_bytes(data_url):
    if not isinstance(data_url, str) or len(data_url) > MAX_IMAGE_BYTES * 4 // 3 + 100:
        raise ValueError('L’immagine supera il limite di 10 MB')
    match = re.fullmatch(r'data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\r\n]+)', data_url)
    if not match:raise ValueError('Scegli un’immagine PNG, JPEG o WebP')
    try:raw = base64.b64decode(match[2].replace('\n','').replace('\r',''), validate=True)
    except ValueError as exc:raise ValueError('Immagine non valida') from exc
    if not 0 < len(raw) <= MAX_IMAGE_BYTES:raise ValueError('L’immagine supera il limite di 10 MB')
    from PIL import Image
    try:
        with Image.open(io.BytesIO(raw)) as picture:
            formats = {'PNG':('png','png'), 'JPEG':('jpg','jpeg'), 'WEBP':('webp','webp')}
            extension, mime = formats[picture.format]
            if picture.width * picture.height > 60_000_000:raise ValueError('Immagine troppo grande')
            picture.verify()
        if match[1] != mime:raise ValueError('Il formato dell’immagine non corrisponde al contenuto')
    except (OSError, KeyError, Image.DecompressionBombError) as exc:
        raise ValueError('Immagine non valida o non supportata') from exc
    asset = f'assets/imported/{hashlib.sha256(raw).hexdigest()}.{extension}'
    return raw, asset


def store_image(folder, data_url):
    raw, asset = image_bytes(data_url)
    target = (Path(folder) / asset).resolve()
    if not target.is_relative_to(Path(folder).resolve()):raise ValueError('Percorso immagine non valido')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if target.read_bytes() != raw:raise ValueError('Un asset con lo stesso nome contiene dati diversi')
    else:
        # Content-addressed names never overwrite another imported image.
        with target.open('xb') as stream:stream.write(raw)
    return asset


def validate_image_asset(folder, asset):
    if not isinstance(asset, str) or not IMAGE_ASSET.fullmatch(asset):raise ValueError('Asset immagine non valido')
    target = (Path(folder) / asset).resolve()
    if not target.is_relative_to(Path(folder).resolve()) or not target.is_file():raise ValueError('Immagine non presente nel progetto')
    if target.stat().st_size>MAX_IMAGE_BYTES:raise ValueError('L’immagine supera il limite di 10 MB')
    raw = target.read_bytes()
    mime = {'png':'png', 'jpg':'jpeg', 'webp':'webp'}[target.suffix[1:]]
    _, expected = image_bytes('data:image/' + mime + ';base64,' + base64.b64encode(raw).decode('ascii'))
    if expected != asset:raise ValueError('L’asset immagine è stato modificato')
    return asset


class Structure(HTMLParser):
    def __init__(self, figures):
        super().__init__(convert_charrefs=True)
        self.figures = {f['id']:f for f in figures}
        self.slots, self.targets, self.references, self.ids = [], [], [], []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('id'):self.ids.append(a['id'])
        if tag == 'figure' and a.get('data-figure-id'):
            identifier = a['data-figure-id'];self.slots.append(identifier)
            f = self.figures.get(identifier)
            if f:self.targets.append({'id':identifier,'kind':'figure',
                'label':label_for(f.get('label'), 'figure', identifier), 'placeholder':False})
        elif 'lecture-placeholder' in a.get('class','').split():
            kind, identifier = a.get('data-placeholder-kind'), a.get('id','')
            if tag != 'div' or kind not in PREFIXES or not IDENTIFIER.fullmatch(identifier):
                raise ValueError('Segnaposto strutturato non valido')
            self.targets.append({'id':identifier,'kind':kind,'label':label_for(a.get('data-label'), kind),
                'placeholder':True,'description':a.get('data-description',''),
                'source':a.get('data-source',''),'action':a.get('data-action','')})
        elif a.get('data-latex') is not None:
            display = a.get('data-math-display', 'inline' if tag == 'span' else 'display')
            if display not in {'inline', 'display'} or tag not in {'span', 'div'}:
                raise ValueError('Formato della formula non valido')
            if a.get('data-label'):
                if not IDENTIFIER.fullmatch(a.get('id','')):raise ValueError('ID della formula non valido')
                self.targets.append({'id':a['id'],'kind':'equation', 'label':label_for(a['data-label'],'equation'),
                    'placeholder':False, 'display_mode':display})
        if tag == 'a' and a.get('data-reference-target'):
            self.references.append({'target':a['data-reference-target']})


def structure(project, *, validate=False):
    parser = Structure(project['figures']);parser.feed(project['document']['html'])
    targets = {item['id']:item for item in parser.targets}
    if validate:
        from collections import Counter
        if Counter(parser.slots) != Counter(f['id'] for f in project['figures']):
            raise ValueError('Una figura è stata rimossa o duplicata dal testo')
        if len(targets) != len(parser.targets) or len({t['label'] for t in parser.targets}) != len(parser.targets):
            raise ValueError('Una label o un identificativo è duplicato nel documento')
        if any(parser.ids.count(t['id']) > (0 if t['kind']=='figure' and not t['placeholder'] else 1) for t in parser.targets):
            raise ValueError('Un identificativo è già usato da un altro elemento')
        if any(ref['target'] not in targets for ref in parser.references):
            raise ValueError('Un riferimento punta a un elemento non più presente')
    for ref in parser.references:
        if ref['target'] in targets:
            ref.update(label=targets[ref['target']]['label'],kind=targets[ref['target']]['kind'])
    return {'figure_order':parser.slots, 'targets':parser.targets, 'references':parser.references}
