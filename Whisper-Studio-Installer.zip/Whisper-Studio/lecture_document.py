"""Validate Codex's structured lecture and publish the editable document."""
from __future__ import annotations

import copy
import hashlib
import html
import json
import re
import shutil
import xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from filelock import FileLock

import review_editor as editor


def object_schema(properties):
    return {"type":"object", "properties":properties, "required":list(properties), "additionalProperties":False}


STR = {"type":"string"}
STRINGS = {"type":"array", "items":STR}
PAGES = {"type":"array", "items":{"type":"integer"}}
SCHEMA = object_schema({
    "title":STR,
    "introduction_html":STR,
    "sections":{"type":"array", "items":object_schema({
        "id":STR, "title":STR, "source_segment_ids":STRINGS,
        "clean_pages":PAGES, "annotated_pages":PAGES, "other_references":STRINGS,
        "html":STR})},
    "slide_supplements":{"type":"array", "items":object_schema({
        "id":STR, "title":STR, "html":STR,
        "references":{"type":"array", "minItems":1, "items":object_schema({
            "role":STR, "pages":{"type":"array", "minItems":1,
                "items":{"type":"integer"}}})}})},
    "figures":{"type":"array", "items":object_schema({
        "id":STR,"title":STR,"source":STR,"caption":STR,"svg":STR})},
    "excluded_segments":{"type":"array", "items":object_schema({"id":STR,"reason":STR})},
    "issues":{"type":"array", "items":object_schema({
        "id":STR,"start":{"type":["number","null"]},"end":{"type":["number","null"]},
        "reason":STR,"status":{"type":"string","enum":["resolved","unresolved"]}})},
    "review_markdown":STR,
})


def safe_svg(source, prefix=None):
    if len(source) > 1_000_000 or re.search(r"<!DOCTYPE|<!ENTITY", source, re.I):
        raise ValueError('Invalid SVG')
    node = ET.fromstring(source)
    if node.tag.split("}")[-1] != "svg":
        raise ValueError('A figure does not contain an SVG')
    allowed={'svg','g','defs','path','rect','line','polyline','polygon','circle','ellipse',
        'text','tspan','textPath','marker','clipPath','mask','pattern','linearGradient',
        'radialGradient','stop','title','desc','symbol','use'}
    for parent in node.iter():
        for child in list(parent):
            if child.tag.split("}")[-1] not in allowed:
                parent.remove(child)
        for key, value in list(parent.attrib.items()):
            name=key.split("}")[-1].lower()
            if name.startswith("on") or (name in {"href","src"} and not value.startswith("#")) or re.search(r"(?:javascript:|url\(\s*[^#])",value,re.I):
                del parent.attrib[key]
    if prefix:
        identifiers={n.attrib['id']:prefix+'-'+n.attrib['id'] for n in node.iter() if 'id' in n.attrib}
        for element in node.iter():
            for key,value in list(element.attrib.items()):
                if key=='id':element.attrib[key]=identifiers[value]
                else:
                    value=re.sub(r'url\(#([^\)]+)\)',lambda m:'url(#'+identifiers.get(m[1],m[1])+')',value)
                    if key.split('}')[-1]=='href' and value.startswith('#'):value='#'+identifiers.get(value[1:],value[1:])
                    element.attrib[key]=value
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    return ET.tostring(node,encoding="unicode")


class Markdown(HTMLParser):
    def __init__(self, figures):
        super().__init__(convert_charrefs=True)
        self.parts=[];self.figures={f['id']:f for f in figures};self.skip=0;self.links=[]
    def handle_starttag(self,tag,attrs):
        attributes=dict(attrs)
        if self.skip:self.skip+=1;return
        if 'lecture-placeholder' in attributes.get('class','').split():
            data={'id':attributes.get('id'),'kind':attributes.get('data-placeholder-kind'),
                'label':attributes.get('data-label'),'description':attributes.get('data-description'),
                'source':attributes.get('data-source'),'action':attributes.get('data-action')}
            self.parts.append('\n\n<!-- PLACEHOLDER '+json.dumps(data,ensure_ascii=False).replace('--','\\u002d\\u002d')+' -->\n\n');self.skip=1;return
        if attributes.get('data-latex') is not None:
            inline = attributes.get('data-math-display') == 'inline' or ('data-math-display' not in attributes and tag == 'span')
            self.parts.append('\\('+attributes['data-latex']+'\\)' if inline else '\n\n\\[\n'+attributes['data-latex']+'\n\\]\n\n')
            self.skip=1;return
        if tag=='figure':
            f=self.figures[attributes['data-figure-id']]
            self.parts.append(f"\n\n<!-- FIGURE:{f['id']} -->\n\n![{f['title']}]({f['asset']})\n\n*{f['caption']}*\n\n")
            self.skip=1;return
        if tag in {'h1','h2','h3','h4'}:self.parts.append('\n\n'+'#'*int(tag[1])+' ')
        elif tag in {'p','div','blockquote','pre','table','ul','ol'}:self.parts.append('\n\n')
        elif tag=='li':self.parts.append('\n- ')
        elif tag in {'strong','b'}:self.parts.append('**')
        elif tag in {'em','i'}:self.parts.append('*')
        elif tag=='br':self.parts.append('  \n')
        elif tag=='code':self.parts.append('`')
        elif tag=='a':self.links.append(attributes.get('href',''));self.parts.append('[')
        elif tag=='tr':self.parts.append('\n| ')
    def handle_endtag(self,tag):
        if self.skip:self.skip-=1;return
        if tag in {'p','div','blockquote','h1','h2','h3','h4','pre','table','ul','ol'}:self.parts.append('\n\n')
        elif tag in {'strong','b'}:self.parts.append('**')
        elif tag in {'em','i'}:self.parts.append('*')
        elif tag=='code':self.parts.append('`')
        elif tag=='a' and self.links:self.parts.append(']('+self.links.pop()+')')
        elif tag in {'td','th'}:self.parts.append(' | ')
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)
    def result(self):return re.sub(r'\n{3,}','\n\n',''.join(self.parts)).strip()+'\n'


def timestamp(value):
    if value is None:return ''
    value=int(value);return f'{value//3600:02d}:{value//60%60:02d}:{value%60:02d}'


def slide_reference(reference, inventory):
    """Resolve a supplement citation from selected inputs, never model filenames."""
    role=reference.get('role','')
    labels={'clean_slides':'clean slides','annotated_slides':'annotated slides','whiteboard':'whiteboard'}
    context=inventory.get(role,{})
    pages=reference.get('pages',[])
    count=context.get('page_count',0);start=context.get('start_page',1)
    if (role not in labels and not re.fullmatch(r'extra-\d+',role)) or not context or not pages:
        raise ValueError('A slide supplement requires a selected PDF source and its page numbers')
    if any(type(page) is not int or not start<=page<=count for page in pages) or len(set(pages))!=len(pages):
        raise ValueError('A slide supplement cites a missing page or a page outside the selected range')
    source=context.get('identity',{}).get('path') or context.get('path') or inventory.get('selected_files',{}).get(role)
    if not source:
        raise ValueError('A slide supplement reference is missing the PDF filename')
    return (Path(source).name+' ('+labels.get(role,'additional PDF')+'), PDF '+
        ('p. ' if len(pages)==1 else 'pp. ')+', '.join(map(str,pages)))


class SupplementContent(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.review_only=False
    def handle_starttag(self,tag,attrs):
        if {'review-only','editorial-note','source-only','source-reference'} & set(dict(attrs).get('class','').split()):
            self.review_only=True


def validate_draft(draft, transcript, inventory):
    if not isinstance(draft,dict) or not draft.get('title') or not isinstance(draft.get('sections'),list) or not draft['sections']:
        raise ValueError('The assistant did not produce a complete organized lesson')
    identifiers={s['id'] for s in transcript['segments']};covered=[];sections=set()
    for section in draft['sections']:
        if not re.fullmatch(r's\d{2,4}',section['id']) or section['id'] in sections or not section['html'].strip():
            raise ValueError('Invalid or duplicate document sections')
        sections.add(section['id']);covered.extend(section['source_segment_ids'])
        for role,key in [('clean_slides','clean_pages'),('annotated_slides','annotated_pages')]:
            count=inventory.get(role,{}).get('page_count',0)
            if any(type(page) is not int or not 1<=page<=count for page in section[key]):
                raise ValueError('A slide citation points to a nonexistent page')
    excluded=draft.get('excluded_segments',[])
    if any(not x.get('reason','').strip() for x in excluded):raise ValueError('An excluded segment has no explanation')
    covered.extend(x['id'] for x in excluded)
    if Counter(covered)!=Counter(identifiers):
        missing=identifiers-set(covered);duplicates=[key for key,n in Counter(covered).items() if n>1]
        raise ValueError(f'Incomplete coverage of the transcript: {len(missing)} missing segments, {len(duplicates)} duplicates')
    # Old saved drafts remain readable; the generation schema requires this array
    # in every new result. Supplements never consume transcript segment IDs.
    supplements=draft.get('slide_supplements',[]);supplement_ids=set()
    if not isinstance(supplements,list):raise ValueError('Slide supplements must be a list')
    for supplement in supplements:
        if (not re.fullmatch(r'sup\d{2,4}',supplement.get('id','')) or supplement['id'] in supplement_ids
                or not supplement.get('title','').strip() or not supplement.get('html','').strip()
                or 'source_segment_ids' in supplement):
            raise ValueError('Invalid slide supplements: unique IDs, a title, and content without audio segments are required')
        supplement_ids.add(supplement['id'])
        if not supplement.get('references'):raise ValueError('A slide supplement has no PDF page references')
        for reference in supplement['references']:slide_reference(reference,inventory)
        parsed=SupplementContent();parsed.feed(editor.clean_html(supplement['html']))
        if parsed.review_only:raise ValueError('Slide supplements are part of the lesson and cannot be review-only')
    figures=set()
    for figure in draft['figures']:
        if not re.fullmatch(r'(?:fig\d{2,4}|user-figure-[A-Za-z0-9_-]{1,100})',figure['id']) or figure['id'] in figures:raise ValueError('Invalid figure identifiers')
        figures.add(figure['id']);figure['svg']=safe_svg(figure['svg'],figure['id'])
    content=editor.clean_html(draft['introduction_html']+'\n'+''.join(s['html'] for s in draft['sections']+supplements))
    slots=re.findall(r'data-figure-id="([\w-]+)"',content)
    if Counter(slots)!=Counter(figures):raise ValueError('Each figure must appear exactly once in the text')
    if re.search(r'\b(?:the lecturer explains|the professor explains|the lecturer states)\b',editor.plain(content),re.I):
        raise ValueError('The draft contains an external narrator; direct exposition is required')
    return draft


def template():
    css=(editor.ASSETS/'document.css').read_text(encoding='utf-8')
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>Whisper Studio · Lecture</title><style>'+css+'</style></head><body>'
        '<header><div class="eyebrow">Whisper Studio</div><h1>Lecture workspace</h1>'
        '<p>English · direct voice · editable lecture</p></header>'
        '<nav aria-label="Document navigation"><a href="lecture.html">Lecture</a>'
        '<a href="review.html">Review and uncertainties</a><button onclick="print()">Print</button></nav>'
        '<main><article class="notes"></article></main></body></html>')


def publish(folder, draft, transcript, inventory, *, expected_hash=None, audio_review=None):
    folder=Path(folder).resolve();folder.mkdir(parents=True,exist_ok=True)
    validate_draft(draft,transcript,inventory)
    project_path=folder/'lecture_project.json'
    with editor.LOCK, FileLock(folder / ".project-save.lock", timeout=10):
        current_raw=project_path.read_bytes() if project_path.exists() else None
        actual_hash=hashlib.sha256(current_raw).hexdigest() if current_raw else None
        if actual_hash!=expected_hash:
            raise FileExistsError('The text changed during processing. The generated draft is preserved in Details; the edited version has not been replaced.')
        current=json.loads(current_raw) if current_raw else None
        if current and (folder/'lecture_notes.md').read_text(encoding='utf-8')!=current['document']['markdown']:
            raise FileExistsError('The Markdown was modified outside the editor: reconcile the changes before updating.')
        figures=[];previous={f['id']:f for f in current['figures']} if current else {}
        if set(previous)-{f['id'] for f in draft['figures']}:
            raise ValueError('The new draft would remove an existing figure: the draft is preserved for review')
        for figure in draft['figures']:
            f={key:figure[key] for key in ('id','title','source','caption')};f['asset']='assets/'+f['id']+'.svg'
            f['notes']=copy.deepcopy(previous.get(f['id'],{}).get('notes',[]))
            if f['id'] in previous:f['caption']=previous[f['id']]['caption']
            for key in ('label','caption_mode','caption_prompt'):
                if key in previous.get(f['id'],{}):f[key]=previous[f['id']][key]
            if previous.get(f['id'],{}).get('kind')=='image':
                f=copy.deepcopy(previous[f['id']])
            figures.append(f)
        by_id={s['id']:s for s in transcript['segments']}
        body='<h1>'+html.escape(draft['title'])+'</h1>'+draft['introduction_html']
        for index,section in enumerate(draft['sections'],1):
            refs=[];segments=[by_id[key] for key in section['source_segment_ids']]
            timed=[s for s in segments if s.get('start') is not None and s.get('end') is not None]
            if timed:refs.append('transcript '+timestamp(min(s['start'] for s in timed))+'–'+timestamp(max(s['end'] for s in timed)))
            elif segments:refs.append('transcript segments '+', '.join(s['id'] for s in segments))
            for label,key in [('clean slides','clean_pages'),('annotated slides','annotated_pages')]:
                if section[key]:refs.append(label+', PDF pp. '+', '.join(map(str,section[key])))
            refs+=section['other_references']
            body+=f'<h2 id="{section["id"]}">{index}. {html.escape(section["title"])}</h2>'
            body+='<p><em>Sources: '+html.escape('; '.join(refs))+'.</em></p>'+section['html']
        if draft['excluded_segments']:
            body+='<p class="review-only"><em>Fragmented or non-substantive source segments are preserved in the review.</em></p>'
        if draft.get('slide_supplements'):
            body+='<div class="lecture-supplements"><h2 id="slide-supplements">'+str(len(draft['sections'])+1)+'. Additional material from the lecture slides</h2>'
            body+='<p class="lecture-supplement-intro">The following material is provided by the cited slides or notes and is not present in the supplied transcript.</p>'
            for supplement in draft['slide_supplements']:
                citations='; '.join(slide_reference(ref,inventory) for ref in supplement['references'])
                body+='<div class="lecture-supplement" id="'+supplement['id']+'"><h3>'+html.escape(supplement['title'])+'</h3>'+supplement['html']
                body+='<p class="slide-citation"><strong>Slide reference:</strong> '+html.escape(citations)+'.</p></div>'
            body+='</div>'
        body=editor.clean_html(body)
        converter=Markdown(figures);converter.feed(body)
        project={'schema_version':1,'project_id':current['project_id'] if current else __import__('uuid').uuid4().hex,
            'lesson':current['lesson'] if current else 'lesson-'+hashlib.sha256(str(folder).encode()).hexdigest()[:12],
            'revision':current['revision']+1 if current else 0,'title':draft['title'],'language':'en','voice':'direct',
            'created_at':current['created_at'] if current else editor.now(),'updated_at':editor.now(),
            'document':{'html':body,'markdown':converter.result()},'figures':figures,'sources':inventory,
            'audio_review_file':'audio_review.json' if audio_review else None}
        if current:
            revision_folder=folder/'revisions'/'editor';revision_folder.mkdir(parents=True,exist_ok=True)
            editor.write_json(revision_folder/f'revision-{current["revision"]:05d}.json',current)
            # Preserve previous diagrams as well as the project and user instructions.
            for f in current['figures']:
                old=folder/f['asset']
                if old.is_file():shutil.copyfile(old,revision_folder/f'revision-{current["revision"]:05d}-{f["id"]}{old.suffix}')
        for figure in draft['figures']:
            if previous.get(figure['id'],{}).get('kind')!='image':editor.atomic_text(folder/'assets'/f'{figure["id"]}.svg',figure['svg'])
        review=draft['review_markdown']+'\n\n## Source segments kept outside the lecture body\n\n'
        for excluded in draft['excluded_segments']:
            segment=by_id[excluded['id']]
            review+=f"- **{excluded['id']}** ({timestamp(segment.get('start'))}): {excluded['reason']}\n\n  {segment['text']}\n\n"
        editor.atomic_text(folder/'review.md',review)
        safe_review='<h1>Review and uncertainties</h1><pre style="white-space:pre-wrap;font:inherit">'+html.escape(review)+'</pre>'
        editor.atomic_text(folder/'review.html',template().replace('<article class="notes"></article>','<article class="notes">'+safe_review+'</article>'))
        editor.atomic_text(folder/'.editor-template.html',template())
        if audio_review:editor.write_json(folder/'audio_review.json',audio_review)
        editor.write_json(project_path,project);editor.publish_handoff(folder,project);editor.render_project(folder,project)
        return project
