#!/bin/sh
exec sh "$(dirname -- "$0")/launch.sh" demo "$@"
