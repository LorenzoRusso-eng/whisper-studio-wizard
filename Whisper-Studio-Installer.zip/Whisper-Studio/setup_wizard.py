'English first-run wizard, shared by Windows, macOS and Linux.'
from __future__ import annotations

import argparse
import json
import os
import platform
import queue
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path

import installer
from studio_runtime import ROOT, PROVIDERS, load_installation, open_path, venv_python, configure_progress_style

STEPS=('Transcription','AI assistant','Summary','Installation','First steps')
EXPLANATION=(
    'The assistant turns transcripts and slides into organized notes, reconstructs figures, '
    'and prepares LaTeX/PDF after your corrections. Whisper handles the audio only.\n\n'
    'The CLI connects the app to your AI account. Once you have signed in, '
    'Whisper Studio uses it automatically. You do not need to type commands during normal use. '
    'You only need one CLI and can switch later.\n\n'
    'Your selected text and materials are processed online by the chosen provider. '
    'Access, limits, and any charges depend on your account. The wizard does not request or store passwords or API keys.'
)


class SetupWizard:
    def __init__(self,root):
        import tkinter as tk
        from tkinter import ttk
        self.tk=tk;self.ttk=ttk;self.root=root;self.step=0;self.running=False
        self.events=queue.Queue();self.cancel=threading.Event();self.worker=None
        previous=load_installation()
        self.mode=tk.StringVar(root,value=previous.get('transcription_mode',''))
        self.provider=tk.StringVar(root,value=previous.get('ai_provider','codex'))
        self.device=tk.StringVar(root,value=previous.get('device','cpu'))
        self.transcript=tk.StringVar(root,value=previous.get('initial_transcript',''))
        self.sample=tk.BooleanVar(root,value=not bool(self.transcript.get()))
        self.status=tk.StringVar(root,value='')
        self.root.title('Whisper Studio · Installation wizard')
        self.root.geometry('980x770');self.root.minsize(830,640)
        style=ttk.Style(root)
        if 'clam' in style.theme_names():style.theme_use('clam')
        style.configure('.',font=('Segoe UI',10),background='#FFFFFF',foreground='#20243A')
        style.configure('TFrame',background='#FFFFFF');style.configure('TLabel',background='#FFFFFF')
        style.configure('TButton',padding=(14,8));style.configure('TCheckbutton',background='#FFFFFF')
        style.configure('TRadiobutton',background='#FFFFFF',padding=6)
        style.configure('Title.TLabel',font=('Segoe UI',23,'bold'))
        style.configure('Sub.TLabel',foreground='#66718A')
        style.configure('Accent.TButton',background='#6554D9',foreground='white')
        self.progress_style=configure_progress_style(style)
        style.map('Accent.TButton',background=[('active','#5544C9')])
        root.configure(bg='#F4F5FA');root.columnconfigure(1,weight=1);root.rowconfigure(0,weight=1)
        side=tk.Frame(root,bg='#24233E',width=210,padx=22,pady=30);side.grid(row=0,column=0,sticky='nsew');side.grid_propagate(False)
        tk.Label(side,text='WHISPER\nSTUDIO',bg='#24233E',fg='white',font=('Segoe UI',19,'bold'),justify='left').pack(anchor='w')
        tk.Label(side,text='INSTALLATION WIZARD',bg='#24233E',fg='#BEB7EE',font=('Segoe UI',8)).pack(anchor='w',pady=(8,36))
        self.step_labels=[]
        for i,name in enumerate(STEPS):
            label=tk.Label(side,text=f'{i+1:02d}   {name}',bg='#24233E',fg='#B6B4C8',font=('Segoe UI',10),anchor='w')
            label.pack(fill='x',pady=12);self.step_labels.append(label)
        tk.Label(side,text='Windows · macOS · Linux\nOne AI assistant is enough.',bg='#24233E',fg='#B6B4C8',font=('Segoe UI',9),justify='left').pack(side='bottom',anchor='w')
        main=ttk.Frame(root,padding=(28,24));main.grid(row=0,column=1,sticky='nsew');main.columnconfigure(0,weight=1);main.rowconfigure(1,weight=1)
        self.heading=ttk.Label(main,style='Title.TLabel',wraplength=650);self.heading.grid(row=0,column=0,sticky='w',pady=(0,16))
        # Scrollable content keeps system font scaling and smaller laptop screens usable.
        self.canvas=tk.Canvas(main,bg='white',highlightthickness=0);self.canvas.grid(row=1,column=0,sticky='nsew')
        scroll=ttk.Scrollbar(main,orient='vertical',command=self.canvas.yview);scroll.grid(row=1,column=1,sticky='ns')
        self.canvas.configure(yscrollcommand=scroll.set)
        self.body=ttk.Frame(self.canvas);self.body_id=self.canvas.create_window((0,0),window=self.body,anchor='nw')
        self.body.bind('<Configure>',lambda _e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.body_id,width=e.width))
        ttk.Label(main,textvariable=self.status,style='Sub.TLabel',wraplength=640).grid(row=2,column=0,sticky='w',pady=(12,8))
        footer=ttk.Frame(main);footer.grid(row=3,column=0,sticky='ew');footer.columnconfigure(1,weight=1)
        self.back=ttk.Button(footer,text='Back',command=self.go_back);self.back.grid(row=0,column=0)
        self.next=ttk.Button(footer,text='Continue →',style='Accent.TButton',command=self.advance);self.next.grid(row=0,column=2)
        self.root.protocol('WM_DELETE_WINDOW',self.close);self.root.after(100,self.poll);self.render()

    def paragraph(self,text,*,title=False):
        widget=self.ttk.Label(self.body,text=text,wraplength=610,justify='left',
                              font=('Segoe UI',12,'bold') if title else ('Segoe UI',10))
        widget.pack(anchor='w',fill='x',pady=(5,12));return widget

    def button(self,label,command):
        widget=self.ttk.Button(self.body,text=label,command=command);widget.pack(anchor='w',pady=5);return widget

    def render(self):
        for widget in self.body.winfo_children():widget.destroy()
        for i,label in enumerate(self.step_labels):label.configure(fg='white' if i==self.step else '#A9E3C4' if i<self.step else '#B6B4C8')
        self.canvas.yview_moveto(0);self.status.set('')
        self.back.configure(state='disabled' if self.step in {0,3,4} else 'normal')
        self.next.configure(state='normal',text='Install →' if self.step==2 else 'Close' if self.step==4 else 'Continue →')
        if self.step==0:self.transcription_page()
        elif self.step==1:self.assistant_page()
        elif self.step==2:self.summary_page()
        elif self.step==3:self.install_page()
        else:self.finish_page()

    def transcription_page(self):
        self.heading.configure(text='Where does your transcript come from?')
        self.paragraph('First, choose how you want to work. You can change this setting in the app later.')
        self.ttk.Radiobutton(self.body,text='Local Whisper · start with audio or video',variable=self.mode,value='whisper').pack(anchor='w',pady=(5,0))
        self.paragraph('Speech recognition runs on your computer. A second Whisper pass automatically checks suspicious intervals. Models are downloaded on first use; processing time and memory requirements depend on the model.')
        row=self.ttk.Frame(self.body);row.pack(fill='x',pady=(0,12))
        self.ttk.Label(row,text='Device:').pack(side='left',padx=(0,12))
        values=('cpu',) if sys.platform=='darwin' else ('cpu','auto','cuda')
        self.ttk.Combobox(row,textvariable=self.device,values=values,state='readonly',width=12).pack(side='left')
        self.paragraph('CPU mode works on all three systems. On Mac, faster-whisper uses the CPU, including on Apple Silicon. CUDA requires a compatible NVIDIA GPU and driver; GPU libraries are installed only when you choose cuda.')
        self.ttk.Separator(self.body).pack(fill='x',pady=8)
        self.ttk.Radiobutton(self.body,text='External service · I already have a transcript',variable=self.mode,value='external').pack(anchor='w',pady=(5,0))
        self.paragraph('Provide a TXT, Markdown, SRT, or JSON transcript with segments[].text. Whisper and the second audio check are skipped. The app imports the file you exported from your external service.')
        self.ttk.Checkbutton(self.body,text='Use the included sample transcript for your first session',variable=self.sample).pack(anchor='w',pady=(0,5))
        file_row=self.ttk.Frame(self.body);file_row.pack(fill='x')
        self.ttk.Entry(file_row,textvariable=self.transcript).pack(side='left',fill='x',expand=True,padx=(0,8))
        self.ttk.Button(file_row,text='Choose file…',command=self.choose_transcript).pack(side='left')

    def choose_transcript(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.root,title='Existing transcript',filetypes=[('Transcripts','*.txt *.md *.srt *.json')])
        if path:self.transcript.set(path);self.sample.set(False);self.mode.set('external')

    def assistant_page(self):
        self.heading.configure(text='Choose your AI assistant')
        self.paragraph(EXPLANATION)
        notes={'codex':'Sign in with a compatible Codex / ChatGPT account or other credentials supported by the CLI.',
               'claude':'The product is called Claude Code and its command is claude. It requires an account or credentials with Claude Code access.',
               'gemini':'Gemini CLI supports automated requests and JSON responses. Complete your first Google sign-in in its interactive window.'}
        for key,info in PROVIDERS.items():
            self.ttk.Radiobutton(self.body,text=info['name'],variable=self.provider,value=key).pack(anchor='w',pady=(10,0))
            self.paragraph(notes[key])
        self.button('Documentation for the selected assistant ↗',lambda:webbrowser.open(PROVIDERS[self.provider.get()]['docs']))

    def configuration(self):
        transcript=str(ROOT/'examples/first-lesson/transcript.txt') if self.sample.get() else self.transcript.get().strip()
        return {'transcription_mode':self.mode.get(),'ai_provider':self.provider.get(),
                'device':self.device.get() if self.mode.get()=='whisper' else 'cpu',
                'initial_transcript':transcript if self.mode.get()=='external' else ''}

    def summary_page(self):
        config=self.configuration();self.heading.configure(text='Ready to get started')
        self.paragraph(platform.system()+' · '+platform.machine()+' · Python '+platform.python_version(),title=True)
        self.paragraph('Installation folder: '+str(ROOT))
        source='Local Whisper + second audio pass' if config['transcription_mode']=='whisper' else 'External transcript · both audio passes skipped'
        self.paragraph('1. '+source+'\n2. '+PROVIDERS[config['ai_provider']]['name']+'\n3. HTML editor, formulas, figures, and PDF support\n4. Guided demo with the included sample file')
        self.paragraph('The Python environment is created in .venv. A missing assistant is installed in .tools. If needed, Node.js LTS is downloaded from its official website and its checksum is verified. Downloads require Internet access. Speech recognition needs more disk space than importing text alone.')
        self.paragraph('Would you also like a final PDF?',title=True)
        self.paragraph('The app can prepare LaTeX sources and a ZIP archive. Compiling a PDF also requires a TeX distribution; converting SVG figures requires Chrome, Chromium, or Edge. Checks and installation commands are available at the end. TeX may require several GB of disk space.')
        self.paragraph('Installation may take a few minutes. You can cancel and try again; settings are saved only after verification succeeds.')

    def install_page(self):
        self.heading.configure(text='Setting up your Studio')
        self.progress=self.ttk.Progressbar(self.body,maximum=6,style=self.progress_style);self.progress.pack(fill='x',pady=(12,16))
        self.log_widget=self.tk.Text(self.body,height=23,wrap='word',font=('Consolas',9),bg='#F4F5FA',fg='#30354B',relief='flat')
        self.log_widget.pack(fill='both',expand=True);self.log_widget.configure(state='disabled')
        self.next.configure(text='Cancel',command=self.cancel_install)
        self.running=True;self.cancel.clear()
        config=self.configuration()
        def work():
            log_file=ROOT/'.logs/install.log';log_file.parent.mkdir(exist_ok=True)
            with log_file.open('a',encoding='utf-8') as log:
                def output(message):
                    log.write(message+'\n');log.flush();self.events.put(('log',message))
                try:
                    installer.install(config,output,lambda n,m:self.events.put(('progress',(n,m))),self.cancel)
                    self.events.put(('installed',config))
                except Exception as exc:self.events.put(('error',str(exc)))
        self.worker=threading.Thread(target=work,daemon=True);self.worker.start()

    def cancel_install(self):
        self.cancel.set();self.next.configure(state='disabled');self.status.set('Canceling…')

    def finish_page(self):
        self.heading.configure(text='Welcome to Whisper Studio')
        self.paragraph('The app is installed and the local demo is ready. Sign in to your selected assistant to process your own materials.',title=True)
        self.button('1. Sign in to '+PROVIDERS[self.provider.get()]['name'],lambda:self.guarded(lambda:installer.login(self.provider.get())))
        self.button('Check CLI and sign-in',self.verify_cli)
        self.paragraph('For Gemini, this check verifies that the CLI starts. Authentication and quota are confirmed by the first live job. The local demo does not consume your AI allowance.')
        self.button('2. Try the guided demo',lambda:self.launch('studio_demo.py'))
        self.button('3. Open Whisper Studio',lambda:self.launch('studio.py'))
        self.ttk.Separator(self.body).pack(fill='x',pady=14)
        self.paragraph('LaTeX and PDF · additional tools',title=True)
        self.button('Check TeX and browser',self.check_pdf)
        command=installer.pdf_install_command()
        if command:
            self.paragraph('Available command: '+subprocess.list2cmdline(command))
            self.button('Install a TeX distribution…',lambda:self.guarded(lambda:installer.terminal_command(command)))
        else:self.button('Download TeX from the official guide ↗',lambda:webbrowser.open('https://www.tug.org/texlive/'))
        self.button('Download Chrome if needed ↗',lambda:webbrowser.open('https://www.google.com/chrome/'))
        self.paragraph('Reopen the app after installing TeX. To share the system, use the distribution ZIP: each person sets up their own account and environment.')
        self.next.configure(command=self.close)

    def check_pdf(self):
        from tkinter import messagebox
        tex=shutil_which_tex()
        try:
            from latex_assets import browser_executable
            browser=browser_executable()
        except (ImportError,FileNotFoundError):browser=None
        messagebox.showinfo('PDF tools','TeX: '+(tex or 'install it / reopen the app')+'\nSVG browser: '+(browser or 'Chrome/Chromium/Edge needs to be installed'),parent=self.root)

    def launch(self,script):
        python=venv_python(windowless=True)
        subprocess.Popen([str(python),str(ROOT/script)],cwd=ROOT,**installer.hidden_process_options())

    def guarded(self,action):
        from tkinter import messagebox
        try:action()
        except Exception as exc:messagebox.showerror('Whisper Studio',str(exc),parent=self.root)

    def verify_cli(self):
        provider=self.provider.get();self.status.set('Checking…')
        def work():
            import ai_providers
            try:
                ai_providers.check_provider(provider)
                self.events.put(('status','CLI available. '+('Your Gemini account will be checked during the first live job.' if provider=='gemini' else 'Sign-in confirmed.')))
            except Exception as exc:self.events.put(('status',str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def advance(self):
        from tkinter import messagebox
        if self.step==0:
            if self.mode.get() not in {'whisper','external'}:
                self.status.set('Select local Whisper or an external transcript.');return
            if self.mode.get()=='external':
                try:installer.validate_transcript_file(self.configuration()['initial_transcript'])
                except (OSError,ValueError) as exc:self.status.set(str(exc));return
        self.step+=1;self.render()

    def go_back(self):
        if self.step in {1,2}:self.step-=1;self.render()

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='log' and hasattr(self,'log_widget'):
                    self.log_widget.configure(state='normal');self.log_widget.insert('end',value+'\n');self.log_widget.see('end');self.log_widget.configure(state='disabled')
                elif kind=='progress':self.progress.configure(value=value[0]);self.status.set(value[1])
                elif kind=='installed':self.running=False;self.step=4;self.next.configure(command=self.advance);self.render()
                elif kind=='error':
                    self.running=False;self.status.set(value);self.next.configure(text='Retry',state='normal',command=self.retry)
                    self.back.configure(state='normal',command=self.retry_choices)
                elif kind=='status':self.status.set(value)
        except queue.Empty:pass
        self.root.after(100,self.poll)

    def retry(self):
        self.next.configure(command=self.advance);self.render()

    def retry_choices(self):
        self.back.configure(command=self.go_back);self.next.configure(command=self.advance);self.step=0;self.render()

    def close(self):
        if self.running:self.cancel_install();return
        self.root.destroy()


def shutil_which_tex():
    import shutil
    for command in ('pdflatex','latexmk'):
        found=shutil.which(command)
        if found:return found
    if sys.platform=='darwin' and Path('/Library/TeX/texbin/pdflatex').is_file():return '/Library/TeX/texbin/pdflatex'
    return None


def console_wizard():
    print('Whisper Studio · installation wizard\n1) Local Whisper\n2) External transcript (skips both audio passes)')
    mode={'1':'whisper','2':'external'}.get(input('Choose [1/2]: ').strip())
    if not mode:raise ValueError('Invalid choice')
    source=''
    if mode=='external':
        source=input('TXT/MD/SRT/JSON transcript (Enter = included sample): ').strip().strip('"') or str(ROOT/'examples/first-lesson/transcript.txt')
        source=installer.validate_transcript_file(source)
    print(EXPLANATION)
    provider=input('Assistant [codex/claude/gemini, default codex]: ').strip() or 'codex'
    if provider not in PROVIDERS:raise ValueError('Invalid assistant')
    config={'transcription_mode':mode,'ai_provider':provider,'device':'cpu','initial_transcript':source}
    print(json.dumps(config,ensure_ascii=False,indent=2))
    if input('Install in this folder? [y/N]: ').strip().lower()!='y':return 0
    installer.install(config,print,lambda n,m:print(f'[{n}/6] {m}'),threading.Event())
    print('Installation verified. To sign in: '+provider+' '+' '.join(PROVIDERS[provider]['login']))
    print('Start the demo with the Demo launcher for your operating system. On Linux, the app requires a graphical session.')
    return 0


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--console',action='store_true',help='Terminal wizard')
    args=parser.parse_args(argv);installer.check_python()
    if args.console:return console_wizard()
    try:
        import tkinter as tk
        root=tk.Tk()
    except Exception as exc:
        print('Tkinter is unavailable. On Debian/Ubuntu, install python3-tk and python3-venv. On Mac, use Python from python.org or python-tk for the same Python version.',file=sys.stderr)
        return console_wizard()
    SetupWizard(root);root.mainloop();return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print(str(exc),file=sys.stderr);raise SystemExit(1)
