"""Italian first-run wizard, shared by Windows, macOS and Linux."""
from __future__ import annotations

import argparse
import json
import os
import platform
import queue
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path

import installer
from studio_runtime import ROOT, PROVIDERS, load_installation, open_path, venv_python, configure_progress_style

STEPS=('Trascrizione','Assistente AI','Riepilogo','Installazione','Primo utilizzo')
EXPLANATION=(
    'L’assistente trasforma la trascrizione e le slide in appunti ordinati, ricostruisce le figure '
    'e prepara LaTeX/PDF dopo le tue correzioni. Whisper si occupa soltanto dell’audio.\n\n'
    'La CLI è il collegamento tra l’app e il tuo account AI: una volta effettuato l’accesso, '
    'Whisper Studio la usa automaticamente. Non devi scrivere comandi durante l’uso normale. '
    'Ne basta una; puoi cambiarla in seguito.\n\n'
    'Testo e materiali selezionati vengono elaborati dal fornitore scelto via Internet. '
    'Accesso, limiti ed eventuali costi dipendono dal tuo account. Il wizard non richiede né salva password o chiavi API.'
)


class SetupWizard:
    def __init__(self,root):
        import tkinter as tk
        from tkinter import ttk
        self.tk=tk;self.ttk=ttk;self.root=root;self.step=0;self.running=False
        self.events=queue.Queue();self.cancel=threading.Event();self.worker=None
        previous=load_installation()
        self.mode=tk.StringVar(root,value=previous.get('transcription_mode',''))
        self.provider=tk.StringVar(root,value=previous.get('ai_provider','codex'))
        self.device=tk.StringVar(root,value=previous.get('device','cpu'))
        self.transcript=tk.StringVar(root,value=previous.get('initial_transcript',''))
        self.sample=tk.BooleanVar(root,value=not bool(self.transcript.get()))
        self.status=tk.StringVar(root,value='')
        self.root.title('Whisper Studio · Installazione guidata')
        self.root.geometry('980x770');self.root.minsize(830,640)
        style=ttk.Style(root)
        if 'clam' in style.theme_names():style.theme_use('clam')
        style.configure('.',font=('Segoe UI',10),background='#FFFFFF',foreground='#20243A')
        style.configure('TFrame',background='#FFFFFF');style.configure('TLabel',background='#FFFFFF')
        style.configure('TButton',padding=(14,8));style.configure('TCheckbutton',background='#FFFFFF')
        style.configure('TRadiobutton',background='#FFFFFF',padding=6)
        style.configure('Title.TLabel',font=('Segoe UI',23,'bold'))
        style.configure('Sub.TLabel',foreground='#66718A')
        style.configure('Accent.TButton',background='#6554D9',foreground='white')
        self.progress_style=configure_progress_style(style)
        style.map('Accent.TButton',background=[('active','#5544C9')])
        root.configure(bg='#F4F5FA');root.columnconfigure(1,weight=1);root.rowconfigure(0,weight=1)
        side=tk.Frame(root,bg='#24233E',width=210,padx=22,pady=30);side.grid(row=0,column=0,sticky='nsew');side.grid_propagate(False)
        tk.Label(side,text='WHISPER\nSTUDIO',bg='#24233E',fg='white',font=('Segoe UI',19,'bold'),justify='left').pack(anchor='w')
        tk.Label(side,text='INSTALLAZIONE GUIDATA',bg='#24233E',fg='#BEB7EE',font=('Segoe UI',8)).pack(anchor='w',pady=(8,36))
        self.step_labels=[]
        for i,name in enumerate(STEPS):
            label=tk.Label(side,text=f'{i+1:02d}   {name}',bg='#24233E',fg='#B6B4C8',font=('Segoe UI',10),anchor='w')
            label.pack(fill='x',pady=12);self.step_labels.append(label)
        tk.Label(side,text='Windows · macOS · Linux\nUn solo assistente AI basta.',bg='#24233E',fg='#B6B4C8',font=('Segoe UI',9),justify='left').pack(side='bottom',anchor='w')
        main=ttk.Frame(root,padding=(28,24));main.grid(row=0,column=1,sticky='nsew');main.columnconfigure(0,weight=1);main.rowconfigure(1,weight=1)
        self.heading=ttk.Label(main,style='Title.TLabel',wraplength=650);self.heading.grid(row=0,column=0,sticky='w',pady=(0,16))
        # Scrollable content keeps system font scaling and smaller laptop screens usable.
        self.canvas=tk.Canvas(main,bg='white',highlightthickness=0);self.canvas.grid(row=1,column=0,sticky='nsew')
        scroll=ttk.Scrollbar(main,orient='vertical',command=self.canvas.yview);scroll.grid(row=1,column=1,sticky='ns')
        self.canvas.configure(yscrollcommand=scroll.set)
        self.body=ttk.Frame(self.canvas);self.body_id=self.canvas.create_window((0,0),window=self.body,anchor='nw')
        self.body.bind('<Configure>',lambda _e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.body_id,width=e.width))
        ttk.Label(main,textvariable=self.status,style='Sub.TLabel',wraplength=640).grid(row=2,column=0,sticky='w',pady=(12,8))
        footer=ttk.Frame(main);footer.grid(row=3,column=0,sticky='ew');footer.columnconfigure(1,weight=1)
        self.back=ttk.Button(footer,text='Indietro',command=self.go_back);self.back.grid(row=0,column=0)
        self.next=ttk.Button(footer,text='Continua →',style='Accent.TButton',command=self.advance);self.next.grid(row=0,column=2)
        self.root.protocol('WM_DELETE_WINDOW',self.close);self.root.after(100,self.poll);self.render()

    def paragraph(self,text,*,title=False):
        widget=self.ttk.Label(self.body,text=text,wraplength=610,justify='left',
                              font=('Segoe UI',12,'bold') if title else ('Segoe UI',10))
        widget.pack(anchor='w',fill='x',pady=(5,12));return widget

    def button(self,label,command):
        widget=self.ttk.Button(self.body,text=label,command=command);widget.pack(anchor='w',pady=5);return widget

    def render(self):
        for widget in self.body.winfo_children():widget.destroy()
        for i,label in enumerate(self.step_labels):label.configure(fg='white' if i==self.step else '#A9E3C4' if i<self.step else '#B6B4C8')
        self.canvas.yview_moveto(0);self.status.set('')
        self.back.configure(state='disabled' if self.step in {0,3,4} else 'normal')
        self.next.configure(state='normal',text='Installa →' if self.step==2 else 'Chiudi' if self.step==4 else 'Continua →')
        if self.step==0:self.transcription_page()
        elif self.step==1:self.assistant_page()
        elif self.step==2:self.summary_page()
        elif self.step==3:self.install_page()
        else:self.finish_page()

    def transcription_page(self):
        self.heading.configure(text='Da dove arriva la trascrizione?')
        self.paragraph('Scegli prima come vuoi lavorare. Potrai cambiare questa scelta anche nell’app.')
        self.ttk.Radiobutton(self.body,text='Whisper locale · parto da un audio o video',variable=self.mode,value='whisper').pack(anchor='w',pady=(5,0))
        self.paragraph('La voce viene riconosciuta sul tuo computer. Il secondo passaggio riascolta automaticamente gli intervalli sospetti con Whisper. I modelli si scaricano al primo utilizzo; tempi e memoria dipendono dal modello.')
        row=self.ttk.Frame(self.body);row.pack(fill='x',pady=(0,12))
        self.ttk.Label(row,text='Dispositivo:').pack(side='left',padx=(0,12))
        values=('cpu',) if sys.platform=='darwin' else ('cpu','auto','cuda')
        self.ttk.Combobox(row,textvariable=self.device,values=values,state='readonly',width=12).pack(side='left')
        self.paragraph('CPU funziona su tutti e tre i sistemi. Su Mac faster-whisper usa la CPU, anche sui chip Apple. CUDA richiede una GPU NVIDIA compatibile e il relativo driver; le librerie GPU vengono installate solo scegliendo cuda.')
        self.ttk.Separator(self.body).pack(fill='x',pady=8)
        self.ttk.Radiobutton(self.body,text='Servizio esterno · ho già il testo trascritto',variable=self.mode,value='external').pack(anchor='w',pady=(5,0))
        self.paragraph('Fornisci una trascrizione TXT, Markdown, SRT o JSON con segments[].text. Whisper e il secondo controllo audio vengono saltati. Il programma non contatta il servizio esterno: importa il file che hai esportato.')
        self.ttk.Checkbutton(self.body,text='Per il primo utilizzo usa la trascrizione di esempio inclusa',variable=self.sample).pack(anchor='w',pady=(0,5))
        file_row=self.ttk.Frame(self.body);file_row.pack(fill='x')
        self.ttk.Entry(file_row,textvariable=self.transcript).pack(side='left',fill='x',expand=True,padx=(0,8))
        self.ttk.Button(file_row,text='Scegli file…',command=self.choose_transcript).pack(side='left')

    def choose_transcript(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.root,title='Trascrizione già pronta',filetypes=[('Trascrizioni','*.txt *.md *.srt *.json')])
        if path:self.transcript.set(path);self.sample.set(False);self.mode.set('external')

    def assistant_page(self):
        self.heading.configure(text='Scegli il tuo assistente AI')
        self.paragraph(EXPLANATION)
        notes={'codex':'Accesso con Codex / account ChatGPT compatibile oppure le credenziali supportate dalla CLI.',
               'claude':'Si chiama Claude Code; il comando è claude. Richiede un account o credenziali abilitati a Claude Code.',
               'gemini':'Sì, Gemini CLI è utilizzabile: supporta richieste automatiche e risposte JSON. Completa il primo accesso Google nella sua finestra interattiva.'}
        for key,info in PROVIDERS.items():
            self.ttk.Radiobutton(self.body,text=info['name'],variable=self.provider,value=key).pack(anchor='w',pady=(10,0))
            self.paragraph(notes[key])
        self.button('Documentazione dell’assistente selezionato ↗',lambda:webbrowser.open(PROVIDERS[self.provider.get()]['docs']))

    def configuration(self):
        transcript=str(ROOT/'examples/first-lesson/transcript.txt') if self.sample.get() else self.transcript.get().strip()
        return {'transcription_mode':self.mode.get(),'ai_provider':self.provider.get(),
                'device':self.device.get() if self.mode.get()=='whisper' else 'cpu',
                'initial_transcript':transcript if self.mode.get()=='external' else ''}

    def summary_page(self):
        config=self.configuration();self.heading.configure(text='Tutto pronto per iniziare')
        self.paragraph(platform.system()+' · '+platform.machine()+' · Python '+platform.python_version(),title=True)
        self.paragraph('Cartella di installazione: '+str(ROOT))
        source='Whisper locale + secondo passaggio audio' if config['transcription_mode']=='whisper' else 'Trascrizione esterna · entrambi i passaggi audio saltati'
        self.paragraph('1. '+source+'\n2. '+PROVIDERS[config['ai_provider']]['name']+'\n3. Editor HTML, formule, figure e lettura PDF\n4. Demo guidata con il file incluso')
        self.paragraph('L’ambiente Python viene creato in .venv. Se l’assistente manca, viene installato in .tools; se necessario scarico Node.js LTS dal sito ufficiale e ne verifico il checksum. I download richiedono Internet. Il riconoscimento vocale richiede più spazio rispetto alla sola importazione di testo.')
        self.paragraph('Vuoi anche il PDF finale?',title=True)
        self.paragraph('I sorgenti LaTeX e lo ZIP si possono preparare dall’app. Per compilare il PDF serve anche una distribuzione TeX; per convertire le figure SVG serve Chrome/Chromium/Edge. Al termine troverai i controlli e i comandi di installazione. TeX può occupare diversi GB.')
        self.paragraph('L’installazione può richiedere alcuni minuti. Puoi annullarla e riprovare; la configurazione viene salvata solo dopo le verifiche.')

    def install_page(self):
        self.heading.configure(text='Prepariamo il tuo Studio')
        self.progress=self.ttk.Progressbar(self.body,maximum=6,style=self.progress_style);self.progress.pack(fill='x',pady=(12,16))
        self.log_widget=self.tk.Text(self.body,height=23,wrap='word',font=('Consolas',9),bg='#F4F5FA',fg='#30354B',relief='flat')
        self.log_widget.pack(fill='both',expand=True);self.log_widget.configure(state='disabled')
        self.next.configure(text='Annulla',command=self.cancel_install)
        self.running=True;self.cancel.clear()
        config=self.configuration()
        def work():
            log_file=ROOT/'.logs/install.log';log_file.parent.mkdir(exist_ok=True)
            with log_file.open('a',encoding='utf-8') as log:
                def output(message):
                    log.write(message+'\n');log.flush();self.events.put(('log',message))
                try:
                    installer.install(config,output,lambda n,m:self.events.put(('progress',(n,m))),self.cancel)
                    self.events.put(('installed',config))
                except Exception as exc:self.events.put(('error',str(exc)))
        self.worker=threading.Thread(target=work,daemon=True);self.worker.start()

    def cancel_install(self):
        self.cancel.set();self.next.configure(state='disabled');self.status.set('Annullamento in corso…')

    def finish_page(self):
        self.heading.configure(text='Benvenuto in Whisper Studio')
        self.paragraph('Programma installato. La demo locale è già disponibile; per elaborare i tuoi materiali completa l’accesso all’assistente scelto.',title=True)
        self.button('1. Accedi a '+PROVIDERS[self.provider.get()]['name'],lambda:self.guarded(lambda:installer.login(self.provider.get())))
        self.button('Verifica CLI e accesso',self.verify_cli)
        self.paragraph('Per Gemini la verifica controlla l’avvio della CLI; l’autenticazione e la quota vengono confermate dalla prima elaborazione reale. La sola demo locale non consuma la quota AI.')
        self.button('2. Prova la demo guidata',lambda:self.launch('studio_demo.py'))
        self.button('3. Apri Whisper Studio',lambda:self.launch('studio.py'))
        self.ttk.Separator(self.body).pack(fill='x',pady=14)
        self.paragraph('LaTeX e PDF · strumenti aggiuntivi',title=True)
        self.button('Controlla TeX e browser',self.check_pdf)
        command=installer.pdf_install_command()
        if command:
            self.paragraph('Comando disponibile: '+subprocess.list2cmdline(command))
            self.button('Installa la distribuzione TeX…',lambda:self.guarded(lambda:installer.terminal_command(command)))
        else:self.button('Scarica TeX dalla guida ufficiale ↗',lambda:webbrowser.open('https://www.tug.org/texlive/'))
        self.button('Scarica Chrome, se manca ↗',lambda:webbrowser.open('https://www.google.com/chrome/'))
        self.paragraph('Dopo aver installato TeX, riapri l’app. Per condividere il sistema usa lo ZIP di distribuzione: ognuno configura il proprio account e il proprio ambiente.')
        self.next.configure(command=self.close)

    def check_pdf(self):
        from tkinter import messagebox
        tex=shutil_which_tex()
        try:
            from latex_assets import browser_executable
            browser=browser_executable()
        except (ImportError,FileNotFoundError):browser=None
        messagebox.showinfo('Strumenti PDF','TeX: '+(tex or 'da installare / riaprire il programma')+'\nBrowser per SVG: '+(browser or 'Chrome/Chromium/Edge da installare'),parent=self.root)

    def launch(self,script):
        python=venv_python(windowless=True)
        subprocess.Popen([str(python),str(ROOT/script)],cwd=ROOT,**installer.hidden_process_options())

    def guarded(self,action):
        from tkinter import messagebox
        try:action()
        except Exception as exc:messagebox.showerror('Whisper Studio',str(exc),parent=self.root)

    def verify_cli(self):
        provider=self.provider.get();self.status.set('Verifica in corso…')
        def work():
            import ai_providers
            try:
                ai_providers.check_provider(provider)
                self.events.put(('status','CLI disponibile. '+('L’account Gemini sarà verificato al primo lavoro reale.' if provider=='gemini' else 'Accesso confermato.')))
            except Exception as exc:self.events.put(('status',str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def advance(self):
        from tkinter import messagebox
        if self.step==0:
            if self.mode.get() not in {'whisper','external'}:
                self.status.set('Seleziona Whisper locale oppure una trascrizione esterna.');return
            if self.mode.get()=='external':
                try:installer.validate_transcript_file(self.configuration()['initial_transcript'])
                except (OSError,ValueError) as exc:self.status.set(str(exc));return
        self.step+=1;self.render()

    def go_back(self):
        if self.step in {1,2}:self.step-=1;self.render()

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='log' and hasattr(self,'log_widget'):
                    self.log_widget.configure(state='normal');self.log_widget.insert('end',value+'\n');self.log_widget.see('end');self.log_widget.configure(state='disabled')
                elif kind=='progress':self.progress.configure(value=value[0]);self.status.set(value[1])
                elif kind=='installed':self.running=False;self.step=4;self.next.configure(command=self.advance);self.render()
                elif kind=='error':
                    self.running=False;self.status.set(value);self.next.configure(text='Riprova',state='normal',command=self.retry)
                    self.back.configure(state='normal',command=self.retry_choices)
                elif kind=='status':self.status.set(value)
        except queue.Empty:pass
        self.root.after(100,self.poll)

    def retry(self):
        self.next.configure(command=self.advance);self.render()

    def retry_choices(self):
        self.back.configure(command=self.go_back);self.next.configure(command=self.advance);self.step=0;self.render()

    def close(self):
        if self.running:self.cancel_install();return
        self.root.destroy()


def shutil_which_tex():
    import shutil
    for command in ('pdflatex','latexmk'):
        found=shutil.which(command)
        if found:return found
    if sys.platform=='darwin' and Path('/Library/TeX/texbin/pdflatex').is_file():return '/Library/TeX/texbin/pdflatex'
    return None


def console_wizard():
    print('Whisper Studio · installazione guidata\n1) Whisper locale\n2) Trascrizione esterna (salta entrambi i passaggi audio)')
    mode={'1':'whisper','2':'external'}.get(input('Scegli [1/2]: ').strip())
    if not mode:raise ValueError('Scelta non valida')
    source=''
    if mode=='external':
        source=input('Trascrizione TXT/MD/SRT/JSON (Invio = esempio incluso): ').strip().strip('"') or str(ROOT/'examples/first-lesson/transcript.txt')
        source=installer.validate_transcript_file(source)
    print(EXPLANATION)
    provider=input('Assistente [codex/claude/gemini, predefinito codex]: ').strip() or 'codex'
    if provider not in PROVIDERS:raise ValueError('Assistente non valido')
    config={'transcription_mode':mode,'ai_provider':provider,'device':'cpu','initial_transcript':source}
    print(json.dumps(config,ensure_ascii=False,indent=2))
    if input('Installare in questa cartella? [s/N]: ').strip().lower()!='s':return 0
    installer.install(config,print,lambda n,m:print(f'[{n}/6] {m}'),threading.Event())
    print('Installazione verificata. Per l’accesso: '+provider+' '+' '.join(PROVIDERS[provider]['login']))
    print('Avvia la demo con il launcher Demo del tuo sistema. Su Linux serve una sessione grafica per l’app.')
    return 0


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--console',action='store_true',help='Wizard nel terminale')
    args=parser.parse_args(argv);installer.check_python()
    if args.console:return console_wizard()
    try:
        import tkinter as tk
        root=tk.Tk()
    except Exception as exc:
        print('Tkinter non disponibile. Su Debian/Ubuntu installa python3-tk e python3-venv; su Mac usa Python da python.org o python-tk della stessa versione.',file=sys.stderr)
        return console_wizard()
    SetupWizard(root);root.mainloop();return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print(str(exc),file=sys.stderr);raise SystemExit(1)
