"""Project-scoped publication metadata, independent of the edited lecture text."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

TEXT_FIELDS = ('course', 'general_topic', 'lecture_title', 'lecture_date',
               'lecturer', 'lecture_number', 'scope', 'instructions')
MACROS = {'course': 'Course', 'general_topic': 'GeneralTopic',
          'lecture_title': 'LectureTitle', 'lecture_date': 'LectureDate',
          'lecturer': 'Lecturer', 'lecture_number': 'LectureNumber', 'scope': 'LectureScope'}


def normalize_settings(value=None, *, title=''):
    value = value or {}
    if not isinstance(value, dict):
        raise ValueError('LaTeX settings must be an object')
    result = {key: str(value.get(key) or '').strip() for key in TEXT_FIELDS}
    result['lecture_title'] = result['lecture_title'] or str(title or '').strip()
    if result['lecture_date']:
        for pattern in ('%Y-%m-%d', '%d/%m/%Y'):
            try:
                result['lecture_date'] = datetime.strptime(result['lecture_date'], pattern).date().isoformat()
                break
            except ValueError:
                continue
        else:
            raise ValueError('Invalid lesson date: use DD/MM/YYYY or YYYY-MM-DD, or leave it blank')
    result['include_toc'] = value.get('include_toc', False)
    if type(result['include_toc']) is not bool:
        raise ValueError('The LaTeX table-of-contents option must be true or false')
    return result


def load_settings(folder, fallback=None):
    path = Path(folder) / '.whisper-studio/latex-settings.json'
    if path.is_file():
        return normalize_settings(json.loads(path.read_text(encoding='utf-8')))
    return normalize_settings(fallback)


def save_settings(folder, value):
    from review_editor import write_json
    if not str(folder or '').strip():
        raise ValueError('Choose the project folder')
    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError('Choose an existing project folder')
    settings = normalize_settings(value)
    # Update just the publication handoff. Never resave the document or its Markdown.
    from filelock import FileLock
    with FileLock(folder / '.project-save.lock', timeout=10):
        write_json(folder / '.whisper-studio/latex-settings.json', settings)
        handoff = folder / 'latex_handoff.json'
        if handoff.is_file():
            data = json.loads(handoff.read_text(encoding='utf-8'))
            data['latex'] = settings
            write_json(handoff, data)
    return settings


def tex_escape(value):
    escapes = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
               '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}',
               '~': r'\textasciitilde{}', '^': r'\textasciicircum{}', '\n': ' '}
    return ''.join(escapes.get(char, char) for char in str(value))


def metadata_tex(settings):
    settings = normalize_settings(settings)
    lines = ['% Generated from the project publication fields. Treat values as plain text.']
    for key, macro in MACROS.items():
        value = settings[key] or ('' if key == 'scope' else '[To be completed]')
        lines.append('\\newcommand{\\' + macro + '}{' + tex_escape(value) + '}')
    return '\n'.join(lines) + '\n'
