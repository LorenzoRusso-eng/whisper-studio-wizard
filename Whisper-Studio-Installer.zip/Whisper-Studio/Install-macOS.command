#!/bin/sh
exec sh "$(dirname -- "$0")/launch.sh" setup "$@"
