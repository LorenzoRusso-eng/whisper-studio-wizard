param(
    [ValidateSet('setup','app','demo')][string]$Action = 'setup',
    [switch]$Console
)
$ErrorActionPreference = 'Stop'
$StudioRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $StudioRoot

function Find-StudioPython {
    $candidates = @()
    if (Test-Path -LiteralPath (Join-Path $StudioRoot '.venv\Scripts\python.exe')) {
        $candidates += [pscustomobject]@{ Exe=(Join-Path $StudioRoot '.venv\Scripts\python.exe'); Args=@() }
    }
    foreach ($selector in @('-3.13','-3.12','-3.11')) {
        $candidates += [pscustomobject]@{ Exe='py'; Args=@($selector) }
    }
    foreach ($name in @('Python313','Python312','Python311')) {
        $candidates += [pscustomobject]@{ Exe=(Join-Path $env:LOCALAPPDATA "Programs\Python\$name\python.exe"); Args=@() }
    }
    $candidates += [pscustomobject]@{ Exe='python'; Args=@() }
    foreach ($candidate in $candidates) {
        try {
            $specArgs = @($candidate.Args)
            & $candidate.Exe @specArgs -c 'import sys; sys.exit(0 if (3,11)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32 else 1)' 2>$null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        } catch { }
    }
    return $null
}

try {
    $python = Find-StudioPython
    if ($null -eq $python) {
        Write-Host '64-bit Python 3.11, 3.12, or 3.13 with Tcl/Tk is required.'
        if (Get-Command winget -ErrorAction SilentlyContinue) {
            $answer = Read-Host 'Install Python 3.13 for this user with winget? [y/N]'
            if ($answer.Trim() -ieq 'y') {
                & winget install --id Python.Python.3.13 --exact --scope user --interactive
                if ($LASTEXITCODE -ne 0) { throw 'Python installation did not complete.' }
                $python = Find-StudioPython
            }
        }
        if ($null -eq $python) {
            Start-Process 'https://www.python.org/downloads/windows/'
            throw 'Install Python 3.13 with Tcl/Tk and pip, then reopen this launcher.'
        }
    }
    $target = switch ($Action) { 'setup' { 'setup_wizard.py' } 'demo' { 'studio_demo.py' } default { 'studio.py' } }
    if ($Action -ne 'setup' -and -not (Test-Path -LiteralPath (Join-Path $StudioRoot '.venv\Scripts\python.exe'))) {
        $target = 'setup_wizard.py'
    }
    $launchArgs = @($python.Args) + @((Join-Path $StudioRoot $target))
    if ($Console -and $target -eq 'setup_wizard.py') { $launchArgs += '--console' }
    & $python.Exe @launchArgs
    exit $LASTEXITCODE
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
