"""Build a shareable source installer using an explicit file allowlist."""
from __future__ import annotations

import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
VERSION='1.2.0'
FILES=(
    'studio.py','studio_runtime.py','installer.py','setup_wizard.py','studio_demo.py','ai_providers.py',
    'audio_selector.pyw','transcribe.py','job_queue.py','audio_review.py',
    'model_catalog.py','lecture_pipeline.py','lecture_ui.py','studio_view.py','lecture_document.py',
    'lecture_markup.py','lecture_preview.py','review_editor.py','latex_export.py','latex_settings.py',
    'latex_assets.py','figure_comparison.py',
    'PROMPT_LECTURE_ORGANIZATION.md','PROMPT_HTML_TO_LATEX.md','README.md','QUICKSTART.md','INSTALLATION.md','CHANGELOG.md',
    'requirements.txt','requirements.lock.txt','requirements-base.txt','requirements-whisper.txt',
    'requirements-cpu.lock.txt','requirements-nvidia.txt','setup.ps1','build_release.py',
    'install-windows.ps1','Install-Windows.bat','Start-Windows.bat','Demo-Windows.bat',
    'launch.sh','Install-macOS.command','Start-macOS.command','Demo-macOS.command',
    'install-linux.sh','start-linux.sh','demo-linux.sh',
    'open-audio-selector.bat','open-lecture-editor.bat','run-whisper.bat',
    'editor/editor.css','editor/editor.js','editor/document.css','editor/insertions.js','editor/comparison.html',
    'editor/vendor/katex/LICENSE','editor/vendor/katex/version.json','editor/vendor/katex/katex.min.js','editor/vendor/katex/katex.min.css',
    'examples/first-lesson/transcript.txt','examples/first-lesson/prepared-result.json','examples/first-lesson/README.md',
    'output/latex-template/lecture-template.tex','output/latex-template/README.md',
)


def release_files(root=ROOT):
    root=Path(root).resolve();files=list(FILES)
    files += [p.relative_to(root).as_posix() for p in sorted((root/'editor/vendor/katex/fonts').glob('*.woff2'))]
    if not files or not any(name.endswith('.woff2') for name in files):raise ValueError('Missing KaTeX fonts')
    for name in files:
        path=(root/name).resolve()
        if not path.is_relative_to(root) or not path.is_file() or (root/name).is_symlink():
            raise ValueError('Missing or external distribution file: '+name)
    return sorted(set(files))


def build(destination=None,root=ROOT):
    root=Path(root).resolve();destination=Path(destination or root/'release/Whisper-Studio-Installer.zip')
    destination.parent.mkdir(parents=True,exist_ok=True);files=release_files(root)
    hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}
    manifest={'product':'Whisper Studio','package':'source-installer','version':VERSION,'schema_version':1,
              'platforms':['Windows','macOS','Linux'],'entrypoint':'QUICKSTART.md','files':hashes}
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED) as packed:
        for name in files:
            item=zipfile.ZipInfo('Whisper-Studio/'+name);item.create_system=3;item.compress_type=zipfile.ZIP_DEFLATED
            mode=0o755 if name.endswith(('.sh','.command')) else 0o644
            item.external_attr=(stat.S_IFREG|mode)<<16
            packed.writestr(item,(root/name).read_bytes())
        packed.writestr('Whisper-Studio/DISTRIBUTION.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    checksum=hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix('.zip.sha256').write_text(checksum+'  '+destination.name+'\n',encoding='ascii')
    return destination,len(files),checksum


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path)
    args=parser.parse_args();path,count,checksum=build(args.output)
    print(f'{path}\n{count} application files · {path.stat().st_size:,} byte\nSHA-256: {checksum}')


if __name__=='__main__':main()
