# First lesson: Ohm's law

`transcript.txt` is an original short teaching transcript included for the demo.
`prepared-result.json` is a **prepared example**, not a live AI response.
The local demo imports the transcript, verifies coverage of all four source
segments, and publishes a new lesson using the real application editor.

No audio is included: Whisper and the second audio pass are skipped.
**Live AI processing** sends the sample text to the configured assistant and
uses the normal pipeline. It requires an authenticated CLI, Internet access,
and available account quota. Each run creates a new output folder to preserve
edits from previous sessions.
