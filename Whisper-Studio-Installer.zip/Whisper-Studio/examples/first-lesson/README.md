# Prima lezione: legge di Ohm

`transcript.txt` è una breve trascrizione didattica originale, inclusa per la demo.
`prepared-result.json` è un risultato di esempio **precompilato**, non una risposta
generata dal vivo. La demo locale importa realmente il testo, controlla la copertura
dei quattro segmenti e pubblica una nuova lezione nell'editor dell'app.

Nessun audio è incluso: Whisper e il secondo passaggio sono saltati.
La modalità **Elaborazione AI reale** invia invece questo testo all'assistente
configurato e usa la normale pipeline. Richiede CLI autenticata, Internet e quota.
Ogni esecuzione usa una cartella nuova per conservare le modifiche precedenti.
