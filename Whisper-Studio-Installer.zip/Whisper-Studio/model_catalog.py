"""Whisper model capabilities and the user's persistent custom model list."""
from __future__ import annotations

import json
import logging
import os
import re
import uuid
from pathlib import Path
from urllib.parse import urlparse

from filelock import FileLock

ROOT=Path(__file__).resolve().parent
DEFAULT_CATALOG=ROOT/'.state/asr-models.json'
LOGGER=logging.getLogger(__name__)
LANGUAGE_CODES=tuple('af am ar as az ba be bg bn bo br bs ca cs cy da de el en es et eu fa fi fo fr gl gu ha haw he hi hr ht hu hy id is it ja jw ka kk km kn ko la lb ln lo lt lv mg mi mk ml mn mr ms mt my ne nl nn no oc pa pl ps pt ro ru sa sd si sk sl sn so sq sr su sv sw ta te tg th tk tl tr tt uk ur uz vi yi yo zh yue'.split())
LANGUAGE_NAMES={
    'auto':'Rilevamento automatico','en':'Inglese','it':'Italiano','fr':'Francese',
    'de':'Tedesco','es':'Spagnolo','pt':'Portoghese','ru':'Russo','zh':'Cinese',
    'ja':'Giapponese','ko':'Coreano','ar':'Arabo','hi':'Hindi','tr':'Turco',
    'nl':'Olandese','pl':'Polacco','el':'Greco','uk':'Ucraino','cs':'Ceco',
    'sv':'Svedese','hu':'Ungherese','ro':'Rumeno','da':'Danese','fi':'Finlandese',
    'no':'Norvegese','bg':'Bulgaro','ca':'Catalano','id':'Indonesiano','vi':'Vietnamita',
    'he':'Ebraico','fa':'Persiano','th':'Thailandese','ur':'Urdu','bn':'Bengalese',
    'ta':'Tamil','te':'Telugu','mr':'Marathi','sk':'Slovacco','sl':'Sloveno',
    'hr':'Croato','sr':'Serbo','sw':'Swahili','af':'Afrikaans','lt':'Lituano',
    'lv':'Lettone','et':'Estone','is':'Islandese','cy':'Gallese','eu':'Basco',
    'gl':'Galiziano','mk':'Macedone','sq':'Albanese','hy':'Armeno','ka':'Georgiano',
    'az':'Azero','kk':'Kazako','ms':'Malese','fil':'Filippino','tl':'Tagalog',
}


def infer_english_only(source):
    name=str(source).replace('\\','/').rstrip('/').rsplit('/',1)[-1].lower()
    return 'distil' in name or bool(re.search(r'\.en(?:[-_.]|$)',name))


def builtin_models():
    try:
        from faster_whisper.utils import available_models
        sources=available_models()
    except (ImportError, OSError):
        sources=['tiny','tiny.en','base','base.en','small','small.en','medium','medium.en',
            'large-v1','large-v2','large-v3','large-v3-turbo','turbo',
            'distil-small.en','distil-medium.en','distil-large-v2','distil-large-v3','distil-large-v3.5']
    if 'distil-large-v3.5' in sources:sources=['distil-large-v3.5']+[s for s in sources if s!='distil-large-v3.5']
    return {s:{'source':s,'name':s,'english_only':infer_english_only(s),'custom':False} for s in sources}


def known_repository_capability(source):
    try:
        from faster_whisper import utils
    except (ImportError, OSError):
        return None
    for alias,repository in getattr(utils,'_MODELS',{}).items():
        if repository==source:return infer_english_only(alias)
    return None


def normalize_source(value):
    value=str(value).strip()
    if not value:raise ValueError('Inserisci il repository o la cartella del modello')
    if value.startswith(('https://','http://')):
        url=urlparse(value)
        if url.scheme!='https' or url.hostname!='huggingface.co' or url.query or url.fragment:
            raise ValueError('Usa un repository Hugging Face oppure una cartella locale')
        value=url.path.strip('/')
    path=Path(value).expanduser()
    if path.is_dir():
        for required in ('model.bin','config.json'):
            if not (path/required).is_file():raise ValueError(f'La cartella CTranslate2 deve contenere {required}')
        return str(path.resolve())
    if path.is_absolute() or '\\' in value or value.startswith(('./','../','~')):
        raise ValueError('La cartella del modello non esiste')
    if value in builtin_models():return value
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*',value):
        raise ValueError('Inserisci un ID Hugging Face nel formato autore/modello, compatibile con CTranslate2')
    return value


class ModelCatalog:
    def __init__(self,path=None):self.path=Path(path or DEFAULT_CATALOG)
    def custom_models(self):
        if not self.path.is_file():return {}
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            if data.get('schema_version')!=1 or not isinstance(data.get('models'),list):raise ValueError('Formato elenco modelli non valido')
            models={}
            for entry in data['models']:
                if not isinstance(entry,dict) or not isinstance(entry.get('source'),str) or type(entry.get('english_only')) is not bool:
                    raise ValueError('Definizione di modello non valida')
                source=entry['source'];models[source]={**entry,'name':str(entry.get('name') or Path(source).name),'custom':True}
            return models
        except (OSError,ValueError,TypeError) as exc:
            LOGGER.warning('Cannot read model catalog: %s',exc)
            return {}
    def entries(self):return {**self.custom_models(),**builtin_models()}
    def entry(self,source):
        return self.entries().get(source,{'source':source,'name':Path(source).name,'english_only':infer_english_only(source),'custom':True})
    def compatible(self,language):
        return {s:m for s,m in self.entries().items() if language=='en' or not m['english_only']}
    def register(self,source,*,name='',english_only=None):
        source=normalize_source(source)
        builtins=builtin_models()
        if source in builtins:return builtins[source]
        entry={'source':source,'name':str(name).strip() or Path(source).name,
            'english_only':infer_english_only(source) if english_only is None else bool(english_only),'custom':True}
        known=known_repository_capability(source)
        if known is not None:entry['english_only']=known
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with FileLock(str(self.path)+'.lock',timeout=10):
            # Do not replace a broken catalog with a new, incomplete list.
            if self.path.is_file():
                data=json.loads(self.path.read_text(encoding='utf-8'))
                if data.get('schema_version')!=1 or not isinstance(data.get('models'),list):raise ValueError('Elenco modelli danneggiato; il file originale è conservato')
                if any(not isinstance(m,dict) or not isinstance(m.get('source'),str) or type(m.get('english_only')) is not bool for m in data['models']):
                    raise ValueError('Elenco modelli danneggiato; il file originale è conservato')
            models=self.custom_models();models[source]=entry
            temp=self.path.with_name(self.path.name+'.'+uuid.uuid4().hex+'.tmp')
            try:
                with temp.open('w',encoding='utf-8',newline='\n') as stream:
                    json.dump({'schema_version':1,'models':list(models.values())},stream,ensure_ascii=False,indent=2)
                    stream.flush();os.fsync(stream.fileno())
                os.replace(temp,self.path)
            finally:
                if temp.exists():temp.unlink()
        return entry


def is_english_only(source):return ModelCatalog().entry(source)['english_only']


def default_model(language):return 'distil-large-v3.5' if language=='en' else 'large-v3-turbo'


def language_label(code):return LANGUAGE_NAMES.get(code,str(code).upper())


def language_choices():
    try:
        from faster_whisper.tokenizer import _LANGUAGE_CODES
    except (ImportError, OSError):
        _LANGUAGE_CODES=LANGUAGE_CODES
    rest=sorted((code for code in _LANGUAGE_CODES if code not in {'en','it'}),key=language_label)
    codes=['en','it','auto',*rest]
    return {f'{language_label(code)} ({code})':code for code in codes}
