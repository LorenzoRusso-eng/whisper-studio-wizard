"""Publish a source comparison workspace without changing the lecture project."""
import html
import json
import re
import shutil
from pathlib import Path


def render_comparison(folder, project):
    folder = Path(folder).resolve()
    groups = []
    destination = folder / 'assets' / 'comparison'
    for key, label in [('clean_slides', 'Slide del professore'),
                       ('whiteboard', 'Lavagne'), ('annotated_slides', 'Appunti dello studente')]:
        source = project.get('sources', {}).get(key, {})
        pages = []
        for page in source.get('pages', []):
            image = page.get('image')
            if not image:
                continue
            image = Path(image)
            if not image.is_absolute():
                image = folder / image
            if not image.is_file() or image.suffix.lower() not in {'.png', '.jpg'}:
                continue
            target = destination / f'{key}-{int(page["page"]):03d}{image.suffix.lower()}'
            destination.mkdir(parents=True, exist_ok=True)
            if not target.exists() or target.stat().st_mtime_ns != image.stat().st_mtime_ns:
                shutil.copy2(image, target)
            pages.append({'page': page['page'], 'image': target.relative_to(folder).as_posix()})
        groups.append({'key': key, 'label': label, 'pages': pages})
    figures = []
    for figure in project.get('figures', []):
        asset = (folder / figure['asset']).resolve()
        if not asset.is_relative_to(folder):
            continue
        match = re.search(r'\bA(\d+)\b', figure.get('source', ''))
        figures.append({**figure, 'annotated_page': int(match[1]) if match else None})
    data = json.dumps({'figures': figures, 'groups': groups}, ensure_ascii=False).replace('<', '\\u003c')
    title = html.escape(project.get('title', 'Lezione'))
    template = (Path(__file__).parent / 'editor' / 'comparison.html').read_text(encoding='utf-8')
    return template.replace('{{TITLE}}', title).replace('{{DATA}}', data)
