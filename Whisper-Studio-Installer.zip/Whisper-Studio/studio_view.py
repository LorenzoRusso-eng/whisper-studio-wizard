"""Compact, single-screen presentation for Whisper Studio's lecture workflow."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

C={'page':'#F4F5FA','paper':'#FFFFFF','ink':'#20243A','muted':'#758097',
   'line':'#E3E7F0','field':'#F9FAFD','accent':'#6554D9','hover':'#5442C2',
   'soft':'#F0EDFD','green':'#217956','green_bg':'#EDF8F2','amber':'#94612B'}


class Tooltip:
    def __init__(self,widget,text):
        self.widget=widget;self.text=text;self.pending=None;self.window=None
        widget.bind('<Enter>',self.schedule,add='+');widget.bind('<Leave>',self.hide,add='+')
        widget.bind('<ButtonPress>',self.hide,add='+')
    def schedule(self,_event=None):
        self.hide();self.pending=self.widget.after(650,self.show)
    def show(self):
        self.pending=None;text=self.text() if callable(self.text) else self.text
        if not text:return
        try:
            self.window=tk.Toplevel(self.widget);self.window.overrideredirect(True)
            label=tk.Label(self.window,text=text,bg='#283249',fg='white',font=('Segoe UI',9),
                padx=12,pady=8,wraplength=520,justify='left');label.pack()
            self.window.update_idletasks()
            x=min(self.widget.winfo_rootx(),self.widget.winfo_screenwidth()-self.window.winfo_reqwidth()-12)
            y=min(self.widget.winfo_rooty()+self.widget.winfo_height()+7,self.widget.winfo_screenheight()-self.window.winfo_reqheight()-12)
            self.window.geometry(f'+{max(0,x)}+{max(0,y)}')
        except tk.TclError:self.window=None
    def hide(self,_event=None):
        try:
            if self.pending:self.widget.after_cancel(self.pending)
            if self.window:self.window.destroy()
        except tk.TclError:pass
        self.pending=None;self.window=None


def setup_style(app):
    root=app.root;style=ttk.Style(root)
    if 'clam' in style.theme_names():style.theme_use('clam')
    root.configure(bg=C['page'])
    root.option_add('*TCombobox*Listbox.font',('Segoe UI',10))
    root.option_add('*TCombobox*Listbox.background',C['paper'])
    root.option_add('*TCombobox*Listbox.selectBackground',C['soft'])
    root.option_add('*TCombobox*Listbox.selectForeground',C['accent'])
    style.configure('.',font=('Segoe UI',10),foreground=C['ink'])
    style.configure('TFrame',background=C['paper'])
    style.configure('Page.TFrame',background=C['page'])
    style.configure('TLabel',background=C['paper'],foreground=C['ink'])
    style.configure('Muted.TLabel',foreground=C['muted'],font=('Segoe UI',9))
    style.configure('Caption.TLabel',foreground=C['muted'],font=('Segoe UI Semibold',9))
    style.configure('Title.TLabel',font=('Segoe UI Semibold',13))
    style.configure('Badge.TLabel',background=C['soft'],foreground=C['accent'],padding=(8,3),font=('Segoe UI Semibold',8))
    style.configure('Connection.TLabel',background=C['soft'],foreground=C['accent'],padding=(10,6),font=('Segoe UI',9))
    style.configure('Ready.Connection.TLabel',background=C['green_bg'],foreground=C['green'])
    style.configure('Warning.Connection.TLabel',background='#FCF3E8',foreground=C['amber'])
    style.configure('TEntry',fieldbackground=C['field'],bordercolor=C['line'],lightcolor=C['line'],
        darkcolor=C['line'],insertcolor=C['ink'],padding=(9,4),borderwidth=1)
    style.map('TEntry',bordercolor=[('focus',C['accent'])],fieldbackground=[('disabled','#F1F3F8')])
    style.configure('TCombobox',fieldbackground=C['field'],background=C['field'],
        bordercolor=C['line'],lightcolor=C['line'],darkcolor=C['line'],arrowcolor=C['muted'],padding=(9,4),arrowsize=13)
    style.map('TCombobox',fieldbackground=[('readonly',C['field']),('disabled','#F1F3F8')],
        selectbackground=[('readonly',C['field'])],selectforeground=[('readonly',C['ink'])],
        bordercolor=[('focus',C['accent'])])
    style.configure('TButton',padding=(11,7),background=C['paper'],foreground=C['ink'],
        bordercolor=C['line'],lightcolor=C['line'],darkcolor=C['line'],borderwidth=1,focusthickness=0)
    style.map('TButton',background=[('disabled','#F4F5F9'),('active','#F3F2FA')],foreground=[('disabled','#A5ADBC')])
    style.configure('Accent.TButton',background=C['accent'],foreground='white',bordercolor=C['accent'],
        lightcolor=C['accent'],darkcolor=C['accent'],padding=(18,8),font=('Segoe UI Semibold',10))
    style.map('Accent.TButton',background=[('disabled','#D9D4F2'),('active',C['hover'])],
        foreground=[('disabled','#9489BC'),('!disabled','white')],bordercolor=[('active',C['hover'])])
    style.configure('Soft.TButton',background=C['soft'],foreground=C['accent'],bordercolor=C['soft'],
        lightcolor=C['soft'],darkcolor=C['soft'],font=('Segoe UI Semibold',9),padding=(10,7))
    style.map('Soft.TButton',background=[('active','#E6E1F9')],foreground=[('disabled','#A5ADBC')])
    style.configure('Browse.TButton',font=('Segoe UI',9),padding=(8,4))
    style.configure('Ghost.TButton',borderwidth=0,background=C['paper'],foreground=C['muted'],padding=(4,5),font=('Segoe UI',10))
    style.configure('Quiet.TMenubutton',background=C['paper'],foreground=C['muted'],padding=(10,7),borderwidth=0,font=('Segoe UI',9))
    style.configure('TCheckbutton',background=C['paper'],font=('Segoe UI',10))
    style.configure('TNotebook',background=C['page'],borderwidth=0)
    style.configure('TNotebook.Tab',padding=(16,7),font=('Segoe UI Semibold',10),background=C['page'],foreground=C['muted'])
    style.map('TNotebook.Tab',background=[('selected',C['paper'])],foreground=[('selected',C['accent'])])
    style.map('TCheckbutton',background=[('active',C['paper'])])
    style.configure('Horizontal.TProgressbar',background=C['accent'],troughcolor='#EFEDF7',borderwidth=0,
        bordercolor='#EFEDF7',lightcolor=C['accent'],darkcolor=C['accent'],thickness=8)
    # Clam's slider does not paint in a compact trough; the default element does.
    style.element_create('Studio.Progressbar.pbar','from','default','Horizontal.Progressbar.pbar')
    style.layout('Horizontal.TProgressbar',[
        ('Horizontal.Progressbar.trough',{'sticky':'nsew','children':[
            ('Studio.Progressbar.pbar',{'side':'left','sticky':'ns'})]})])
    style.configure('Step.TLabel',background=C['paper'],foreground='#9AA3B4',font=('Segoe UI',9))
    style.configure('Active.Step.TLabel',background=C['paper'],foreground=C['accent'],font=('Segoe UI Semibold',9))
    style.configure('Done.Step.TLabel',background=C['paper'],foreground=C['green'],font=('Segoe UI',9))
    style.configure('Warning.Step.TLabel',background=C['paper'],foreground=C['amber'],font=('Segoe UI',9))


def tip(app,widget,text):
    tooltip=Tooltip(widget,text);app.tooltips.append(tooltip);return tooltip


def card(parent,title,number,subtitle='',badge=None):
    outer=tk.Frame(parent,bg=C['paper'],highlightbackground=C['line'],highlightthickness=1,bd=0)
    outer.columnconfigure(0,weight=1);outer.rowconfigure(1,weight=1)
    header=ttk.Frame(outer,padding=(16,10,16,7));header.grid(row=0,column=0,sticky='ew');header.columnconfigure(1,weight=1)
    ttk.Label(header,text=number,style='Badge.TLabel').grid(row=0,column=0,padx=(0,9))
    ttk.Label(header,text=title,style='Title.TLabel').grid(row=0,column=1,sticky='w')
    if badge is not None:ttk.Label(header,textvariable=badge,style='Muted.TLabel').grid(row=0,column=2,sticky='e')
    if subtitle:ttk.Label(header,text=subtitle,style='Muted.TLabel').grid(row=1,column=0,columnspan=3,sticky='w',pady=(4,0))
    body=ttk.Frame(outer,padding=(16,1,16,11));body.grid(row=1,column=0,sticky='nsew')
    return outer,body,header


def file_picker(app,parent,row,key,label,callback,page_key=None):
    ttk.Label(parent,text=label,font=('Segoe UI',9)).grid(row=row,column=0,sticky='w',padx=(0,12),pady=3)
    entry=ttk.Entry(parent,textvariable=app.variables[key],width=10,font=('Segoe UI',9))
    entry.grid(row=row,column=1,sticky='ew',pady=3);app.path_entries[key]=entry
    actions=ttk.Frame(parent);actions.grid(row=row,column=2,padx=(8,0))
    if page_key:
        ttk.Label(actions,text='da p.',style='Muted.TLabel').pack(side='left',padx=(0,4))
        page=ttk.Entry(actions,textvariable=app.variables[page_key],width=3,font=('Segoe UI',9))
        page.pack(side='left',padx=(0,8));app.form_widgets.append(page)
        tip(app,page,'Prima pagina PDF da usare. Lascia vuoto per partire dalla pagina 1.')
    button=ttk.Button(actions,text='Scegli',width=6,style='Browse.TButton',command=callback)
    button.pack(side='left');app.form_widgets.extend([entry,button])
    tip(app,entry,lambda k=key:app.variables[k].get() or 'Seleziona il file da usare per questa lezione.')
    entry.bind('<FocusOut>',lambda _e,e=entry:e.xview_moveto(1),add='+')
    entry.bind('<Configure>',lambda _e,e=entry:e.xview_moveto(1) if app.root.focus_get()!=e else None,add='+')
    if key!='folder':
        clear=ttk.Button(actions,text='×',width=2,style='Ghost.TButton',command=lambda:app.variables[key].set(''))
        clear.pack(side='left',padx=(3,0));app.form_widgets.append(clear);tip(app,clear,'Rimuovi questa selezione')
    return entry


def refresh_materials(app):
    count=sum(bool(app.variables[key].get()) for key in ('audio','transcript','clean_slides','annotated_slides','whiteboard'))+len(app.context_files)
    app.materials_count.set(f'{count} file selezionat'+('o' if count==1 else 'i'))
    for entry in app.path_entries.values():
        if app.root.focus_get()!=entry:entry.xview_moveto(1)


def refresh_connection(app):
    text=app.codex_status.get().casefold()
    name={'codex':'Codex','claude':'Claude','gemini':'Gemini'}.get(app.variables['ai_provider'].get(),'Assistente')
    if 'pronto' in text:label,style='●  '+name+' pronto','Ready.Connection.TLabel'
    elif text.startswith('verifica'):label,style='●  Verifica '+name,'Connection.TLabel'
    else:label,style='●  '+name+' da verificare','Warning.Connection.TLabel'
    app.connection_label.set(label);app.connection_badge.configure(style=style)


def build_ui(app):
    setup_style(app);root=app.root
    app.tooltips=[];app.path_entries={}
    text_options={'wrap':'word','font':('Segoe UI',10),'relief':'flat','bd':0,'padx':10,'pady':8,
        'bg':C['field'],'fg':C['ink'],'insertbackground':C['accent'],'highlightthickness':1,
        'highlightbackground':C['line'],'highlightcolor':C['accent'],'undo':True}
    app.materials_count=tk.StringVar(root,value='0 file selezionati');app.connection_label=tk.StringVar(root,value='●  Verifica connessione')
    root.configure(menu='');outer=ttk.Frame(root,style='Page.TFrame');outer.pack(fill='both',expand=True)
    outer.columnconfigure(0,weight=1);outer.rowconfigure(2,weight=1)
    header=ttk.Frame(outer,padding=(24,10));header.grid(row=0,column=0,sticky='ew');header.columnconfigure(1,weight=1)
    logo=tk.Canvas(header,width=37,height=36,bg=C['paper'],bd=0,highlightthickness=0)
    logo.grid(row=0,column=0,rowspan=2,padx=(0,12))
    for x,h in [(5,10),(12,22),(19,31),(26,18),(33,8)]:logo.create_line(x,18-h/2,x,18+h/2,fill=C['accent'],width=4,capstyle='round')
    ttk.Label(header,text='Whisper Studio',font=('Segoe UI Semibold',20)).grid(row=0,column=1,sticky='w')
    ttk.Label(header,text='Dalla lezione ai tuoi appunti.',style='Muted.TLabel').grid(row=1,column=1,sticky='w',pady=(2,0))
    app.connection_badge=ttk.Label(header,textvariable=app.connection_label,style='Connection.TLabel')
    app.connection_badge.grid(row=0,column=2,rowspan=2,padx=(12,14));tip(app,app.connection_badge,lambda:app.codex_status.get())
    tools=ttk.Menubutton(header,text='Strumenti',style='Quiet.TMenubutton');menu=tk.Menu(tools,tearoff=False)
    menu.add_command(label='Trascrizione avanzata',command=app.open_advanced);menu.add_command(label='Verifica assistente',command=app.refresh_codex)
    menu.add_command(label='Installazione e assistente AI…',command=app.open_setup)
    menu.add_command(label='Demo guidata',command=app.open_demo)
    tools.configure(menu=menu);tools.grid(row=0,column=3,rowspan=2)

    project=tk.Frame(outer,bg=C['paper'],highlightbackground=C['line'],highlightthickness=1)
    project.grid(row=1,column=0,sticky='ew',padx=20,pady=(8,8))
    project_form=ttk.Frame(project,padding=(16,8));project_form.pack(fill='both',expand=True)
    project_form.columnconfigure(1,weight=3);project_form.columnconfigure(4,weight=2)
    ttk.Label(project_form,text='PROGETTO',style='Caption.TLabel').grid(row=0,column=0,padx=(0,14))
    folder=ttk.Entry(project_form,textvariable=app.variables['folder'],width=15,font=('Segoe UI',9))
    folder.grid(row=0,column=1,sticky='ew');app.path_entries['folder']=folder;app.form_widgets.append(folder)
    folder.bind('<Configure>',lambda _e:folder.xview_moveto(1) if root.focus_get()!=folder else None,add='+')
    select=ttk.Button(project_form,text='Scegli cartella',command=app.choose_folder,style='Browse.TButton')
    select.grid(row=0,column=2,padx=(8,20));app.form_widgets.append(select)
    ttk.Label(project_form,text='Titolo',style='Muted.TLabel').grid(row=0,column=3,padx=(0,9))
    title=ttk.Entry(project_form,textvariable=app.variables['title'],width=18,font=('Segoe UI',9))
    title.grid(row=0,column=4,sticky='ew');app.form_widgets.append(title)
    tip(app,folder,lambda:app.variables['folder'].get() or 'La cartella in cui salvare appunti, figure e revisioni.')
    tip(app,title,'Il titolo usato per organizzare la lezione.')
    choices=ttk.Frame(project_form);choices.grid(row=1,column=0,columnspan=5,sticky='ew',pady=(8,0))
    ttk.Label(choices,text='Trascrizione',style='Muted.TLabel').pack(side='left',padx=(0,8))
    mode=ttk.Combobox(choices,textvariable=app.variables['transcription_mode'],values=('whisper','external'),state='readonly',width=10)
    mode.pack(side='left');tip(app,mode,'whisper: riconoscimento locale e controllo audio. external: carica il testo già trascritto; entrambi i passaggi audio vengono saltati.')
    ttk.Label(choices,text='Assistente AI',style='Muted.TLabel').pack(side='left',padx=(20,8))
    provider=ttk.Combobox(choices,textvariable=app.variables['ai_provider'],values=('codex','claude','gemini'),state='readonly',width=10)
    provider.pack(side='left');provider.bind('<<ComboboxSelected>>',lambda _e:app.refresh_codex())
    app.form_widgets.extend([mode,provider]);app.readonly_widgets.update([mode,provider])

    content=ttk.Frame(outer,style='Page.TFrame');content.grid(row=2,column=0,sticky='nsew',padx=20,pady=(0,12))
    content.columnconfigure(0,weight=6,uniform='main');content.columnconfigure(1,weight=5,uniform='main');content.rowconfigure(0,weight=1)
    materials,files,_=card(content,'Materiali della lezione','01','Scegli un audio o una trascrizione, poi aggiungi il contesto.',app.materials_count)
    materials.grid(row=0,column=0,sticky='nsew',padx=(0,12));files.columnconfigure(1,weight=1)
    file_picker(app,files,0,'audio','Audio / video',lambda:app.choose_file('audio'))
    file_picker(app,files,1,'transcript','Trascrizione',lambda:app.choose_file('transcript'))
    ttk.Separator(files).grid(row=2,column=0,columnspan=3,sticky='ew',pady=(3,5))
    file_picker(app,files,3,'clean_slides','Slide pulite',lambda:app.choose_file('clean_slides'),page_key='clean_start')
    file_picker(app,files,4,'annotated_slides','Slide annotate',lambda:app.choose_file('annotated_slides'),page_key='annotated_start')
    file_picker(app,files,5,'whiteboard','Lavagna',lambda:app.choose_file('whiteboard'))
    ttk.Separator(files).grid(row=6,column=0,columnspan=3,sticky='ew',pady=(5,6))
    ttk.Label(files,text='Altro contesto',font=('Segoe UI',9)).grid(row=7,column=0,sticky='w',padx=(0,12))
    extras=ttk.Entry(files,textvariable=app.context_label,state='readonly',width=10,font=('Segoe UI',9));extras.grid(row=7,column=1,sticky='ew')
    tip(app,extras,lambda:'\n'.join(app.context_files) or 'Puoi aggiungere altri PDF, testi o immagini.')
    app.readonly_widgets.add(extras);app.form_widgets.append(extras)
    buttons=ttk.Frame(files);buttons.grid(row=7,column=2,padx=(8,0),sticky='e')
    add=ttk.Button(buttons,text='Aggiungi',width=8,style='Browse.TButton',command=app.choose_context);add.pack(side='left');app.form_widgets.append(add)
    clear=ttk.Button(buttons,text='×',width=2,style='Ghost.TButton',command=app.clear_context);clear.pack(side='left',padx=(3,0));app.form_widgets.append(clear)
    tip(app,clear,'Rimuovi i materiali aggiuntivi')
    ttk.Label(files,text='Termini tecnici per l’audio',style='Caption.TLabel').grid(row=8,column=0,columnspan=3,sticky='w',pady=(8,5))
    files.rowconfigure(9,weight=1,minsize=38)
    app.glossary=tk.Text(files,height=2,**text_options);app.glossary.grid(row=9,column=0,columnspan=3,sticky='nsew')
    tip(app,app.glossary,'Nomi, sigle e termini tecnici utili al riconoscimento audio.');app.form_widgets.append(app.glossary)

    app.workflow_tabs=ttk.Notebook(content);app.workflow_tabs.grid(row=0,column=1,sticky='nsew')
    right=ttk.Frame(app.workflow_tabs,style='Page.TFrame');app.workflow_tabs.add(right,text='Elaborazione')
    right.columnconfigure(0,weight=1);right.rowconfigure(1,weight=1)
    audio,settings,audio_header=card(right,'Lingua e modello','02')
    audio.grid(row=0,column=0,sticky='ew',pady=(0,12));settings.columnconfigure(1,weight=1)
    app.add_model_button=ttk.Button(audio_header,text='+ Modello',style='Soft.TButton',command=app.show_add_model)
    app.add_model_button.grid(row=0,column=2,padx=(12,0));tip(app,app.add_model_button,'Aggiungi un modello Whisper da Hugging Face o da una cartella locale.')
    ttk.Label(settings,text='Lingua audio',font=('Segoe UI',9)).grid(row=0,column=0,sticky='w',padx=(0,12),pady=4)
    app.language_combo=ttk.Combobox(settings,textvariable=app.language_choice,values=tuple(app.language_options),state='readonly',width=12,font=('Segoe UI',9))
    app.language_combo.grid(row=0,column=1,sticky='ew',pady=4)
    app.language_combo.bind('<<ComboboxSelected>>',lambda _e:app.variables['language'].set(app.language_options[app.language_choice.get()]))
    ttk.Label(settings,text='Modello',font=('Segoe UI',9)).grid(row=1,column=0,sticky='w',padx=(0,12),pady=4)
    app.model_combo=ttk.Combobox(settings,textvariable=app.variables['model'],state='readonly',width=12,font=('Segoe UI',9))
    app.model_combo.grid(row=1,column=1,sticky='ew',pady=4);tip(app,app.model_combo,lambda:app.variables['model'].get())
    model_note=ttk.Label(settings,textvariable=app.model_hint,style='Muted.TLabel',wraplength=380)
    model_note.grid(row=2,column=0,columnspan=2,sticky='w',pady=(5,0))
    app.form_widgets.extend([app.language_combo,app.model_combo,app.add_model_button]);app.readonly_widgets.update([app.language_combo,app.model_combo])

    notes,editor,_=card(right,'Indicazioni','03','Facoltative. Il prompt di base è già pronto.')
    notes.grid(row=1,column=0,sticky='nsew');editor.columnconfigure(0,weight=1)
    editor.rowconfigure(1,weight=1,minsize=60)
    ttk.Label(editor,text='Cosa tenere presente',style='Caption.TLabel').grid(row=0,column=0,sticky='w',pady=(3,6))
    app.instructions=tk.Text(editor,height=5,**text_options);app.instructions.grid(row=1,column=0,sticky='nsew')
    tip(app,app.instructions,'Indica sezioni da includere, particolarità dei materiali o correzioni già note.')
    app.form_widgets.append(app.instructions)
    lecture_actions=ttk.Frame(editor);lecture_actions.grid(row=2,column=0,sticky='ew',pady=(10,0));lecture_actions.columnconfigure(0,weight=1)
    app.cancel_button=ttk.Button(lecture_actions,text='Annulla',style='Ghost.TButton',command=app.cancel,state='disabled')
    app.cancel_button.grid(row=0,column=0,sticky='e',padx=(0,9))
    app.start_button=ttk.Button(lecture_actions,text='Elabora lezione  →',style='Accent.TButton',command=app.start)
    app.start_button.grid(row=0,column=1,sticky='e')

    latex_page=ttk.Frame(app.workflow_tabs,style='Page.TFrame');app.workflow_tabs.add(latex_page,text='LaTeX e PDF')
    latex_page.columnconfigure(0,weight=1);latex_page.rowconfigure(0,weight=1)
    latex,fields,_=card(latex_page,'Dati e pubblicazione','04','Usa la lezione corretta e salvata nell’editor.')
    latex.grid(row=0,column=0,sticky='nsew');fields.columnconfigure(1,weight=1)
    for row,key,label in [(0,'course','Corso'),(1,'general_topic','Tema'),(2,'lecture_title','Lezione'),(3,'lecturer','Docente')]:
        ttk.Label(fields,text=label,font=('Segoe UI',9)).grid(row=row,column=0,sticky='w',padx=(0,10),pady=3)
        entry=ttk.Entry(fields,textvariable=app.latex_variables[key],width=12,font=('Segoe UI',9))
        entry.grid(row=row,column=1,sticky='ew',pady=3);app.form_widgets.append(entry)
        if key=='lecture_title':tip(app,entry,'Titolo specifico per il PDF. Se vuoto, usa il titolo del progetto salvato.')
    ttk.Label(fields,text='Data / n.',font=('Segoe UI',9)).grid(row=4,column=0,sticky='w',padx=(0,10),pady=3)
    date_row=ttk.Frame(fields);date_row.grid(row=4,column=1,sticky='ew',pady=3);date_row.columnconfigure(0,weight=1)
    date=ttk.Entry(date_row,textvariable=app.latex_variables['lecture_date'],width=12,font=('Segoe UI',9));date.grid(row=0,column=0,sticky='ew')
    tip(app,date,'Data della lezione: GG/MM/AAAA oppure AAAA-MM-GG. Vuoto se non nota.')
    ttk.Label(date_row,text='N.',style='Muted.TLabel').grid(row=0,column=1,padx=(12,6))
    number=ttk.Entry(date_row,textvariable=app.latex_variables['lecture_number'],width=6,font=('Segoe UI',9));number.grid(row=0,column=2)
    app.form_widgets.extend([date,number]);tip(app,number,'Numero o identificativo della lezione; non viene dedotto dal nome della cartella.')
    ttk.Label(fields,text='Scope',font=('Segoe UI',9)).grid(row=5,column=0,sticky='w',padx=(0,10),pady=3)
    scope=ttk.Entry(fields,textvariable=app.latex_variables['scope'],width=12,font=('Segoe UI',9));scope.grid(row=5,column=1,sticky='ew',pady=3)
    app.form_widgets.append(scope);tip(app,scope,'Testo iniziale facoltativo sotto la testata. Se vuoto, il PDF lo omette.')
    toc=ttk.Checkbutton(fields,text='Aggiungi l’indice dei contenuti',variable=app.latex_toc);toc.grid(row=6,column=0,columnspan=2,sticky='w',pady=(5,3));app.form_widgets.append(toc)
    ttk.Label(fields,text='Indicazioni per il LaTeX',style='Caption.TLabel').grid(row=7,column=0,columnspan=2,sticky='w',pady=(5,4))
    app.latex_instructions=tk.Text(fields,height=3,**text_options);app.latex_instructions.grid(row=8,column=0,columnspan=2,sticky='nsew')
    fields.rowconfigure(8,weight=1,minsize=48);app.form_widgets.append(app.latex_instructions)
    tip(app,app.latex_instructions,'Vincoli di impaginazione o figure. Il testo approvato, le sezioni e i segnaposto restano quelli salvati.')
    latex_actions=ttk.Frame(fields);latex_actions.grid(row=9,column=0,columnspan=2,sticky='ew',pady=(9,0));latex_actions.columnconfigure(2,weight=1)
    app.latex_save_button=ttk.Button(latex_actions,text='Salva dati',style='Browse.TButton',command=app.save_latex);app.latex_save_button.grid(row=0,column=0)
    app.latex_prompt_button=ttk.Button(latex_actions,text='Prepara prompt',style='Browse.TButton',command=app.prepare_latex);app.latex_prompt_button.grid(row=0,column=1,padx=7)
    app.latex_cancel_button=ttk.Button(latex_actions,text='Annulla',style='Ghost.TButton',command=app.cancel,state='disabled')
    app.latex_cancel_button.grid(row=0,column=2,sticky='e',padx=(0,7))
    app.latex_export_button=ttk.Button(latex_actions,text='Genera LaTeX',style='Soft.TButton',command=app.start_latex);app.latex_export_button.grid(row=0,column=3,sticky='e')
    tip(app,app.latex_prompt_button,'Congela gli input e prepara il prompt riproducibile senza chiamare l’assistente AI.')
    tip(app,app.latex_export_button,'Crea una nuova esportazione LaTeX, il PDF quando compilabile e lo ZIP. Non ripete Whisper.')

    footer=ttk.Frame(outer,padding=(20,9,20,8));footer.grid(row=3,column=0,sticky='ew');footer.columnconfigure(0,weight=1)
    state=ttk.Frame(footer);state.grid(row=0,column=0,sticky='ew',padx=(0,18));state.columnconfigure(1,weight=1)
    ttk.Label(state,textvariable=app.progress_context,style='Badge.TLabel').grid(row=0,column=0,sticky='w',padx=(0,9))
    status=tk.Label(state,textvariable=app.status,bg=C['paper'],fg=C['ink'],font=('Segoe UI Semibold',10),anchor='w',height=1,width=1)
    status.grid(row=0,column=1,sticky='ew');tip(app,status,lambda:app.status.get())
    activity=tk.Label(state,textvariable=app.activity,bg=C['paper'],fg=C['muted'],font=('Segoe UI',9),anchor='w',height=1,width=1)
    activity.grid(row=1,column=0,columnspan=2,sticky='ew',pady=(3,0));tip(app,activity,lambda:app.activity.get())
    actions=ttk.Frame(footer);actions.grid(row=0,column=1,sticky='e')
    app.open_button=ttk.Button(actions,text='Apri lezione',command=app.open_result);app.open_button.grid(row=0,column=0,padx=(0,9));tip(app,app.open_button,'Apri l’HTML modificabile salvato in questo progetto.')
    app.open_latex_button=ttk.Button(actions,text='Apri LaTeX',command=app.open_latex);app.open_latex_button.grid(row=0,column=1,padx=(0,9))
    tip(app,app.open_latex_button,'Apri il PDF dell’ultima esportazione disponibile, oppure il sorgente LaTeX se il PDF manca.')
    app.details_button=ttk.Button(actions,text='Dettagli',style='Ghost.TButton',command=app.show_details);app.details_button.grid(row=0,column=2)
    progress_frame=ttk.Frame(footer,height=8);progress_frame.grid(row=1,column=0,columnspan=2,sticky='ew',pady=(8,5));progress_frame.pack_propagate(False)
    app.progress=ttk.Progressbar(progress_frame,mode='determinate',maximum=100);app.progress.pack(fill='both',expand=True)
    steps=ttk.Frame(footer);steps.grid(row=2,column=0,columnspan=2,sticky='ew');app.step_labels=[]
    for i,label in enumerate(['Materiali','Trascrizione','Contesto','Elaborazione','Appunti']):
        steps.columnconfigure(i,weight=1,uniform='phases')
        node=ttk.Label(steps,text=f'{i+1:02d}  {label}',style='Step.TLabel');node.grid(row=0,column=i,sticky='w');app.step_labels.append(node)
    for key in app.path_entries:app.variables[key].trace_add('write',lambda *_:refresh_materials(app))
    app.variables['folder'].trace_add('write',lambda *_:app.project_folder_changed())
    app.workflow_tabs.bind('<<NotebookTabChanged>>',lambda _event:app.show_workflow_progress())
    app.codex_status.trace_add('write',lambda *_:refresh_connection(app))
    refresh_connection(app);refresh_materials(app)
