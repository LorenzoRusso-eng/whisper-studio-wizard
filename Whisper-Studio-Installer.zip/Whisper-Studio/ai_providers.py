"""CLI adapters. Prompts travel through stdin, never through a shell."""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import signal
import subprocess
import threading
import time
from pathlib import Path

from studio_runtime import ROOT, PROVIDERS, hidden_process_options, provider_id


def locate(provider):
    provider = provider_id(provider)
    suffixes = ('.exe', '', '.cmd') if os.name == 'nt' else ('',)
    candidates = [ROOT / '.tools' / (provider + suffix) for suffix in suffixes]
    candidates += [ROOT / '.tools/bin' / provider, Path.home() / '.local/bin' / provider]
    if provider == 'codex' and os.name == 'nt':
        candidates.append(Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs/OpenAI/Codex/bin/codex.exe')
    for path in candidates:
        if path.is_file():
            return str(path.resolve())
    for suffix in suffixes:
        path = shutil.which(provider + suffix)
        if path:
            return str(Path(path).absolute())
    raise FileNotFoundError(f'{PROVIDERS[provider]["name"]} not found. Open the installation wizard.')


def executable_command(executable, provider):
    """Resolve npm's Windows shim without cmd.exe or shell interpolation."""
    path = Path(executable)
    if path.suffix.lower() not in {'.cmd', '.bat', '.ps1'}:
        return [str(path)]
    package = path.parent / 'node_modules' / PROVIDERS[provider]['package']
    metadata = package / 'package.json'
    if not metadata.is_file():
        raise RuntimeError(f'Cannot resolve the npm launcher: {path}. Reinstall it through the wizard.')
    data = json.loads(metadata.read_text(encoding='utf-8'))
    entry = data['bin']
    if isinstance(entry, dict):
        entry = entry[provider]
    target = (package / entry).resolve()
    if not target.is_relative_to(package.resolve()) or not target.is_file():
        raise RuntimeError('The CLI package contains an invalid launcher')
    if target.suffix.lower() == '.exe':
        return [str(target)]
    node = shutil.which('node')
    if not node:
        raise FileNotFoundError('Node.js not found. Install Node.js 22 or later and reopen the wizard.')
    return [node, str(target)]


def check_provider(provider):
    provider = provider_id(provider)
    executable = locate(provider)
    command = executable_command(executable, provider)
    check = subprocess.run(command + ['--version'], capture_output=True, text=True,
                           encoding='utf-8', errors='replace', timeout=20, **hidden_process_options())
    if check.returncode:
        raise RuntimeError(f'{PROVIDERS[provider]["name"]}: startup failed. {check.stderr[-800:]}')
    if provider in {'codex', 'claude'}:
        args = ['login', 'status'] if provider == 'codex' else ['auth', 'status']
        auth = subprocess.run(command + args, capture_output=True, text=True,
                              encoding='utf-8', errors='replace', timeout=20, **hidden_process_options())
        if auth.returncode:
            raise RuntimeError(f'{PROVIDERS[provider]["name"]}: sign in through the wizard and try again.')
    return executable


def arguments(provider, executable, directory, schema):
    command = executable_command(executable, provider)
    directory=Path(directory)
    directories={str(ROOT)}
    manifest_path=directory/'manifest.json'
    if manifest_path.is_file():
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        directories.add(str(directory.parent.parent))
        for item in manifest.get('contexts',[]):
            if item.get('path'):directories.add(str(Path(item['path']).parent))
        for path in manifest.get('existing_figure_assets',{}).values():directories.add(str(Path(path).parent))
    if provider == 'claude':
        return command + ['-p', '--output-format', 'stream-json', '--verbose',
                          '--json-schema', json.dumps(schema, separators=(',', ':')),
                          '--permission-mode', 'dontAsk', '--allowedTools', 'Read,Edit,Write,Bash,Glob,Grep',
                          '--no-session-persistence','--add-dir',*sorted(directories)]
    if provider == 'gemini':
        # Allow the shell for the requested render/compile workflow; managed policies
        # can still deny a tool. Never bypass the CLI permission mechanism globally.
        return command + ['--prompt', 'Execute the complete job supplied on stdin.',
                          '--output-format', 'stream-json', '--approval-mode', 'auto_edit',
                          '--allowed-tools','run_shell_command',
                          *[arg for path in sorted(directories) for arg in ('--include-directories',path)]]
    raise ValueError('Use the existing Codex adapter for codex')


def parse_result(provider, item):
    if item.get('is_error') or item.get('error') or item.get('status') in {'error', 'failed'}:
        raise RuntimeError(f'{PROVIDERS[provider]["name"]}: {item.get("error") or item.get("result") or item}')
    value = item.get('structured_output') if provider == 'claude' else item.get('response')
    if value is None:
        value = item.get('result') if provider == 'claude' else None
    if isinstance(value, str):
        value = re.sub(r'^```(?:json)?\s*|\s*```$', '', value.strip())
        value = json.loads(value)
    if not isinstance(value, dict):
        raise ValueError(f'{PROVIDERS[provider]["name"]}: no complete JSON result received')
    return value


def validate_schema(value, schema, path='$'):
    """Validate the schema subset used by both Studio output contracts."""
    kinds = schema.get('type', [])
    if isinstance(kinds, str):
        kinds = [kinds]
    actual = ('null' if value is None else 'boolean' if type(value) is bool else
              'integer' if type(value) is int else 'number' if type(value) is float else
              'string' if isinstance(value, str) else 'array' if isinstance(value, list) else
              'object' if isinstance(value, dict) else 'unknown')
    if kinds and actual not in kinds and not (actual == 'integer' and 'number' in kinds):
        raise ValueError(f'{path}: invalid JSON type ({actual})')
    if 'enum' in schema and value not in schema['enum']:
        raise ValueError(f'{path}: unexpected value')
    if isinstance(value, dict):
        properties = schema.get('properties', {})
        if any(key not in value for key in schema.get('required', [])):
            raise ValueError(f'{path}: missing required fields')
        if schema.get('additionalProperties') is False and set(value) - set(properties):
            raise ValueError(f'{path}: unexpected additional fields')
        for key in value.keys() & properties.keys():
            validate_schema(value[key], properties[key], path + '.' + key)
    if isinstance(value, list):
        if len(value) < schema.get('minItems', 0):
            raise ValueError(f'{path}: incomplete list')
        for index, child in enumerate(value):
            validate_schema(child, schema.get('items', {}), f'{path}[{index}]')


def run_provider(provider, executable, directory, prompt, cancel, event, *, output_schema,
                 process_factory=subprocess.Popen, timeout=3600):
    import lecture_pipeline as pipeline
    import review_editor as editor
    provider = provider_id(provider)
    directory = Path(directory)
    editor.write_json(directory / 'output-schema.json', output_schema)
    prompt += ('\n\n## CLI output adapter\nRead output-schema.json in this working directory. '
               'Return ONLY the complete JSON object conforming to it, without Markdown fences. '
               'Use the available file/image read and shell tools in place of Codex-specific tool names. '
               'When a local tool is denied, do not claim the denied verification succeeded.\n')
    editor.atomic_text(directory / 'prompt.md', prompt)
    command = arguments(provider, executable, directory, output_schema)
    environment = os.environ.copy()
    for name in ('CODEX_THREAD_ID', 'CLAUDECODE'):
        environment.pop(name, None)
    options = hidden_process_options()
    if os.name != 'nt':
        options['start_new_session'] = True
    process = process_factory(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, encoding='utf-8', errors='replace', bufsize=1,
                              cwd=directory, env=environment, **options)
    lines = queue.Queue()
    def read(stream, name):
        try:
            for line in stream:
                lines.put((name, line))
        finally:
            lines.put((name, None))
    readers = []
    for name, stream in [('stdout', process.stdout), ('stderr', process.stderr)]:
        thread = threading.Thread(target=read, args=(stream, name), daemon=True)
        thread.start(); readers.append(thread)
    def write_prompt():
        try:
            process.stdin.write(prompt)
            process.stdin.close()
        except (OSError, ValueError):
            pass
    writer = threading.Thread(target=write_prompt, daemon=True); writer.start()
    done = set(); final = None; chunks = []; error = ''; started = time.monotonic()
    try:
        with (directory / f'{provider}-events.jsonl').open('w', encoding='utf-8') as log:
            while len(done) < 2 or process.poll() is None:
                pipeline.engine.check_cancelled(cancel)
                if time.monotonic() - started > timeout:
                    raise TimeoutError(f'{PROVIDERS[provider]["name"]}: time limit exceeded; inputs have been preserved.')
                try:
                    name, line = lines.get(timeout=.2)
                except queue.Empty:
                    continue
                if line is None:
                    done.add(name); continue
                log.write(line); log.flush()
                if name == 'stderr':
                    error = (error + line)[-5000:]; continue
                try:
                    item = json.loads(line)
                except ValueError:
                    continue
                kind = item.get('type')
                if kind == 'result':
                    final = item
                elif provider == 'gemini' and kind == 'message' and item.get('role') == 'assistant':
                    chunks.append(item.get('content', ''))
                elif kind in {'tool_use', 'tool_result', 'assistant'}:
                    event('activity', f'{PROVIDERS[provider]["name"]} is processing the materials…')
                elif kind == 'error':
                    error = str(item)[-5000:]
            if process.wait(timeout=10) or final is None:
                raise RuntimeError(f'{PROVIDERS[provider]["name"]}: incomplete job. {error[-1800:]}')
        if provider == 'gemini':
            final = {**final, 'response': ''.join(chunks)}
        result = parse_result(provider, final)
        validate_schema(result, output_schema)
        editor.write_json(directory / f'{provider}-result.json', result)
        return result
    finally:
        if process.poll() is None:
            if os.name != 'nt':
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            pipeline.terminate_process(process)
        writer.join(3)
        for reader in readers:
            reader.join(3)
        for stream in (process.stdout, process.stderr):
            stream.close()
