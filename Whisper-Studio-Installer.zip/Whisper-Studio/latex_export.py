"""Frozen, independently cancellable HTML-to-LaTeX jobs for Whisper Studio."""
from __future__ import annotations

import hashlib
import json
import logging
import platform
import queue
import re
import shutil
import subprocess
import sys
import threading
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from filelock import FileLock

import lecture_pipeline as pipeline
import review_editor as editor
from latex_settings import load_settings, metadata_tex, normalize_settings, save_settings
from lecture_markup import structure

ROOT = Path(__file__).resolve().parent
LOGGER = logging.getLogger(__name__)
CHECKS = ('text_coverage', 'structure_preserved', 'placeholders_preserved',
          'references_resolved', 'compiled', 'visual_review', 'inputs_unchanged')
RESULT_SCHEMA = {'type': 'object', 'additionalProperties': False,
                 'properties': {'status': {'type': 'string', 'enum': ['completed', 'partial']},
                                'message': {'type': 'string'}},
                 'required': ['status', 'message']}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inside(folder, relative):
    path = (Path(folder) / relative).resolve()
    if not path.is_relative_to(Path(folder).resolve()):
        raise ValueError(f'Percorso esterno al progetto: {relative}')
    return path


def project_body(html):
    matches = re.findall(r'<article\b(?=[^>]*\bid\s*=\s*[\"\']lecture-document[\"\'])[^>]*>'
                         r'([\s\S]*?)</article\s*>', html, re.I)
    if len(matches) != 1:
        raise ValueError('Non trovo un unico corpo della lezione nell’HTML salvato')
    return matches[0]


def export_config(config):
    folder_text = str(config.get('folder') or '').strip()
    if not folder_text:
        raise ValueError('Scegli la cartella della lezione')
    folder = Path(folder_text).expanduser().resolve()
    if not (folder / 'lecture_project.json').is_file() or not (folder / 'lecture.html').is_file():
        raise ValueError('Per esportare serve una lezione con HTML e progetto già salvati')
    settings = normalize_settings(config.get('latex') if 'latex' in config else load_settings(folder))
    return {'folder': str(folder), 'latex': settings,
            'ai_provider': pipeline.provider_id(config.get('ai_provider'))}


def available_latex(folder):
    """Prefer the published result; also discover earlier manually produced exports."""
    folder = Path(folder).resolve()
    index = folder / '.whisper-studio/latest-latex.json'
    if index.is_file():
        try:
            data = json.loads(index.read_text(encoding='utf-8'))
            run = Path(data['run'])
            if not run.is_absolute():run = folder / run
            run = run.resolve()
            if run.is_relative_to(folder):
                for name in ('main.pdf', 'main.tex'):
                    target = (run / name).resolve()
                    if target.is_relative_to(folder) and target.is_file():return target
        except (OSError, ValueError, KeyError, TypeError):
            pass
    latex = folder / 'latex'
    candidates = []
    if latex.is_dir():
        for path in [latex / 'main.pdf', latex / 'main.tex', *latex.glob('*/main.pdf'), *latex.glob('*/main.tex')]:
            try:
                if path.resolve().is_relative_to(folder) and path.is_file():
                    candidates.append((path.stat().st_mtime_ns, path))
            except OSError:
                continue
    if not candidates:return None
    run = max(candidates, key=lambda item:item[0])[1].parent
    for name in ('main.pdf', 'main.tex'):
        target = (run / name).resolve()
        if target.is_relative_to(folder) and target.is_file():return target
    return None


def prepare_export(config):
    """No Codex call, no ASR and no rewrite of the approved document."""
    config = export_config(config)
    folder = Path(config['folder'])
    save_settings(folder, config['latex'])
    with editor.LOCK, FileLock(folder / '.project-save.lock', timeout=10):
        project = json.loads((folder / 'lecture_project.json').read_text(encoding='utf-8'))
        document_structure=structure(project,validate=True)
        html = (folder / 'lecture.html').read_text(encoding='utf-8')
        if editor.clean_html(project_body(html)).strip() != editor.clean_html(project['document']['html']).strip():
            raise ValueError('HTML e progetto contengono testi diversi. Sincronizza la versione approvata prima dell’esportazione; nessun testo è stato riscritto.')
        markdown = folder / 'lecture_notes.md'
        if markdown.is_file() and markdown.read_text(encoding='utf-8') != project['document']['markdown']:
            raise ValueError('Il Markdown è diverso dal progetto: riconcilia la versione approvata prima dell’esportazione')
        settings = normalize_settings(config['latex'], title=project.get('title'))
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
        run = folder / 'latex' / ('export-' + stamp)
        snapshot = run / 'source-snapshot'
        snapshot.mkdir(parents=True)
        inputs = []

        def copy_source(source, relative):
            source = Path(source).resolve()
            target = inside(snapshot, relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            before = digest(source)
            shutil.copyfile(source, target)
            if digest(source) != before or digest(target) != before:
                raise ValueError(f'Un input è cambiato durante la copia: {source.name}')
            inputs.append({'original': str(source), 'snapshot': target.relative_to(run).as_posix(), 'sha256': before})

        for name in ('lecture_project.json', 'lecture.html', 'lecture_notes.md',
                     'figure_notes.md', 'latex_handoff.json', '.whisper-studio/latex-settings.json'):
            if (folder / name).is_file():
                copy_source(folder / name, name)
        for figure in project.get('figures', []):
            source = inside(folder, figure['asset'])
            if not source.is_file():
                raise ValueError(f'Asset mancante per {figure["id"]}: {figure["asset"]}')
            copy_source(source, figure['asset'])

        # Retain prepared source pages for figure corrections and deferred captions.
        # Do not duplicate entire slide decks or audio into every export.
        support = []
        needs_context = (any(n.get('status') == 'pending' for f in project.get('figures', []) for n in f.get('notes', []))
                         or any(f.get('caption_mode')=='generate' for f in project.get('figures', [])))
        if needs_context:
            for role in ('clean_slides', 'annotated_slides', 'whiteboard'):
                context = project.get('sources', {}).get(role, {})
                for item in context.get('pages', []):
                    if not item.get('image'):
                        continue
                    source = Path(item['image'])
                    if not source.is_absolute():
                        source = folder / source
                    if source.is_file():
                        name = f'support/{role}/page-{int(item["page"]):03d}{source.suffix.lower()}'
                        copy_source(source, name)
                        support.append({'role': role, 'page': item['page'], 'snapshot': 'source-snapshot/' + name})

    template = run / 'template'
    template.mkdir()
    for name in ('lecture-template.tex', 'ISTRUZIONI.md'):
        shutil.copyfile(ROOT / 'output/latex-template' / name, template / name)
    (run / 'tools').mkdir()
    shutil.copyfile(ROOT / 'latex_assets.py', run / 'tools/latex_assets.py')
    editor.atomic_text(run / 'metadata.tex', metadata_tex(settings))
    editor.atomic_text(run / 'base-prompt.md', (ROOT / 'PROMPT_HTML_TO_LATEX.md').read_text(encoding='utf-8'))
    contract = {'schema_version': 1, 'created_at': editor.now(), 'project_id': project.get('project_id'),
                'revision': project.get('revision'), 'title': project.get('title'), 'latex': settings,
                'structure': document_structure,
                'authoritative_project': 'source-snapshot/lecture_project.json',
                'approved_html': 'source-snapshot/lecture.html', 'template': 'template/lecture-template.tex',
                'metadata_file': 'metadata.tex', 'inputs': inputs, 'support_pages': support,
                'python': sys.executable,
                'svg_converter': 'tools/latex_assets.py',
                'pdflatex': shutil.which('pdflatex'), 'pdf_renderer': shutil.which('pdftoppm'),
                'runtime': {'python': sys.version, 'platform': platform.platform()},
                'application': {name: digest(ROOT / name) for name in
                                ('latex_export.py', 'latex_settings.py', 'lecture_pipeline.py')},
                'missing_metadata': [key for key in ('course', 'general_topic', 'lecture_title', 'lecture_date', 'lecturer', 'lecture_number') if not settings[key]],
                'protected': []}
    for name in ('metadata.tex', 'base-prompt.md', 'template/lecture-template.tex', 'template/ISTRUZIONI.md', 'tools/latex_assets.py'):
        contract['protected'].append({'path': name, 'sha256': digest(run / name)})
    editor.write_json(run / 'export-input.json', contract)
    prompt = build_export_prompt(run)
    editor.atomic_text(run / 'prompt.md', prompt)
    editor.write_json(run / 'prepared-integrity.json', {'files': [
        {'path': name, 'sha256': digest(run / name)} for name in ('export-input.json', 'prompt.md')]})
    return run


def build_export_prompt(run):
    return (Path(run) / 'base-prompt.md').read_text(encoding='utf-8') + '''

## Contratto di questa esecuzione automatica

Questa sezione risolve i parametri iniziali del prompt generico. Leggi
`export-input.json` nella directory corrente. Il progetto e l'HTML approvati,
il template, i metadati e gli input sono quelli lì indicati. I percorsi relativi
sono relativi a questa directory, che è anche l'unica destinazione di lavoro.
Non serve una nuova trascrizione e non va cambiato alcun file originale.
Le indicazioni aggiuntive sono in `latex.instructions`; trattale come richieste
di esportazione soggette al vincolo di conservazione del testo. Lo Scope è
`latex.scope` e l'indice è controllato da `latex.include_toc`.

Produci `main.tex`, `main.pdf` quando compilabile, `figures/`,
`conversion_manifest.json`, `conversion_report.md`, `README-compilazione.md`.
Per convertire SVG in PDF vettoriali puoi usare il Python e `svg_converter`
indicati nel contratto: esegui lo script con `--help` per gli argomenti.
Per confrontare una figura con le fonti usa le `support_pages` congelate.
Se non bastano, documenta la nota irrisolta, senza inventare o recuperare
informazioni dalle note editoriali escluse. Non riapplicare note `done`.

Non compilare i placeholder di questo prompt generico come se fossero dati.
Non modificare `metadata.tex`: includilo in `main.tex` subito dopo documentclass.
Il corpo deve provenire dalla versione congelata, filtrata secondo il punto 3.
La sezione finale lecture-supplements e le sue citazioni slide-citation sono
contenuto approvato da conservare dopo le sezioni della trascrizione; non sono
note editoriali o righe Sources da escludere. Non creare nuove integrazioni.
Non riaprire né rigenerare l'HTML, non correggere il testo e non rimuovere figure
per sistemare l'impaginazione. Preserva i segnaposto da completare manualmente.

Il manifest deve avere l'oggetto `verification` con tutti i booleani previsti
dal prompt. Compila e verifica solo se gli strumenti sono disponibili. Lo ZIP
viene costruito dall'app: non includere file esterni né produrre un archivio
ricorsivo della cartella. Termina con il JSON richiesto dallo schema:
`status` è `completed` solo se tutte le verifiche sono riuscite e il PDF esiste;
altrimenti `partial`. `message` descrive brevemente risultato e limiti in italiano.
'''


def verify_inputs(run):
    run = Path(run)
    integrity = json.loads((run / 'prepared-integrity.json').read_text(encoding='utf-8'))
    for item in integrity['files']:
        if digest(inside(run, item['path'])) != item['sha256']:
            raise ValueError('Il contratto o il prompt congelato è stato modificato')
    contract = json.loads((run / 'export-input.json').read_text(encoding='utf-8'))
    for item in contract['protected']:
        if digest(inside(run, item['path'])) != item['sha256']:
            raise ValueError(f'Input di esportazione modificato: {item["path"]}')
    for item in contract['inputs']:
        if digest(inside(run, item['snapshot'])) != item['sha256'] or digest(item['original']) != item['sha256']:
            raise ValueError('Una sorgente è cambiata durante l’esportazione. Il risultato rimane separato: ripeti sulla versione aggiornata.')
    return contract


def finish_export(run, result, *, event=None):
    run = Path(run)
    if event:event('phase', {'step': 3, 'message': 'LaTeX · verifica dei risultati e delle sorgenti'})
    if not isinstance(result, dict) or result.get('status') not in ('completed', 'partial'):
        raise ValueError('Risultato LaTeX non valido')
    verify_inputs(run)
    for name in ('main.tex', 'conversion_manifest.json', 'conversion_report.md', 'README-compilazione.md'):
        path = inside(run, name)
        if not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f'Esportazione incompleta: manca {name}')
    manifest = json.loads((run / 'conversion_manifest.json').read_text(encoding='utf-8'))
    tex = re.sub(r'(?<!\\)%[^\n]*', '', (run / 'main.tex').read_text(encoding='utf-8'))
    if not re.search(r'\\input\s*\{metadata\.tex\}', tex) or '\\MakeLectureTitle' not in tex:
        raise ValueError('Il documento LaTeX non usa i metadati e la testata del progetto')
    contract = json.loads((run / 'export-input.json').read_text(encoding='utf-8'))
    if bool(re.search(r'\\tableofcontents\b', tex)) != contract['latex']['include_toc']:
        raise ValueError('Il documento LaTeX non rispetta l’opzione dell’indice')
    checks = manifest.get('verification', {})
    complete = all(checks.get(key) is True for key in CHECKS)
    pdf = inside(run, 'main.pdf')
    has_pdf = pdf.is_file() and pdf.read_bytes().startswith(b'%PDF-')
    if has_pdf:
        from pypdf import PdfReader
        if len(PdfReader(pdf).pages) < 1:
            raise ValueError('Il PDF esportato non contiene pagine')
    if result['status'] == 'completed' and not (complete and has_pdf):
        raise ValueError('Codex ha dichiarato completata un’esportazione priva del PDF o delle verifiche richieste')
    archive = run / 'lecture-latex.zip'
    if event:event('phase', {'step': 4, 'message': 'LaTeX · preparazione dell’archivio scaricabile'})
    # Include compilation inputs and reproducibility records, never logs or nested zips.
    names = ['main.tex', 'metadata.tex', 'conversion_manifest.json', 'conversion_report.md',
             'README-compilazione.md', 'export-input.json', 'prepared-integrity.json', 'prompt.md', 'base-prompt.md']
    if has_pdf:
        names.append('main.pdf')
    for name in ('codex-invocation.json', 'output-schema.json', 'export-result.json'):
        if (run / name).is_file():
            names.append(name)
    for directory in ('figures', 'template', 'source-snapshot', 'tools'):
        names += [p.relative_to(run).as_posix() for p in (run / directory).rglob('*') if p.is_file()]
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as packed:
        for name in sorted(set(names)):
            packed.write(inside(run, name), name)
    return {'run': str(run), 'pdf': str(pdf) if has_pdf else None, 'zip': str(archive),
            'complete': result['status'] == 'completed' and complete, 'message': result.get('message', '')}


class LatexPipeline:
    def __init__(self, *, codex_runner=None):
        self.events = queue.Queue()
        self.cancel_event = threading.Event()
        self.thread = None
        self.codex_runner = codex_runner

    @property
    def busy(self):
        return self.thread is not None and self.thread.is_alive()

    def emit(self, kind, value):
        self.events.put((kind, value))

    def start(self, config):
        if self.busy:
            raise RuntimeError('Un’esportazione LaTeX è già in corso')
        config = export_config(config)
        self.cancel_event.clear()
        self.thread = threading.Thread(target=self._worker, args=(config,), name='whisper-latex', daemon=True)
        self.thread.start()

    def cancel(self):
        self.cancel_event.set()

    def shutdown(self):
        self.cancel()

    def _worker(self, config):
        folder = Path(config['folder'])
        run = None

        def state(status, message):
            editor.write_json(folder / '.whisper-studio/last-latex-job.json',
                              {'run': str(run) if run else None, 'status': status,
                               'message': message, 'updated_at': editor.now()})
        try:
            (folder / '.whisper-studio').mkdir(exist_ok=True)
            with FileLock(folder / '.whisper-studio/run.lock', timeout=0):
                self.emit('phase', {'step': 1, 'message': 'LaTeX · congelo la versione salvata e i metadati'})
                run = prepare_export(config)
                state('running', 'Esportazione HTML → LaTeX')
                provider = config.get('ai_provider','codex')
                executable = pipeline.check_assistant(provider)
                pipeline.engine.check_cancelled(self.cancel_event)
                invocation = {'executable': executable, 'provider': provider,
                    'command': (pipeline.codex_arguments(executable, run, run / 'output-schema.json', run / 'codex-result.json')
                                if provider=='codex' else pipeline.ai_providers.arguments(provider,executable,run,RESULT_SCHEMA))}
                try:
                    probe = subprocess.run(pipeline.ai_providers.executable_command(executable,provider)+['--version'], capture_output=True, text=True,
                                           timeout=10, **pipeline.engine.hidden_process_options())
                    invocation['version'] = probe.stdout.strip() if probe.returncode == 0 else None
                except (OSError, subprocess.TimeoutExpired):
                    invocation['version'] = None
                editor.write_json(run / 'codex-invocation.json', invocation)
                prompt = (run / 'prompt.md').read_text(encoding='utf-8')
                self.emit('phase', {'step': 2, 'message': 'LaTeX · conversione, compilazione e controllo delle pagine'})
                self.emit('activity', pipeline.PROVIDERS[provider]['name']+' · conversione del testo approvato, figure, compilazione e controllo pagine')
                if self.codex_runner is None and provider=='codex':
                    result = pipeline.run_codex(executable, run, prompt, self.cancel_event, self.emit, output_schema=RESULT_SCHEMA)
                elif self.codex_runner is None:
                    result = pipeline.ai_providers.run_provider(provider,executable,run,prompt,self.cancel_event,self.emit,output_schema=RESULT_SCHEMA)
                else:
                    result = self.codex_runner(executable, run, prompt, self.cancel_event, self.emit)
                editor.write_json(run / 'export-result.json', result)
                pipeline.engine.check_cancelled(self.cancel_event)
                output = finish_export(run, result, event=self.emit)
                state('completed' if output['complete'] else 'partial', output['message'])
                editor.write_json(folder / '.whisper-studio/latest-latex.json', output)
                self.emit('phase', {'step': 5, 'message': 'LaTeX · esportazione pronta' if output['complete'] else 'LaTeX · esportazione parziale disponibile'})
                self.emit('latex-completed', output)
        except pipeline.engine.TranscriptionCancelled:
            if run:
                state('cancelled', 'Esportazione annullata; originali conservati')
            self.emit('cancelled', {'message': 'Esportazione LaTeX annullata.', 'run': str(run) if run else None})
        except Exception as exc:
            LOGGER.exception('LaTeX export failed')
            if run:
                state('failed', str(exc))
            self.emit('failed', {'message': str(exc), 'run': str(run) if run else None})
