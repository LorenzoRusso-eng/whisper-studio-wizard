"""Frozen, independently cancellable HTML-to-LaTeX jobs for Whisper Studio."""
from __future__ import annotations

import hashlib
import json
import logging
import platform
import queue
import re
import shutil
import subprocess
import sys
import threading
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from filelock import FileLock

import lecture_pipeline as pipeline
import review_editor as editor
from latex_settings import load_settings, metadata_tex, normalize_settings, save_settings
from lecture_markup import structure

ROOT = Path(__file__).resolve().parent
LOGGER = logging.getLogger(__name__)
CHECKS = ('text_coverage', 'structure_preserved', 'placeholders_preserved',
          'references_resolved', 'compiled', 'visual_review', 'inputs_unchanged')
RESULT_SCHEMA = {'type': 'object', 'additionalProperties': False,
                 'properties': {'status': {'type': 'string', 'enum': ['completed', 'partial']},
                                'message': {'type': 'string'}},
                 'required': ['status', 'message']}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inside(folder, relative):
    path = (Path(folder) / relative).resolve()
    if not path.is_relative_to(Path(folder).resolve()):
        raise ValueError(f'Path outside the project: {relative}')
    return path


def project_body(html):
    matches = re.findall(r'<article\b(?=[^>]*\bid\s*=\s*[\"\']lecture-document[\"\'])[^>]*>'
                         r'([\s\S]*?)</article\s*>', html, re.I)
    if len(matches) != 1:
        raise ValueError('Could not find a single lesson body in the saved HTML')
    return matches[0]


def export_config(config):
    folder_text = str(config.get('folder') or '').strip()
    if not folder_text:
        raise ValueError('Choose the lesson folder')
    folder = Path(folder_text).expanduser().resolve()
    if not (folder / 'lecture_project.json').is_file() or not (folder / 'lecture.html').is_file():
        raise ValueError('Export requires a lesson with saved HTML and project files')
    settings = normalize_settings(config.get('latex') if 'latex' in config else load_settings(folder))
    return {'folder': str(folder), 'latex': settings,
            'ai_provider': pipeline.provider_id(config.get('ai_provider'))}


def available_latex(folder):
    """Prefer the published result; also discover earlier manually produced exports."""
    folder = Path(folder).resolve()
    index = folder / '.whisper-studio/latest-latex.json'
    if index.is_file():
        try:
            data = json.loads(index.read_text(encoding='utf-8'))
            run = Path(data['run'])
            if not run.is_absolute():run = folder / run
            run = run.resolve()
            if run.is_relative_to(folder):
                for name in ('main.pdf', 'main.tex'):
                    target = (run / name).resolve()
                    if target.is_relative_to(folder) and target.is_file():return target
        except (OSError, ValueError, KeyError, TypeError):
            pass
    latex = folder / 'latex'
    candidates = []
    if latex.is_dir():
        for path in [latex / 'main.pdf', latex / 'main.tex', *latex.glob('*/main.pdf'), *latex.glob('*/main.tex')]:
            try:
                if path.resolve().is_relative_to(folder) and path.is_file():
                    candidates.append((path.stat().st_mtime_ns, path))
            except OSError:
                continue
    if not candidates:return None
    run = max(candidates, key=lambda item:item[0])[1].parent
    for name in ('main.pdf', 'main.tex'):
        target = (run / name).resolve()
        if target.is_relative_to(folder) and target.is_file():return target
    return None


def prepare_export(config):
    """No Codex call, no ASR and no rewrite of the approved document."""
    config = export_config(config)
    folder = Path(config['folder'])
    save_settings(folder, config['latex'])
    with editor.LOCK, FileLock(folder / '.project-save.lock', timeout=10):
        project = json.loads((folder / 'lecture_project.json').read_text(encoding='utf-8'))
        document_structure=structure(project,validate=True)
        html = (folder / 'lecture.html').read_text(encoding='utf-8')
        if editor.clean_html(project_body(html)).strip() != editor.clean_html(project['document']['html']).strip():
            raise ValueError('The HTML and project contain different text. Synchronize the approved version before exporting; no text has been rewritten.')
        markdown = folder / 'lecture_notes.md'
        if markdown.is_file() and markdown.read_text(encoding='utf-8') != project['document']['markdown']:
            raise ValueError('The Markdown differs from the project: reconcile the approved version before exporting')
        settings = normalize_settings(config['latex'], title=project.get('title'))
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
        run = folder / 'latex' / ('export-' + stamp)
        snapshot = run / 'source-snapshot'
        snapshot.mkdir(parents=True)
        inputs = []

        def copy_source(source, relative):
            source = Path(source).resolve()
            target = inside(snapshot, relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            before = digest(source)
            shutil.copyfile(source, target)
            if digest(source) != before or digest(target) != before:
                raise ValueError(f'An input changed while being copied: {source.name}')
            inputs.append({'original': str(source), 'snapshot': target.relative_to(run).as_posix(), 'sha256': before})

        for name in ('lecture_project.json', 'lecture.html', 'lecture_notes.md',
                     'figure_notes.md', 'latex_handoff.json', '.whisper-studio/latex-settings.json'):
            if (folder / name).is_file():
                copy_source(folder / name, name)
        for figure in project.get('figures', []):
            source = inside(folder, figure['asset'])
            if not source.is_file():
                raise ValueError(f'Missing asset for {figure["id"]}: {figure["asset"]}')
            copy_source(source, figure['asset'])

        # Retain prepared source pages for figure corrections and deferred captions.
        # Do not duplicate entire slide decks or audio into every export.
        support = []
        needs_context = (any(n.get('status') == 'pending' for f in project.get('figures', []) for n in f.get('notes', []))
                         or any(f.get('caption_mode')=='generate' for f in project.get('figures', [])))
        if needs_context:
            for role in ('clean_slides', 'annotated_slides', 'whiteboard'):
                context = project.get('sources', {}).get(role, {})
                for item in context.get('pages', []):
                    if not item.get('image'):
                        continue
                    source = Path(item['image'])
                    if not source.is_absolute():
                        source = folder / source
                    if source.is_file():
                        name = f'support/{role}/page-{int(item["page"]):03d}{source.suffix.lower()}'
                        copy_source(source, name)
                        support.append({'role': role, 'page': item['page'], 'snapshot': 'source-snapshot/' + name})

    template = run / 'template'
    template.mkdir()
    for name in ('lecture-template.tex', 'README.md'):
        shutil.copyfile(ROOT / 'output/latex-template' / name, template / name)
    (run / 'tools').mkdir()
    shutil.copyfile(ROOT / 'latex_assets.py', run / 'tools/latex_assets.py')
    editor.atomic_text(run / 'metadata.tex', metadata_tex(settings))
    editor.atomic_text(run / 'base-prompt.md', (ROOT / 'PROMPT_HTML_TO_LATEX.md').read_text(encoding='utf-8'))
    contract = {'schema_version': 1, 'created_at': editor.now(), 'project_id': project.get('project_id'),
                'revision': project.get('revision'), 'title': project.get('title'), 'latex': settings,
                'structure': document_structure,
                'authoritative_project': 'source-snapshot/lecture_project.json',
                'approved_html': 'source-snapshot/lecture.html', 'template': 'template/lecture-template.tex',
                'metadata_file': 'metadata.tex', 'inputs': inputs, 'support_pages': support,
                'python': sys.executable,
                'svg_converter': 'tools/latex_assets.py',
                'pdflatex': shutil.which('pdflatex'), 'pdf_renderer': shutil.which('pdftoppm'),
                'runtime': {'python': sys.version, 'platform': platform.platform()},
                'application': {name: digest(ROOT / name) for name in
                                ('latex_export.py', 'latex_settings.py', 'lecture_pipeline.py')},
                'missing_metadata': [key for key in ('course', 'general_topic', 'lecture_title', 'lecture_date', 'lecturer', 'lecture_number') if not settings[key]],
                'protected': []}
    for name in ('metadata.tex', 'base-prompt.md', 'template/lecture-template.tex', 'template/README.md', 'tools/latex_assets.py'):
        contract['protected'].append({'path': name, 'sha256': digest(run / name)})
    editor.write_json(run / 'export-input.json', contract)
    prompt = build_export_prompt(run)
    editor.atomic_text(run / 'prompt.md', prompt)
    editor.write_json(run / 'prepared-integrity.json', {'files': [
        {'path': name, 'sha256': digest(run / name)} for name in ('export-input.json', 'prompt.md')]})
    return run


def build_export_prompt(run):
    return (Path(run) / 'base-prompt.md').read_text(encoding='utf-8') + "\n\n## Contract for this automated execution\n\nThis section resolves the generic prompt's initial parameters. Read\n`export-input.json` in the current directory. Use the approved project and HTML,\ntemplate, metadata, and inputs identified there. Relative paths are relative\nto this directory, which is also the only output destination.\nNo new transcription is needed. Do not change any original file.\nAdditional instructions are in `latex.instructions`; apply them as export\nrequirements subject to preserving the approved text. Scope is `latex.scope`,\nand the table of contents is controlled by `latex.include_toc`.\n\nProduce `main.tex`, `main.pdf` when compilable, `figures/`,\n`conversion_manifest.json`, `conversion_report.md`, and `README-compilation.md`.\nTo convert SVG to vector PDF, use the Python executable and `svg_converter`\nspecified in the contract; run the script with `--help` for its arguments.\nUse the frozen `support_pages` to compare a figure against its sources.\nIf they are insufficient, document the unresolved note without inventing\ninformation or recovering it from excluded editorial notes. Do not reapply\nnotes marked `done`.\n\nDo not fill the generic prompt's placeholders as if they were source data.\nDo not change `metadata.tex`; include it in `main.tex` immediately after\ndocumentclass. The body must come from the frozen version, filtered according\nto section 3. The final lecture-supplements section and its slide-citation\nreferences are approved content to preserve after the transcript sections;\nthey are not editorial notes or technical Sources lines to exclude. Do not\ncreate new supplements. Do not reopen or regenerate the HTML, correct the\ntext, or remove figures to fix the layout. Preserve placeholders intended\nfor manual completion.\n\nThe manifest must contain `verification` with all booleans required by the\nprompt. Compile and verify only when the tools are available. The application\nbuilds the ZIP: do not include external files or recursively archive the\nfolder. Finish with the JSON required by the schema: `status` is `completed`\nonly when every check has succeeded and the PDF exists; otherwise use\n`partial`. The `message` briefly describes the result and limitations in English.\n"


def verify_inputs(run):
    run = Path(run)
    integrity = json.loads((run / 'prepared-integrity.json').read_text(encoding='utf-8'))
    for item in integrity['files']:
        if digest(inside(run, item['path'])) != item['sha256']:
            raise ValueError('The frozen contract or prompt has been modified')
    contract = json.loads((run / 'export-input.json').read_text(encoding='utf-8'))
    for item in contract['protected']:
        if digest(inside(run, item['path'])) != item['sha256']:
            raise ValueError(f'Export input modified: {item["path"]}')
    for item in contract['inputs']:
        if digest(inside(run, item['snapshot'])) != item['sha256'] or digest(item['original']) != item['sha256']:
            raise ValueError('A source changed during export. The result is kept separately; export again from the updated version.')
    return contract


def finish_export(run, result, *, event=None):
    run = Path(run)
    if event:event('phase', {'step': 3, 'message': 'LaTeX · checking results and sources'})
    if not isinstance(result, dict) or result.get('status') not in ('completed', 'partial'):
        raise ValueError('Invalid LaTeX result')
    verify_inputs(run)
    for name in ('main.tex', 'conversion_manifest.json', 'conversion_report.md', 'README-compilation.md'):
        path = inside(run, name)
        if not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f'Incomplete export: missing {name}')
    manifest = json.loads((run / 'conversion_manifest.json').read_text(encoding='utf-8'))
    tex = re.sub(r'(?<!\\)%[^\n]*', '', (run / 'main.tex').read_text(encoding='utf-8'))
    if not re.search(r'\\input\s*\{metadata\.tex\}', tex) or '\\MakeLectureTitle' not in tex:
        raise ValueError('The LaTeX document does not use the project metadata and header')
    contract = json.loads((run / 'export-input.json').read_text(encoding='utf-8'))
    if bool(re.search(r'\\tableofcontents\b', tex)) != contract['latex']['include_toc']:
        raise ValueError('The LaTeX document does not respect the table-of-contents option')
    checks = manifest.get('verification', {})
    complete = all(checks.get(key) is True for key in CHECKS)
    pdf = inside(run, 'main.pdf')
    has_pdf = pdf.is_file() and pdf.read_bytes().startswith(b'%PDF-')
    if has_pdf:
        from pypdf import PdfReader
        if len(PdfReader(pdf).pages) < 1:
            raise ValueError('The exported PDF contains no pages')
    if result['status'] == 'completed' and not (complete and has_pdf):
        raise ValueError('The assistant reported a completed export without a PDF or the required checks')
    archive = run / 'lecture-latex.zip'
    if event:event('phase', {'step': 4, 'message': 'LaTeX · preparing the downloadable archive'})
    # Include compilation inputs and reproducibility records, never logs or nested zips.
    names = ['main.tex', 'metadata.tex', 'conversion_manifest.json', 'conversion_report.md',
             'README-compilation.md', 'export-input.json', 'prepared-integrity.json', 'prompt.md', 'base-prompt.md']
    if has_pdf:
        names.append('main.pdf')
    for name in ('codex-invocation.json', 'output-schema.json', 'export-result.json'):
        if (run / name).is_file():
            names.append(name)
    for directory in ('figures', 'template', 'source-snapshot', 'tools'):
        names += [p.relative_to(run).as_posix() for p in (run / directory).rglob('*') if p.is_file()]
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as packed:
        for name in sorted(set(names)):
            packed.write(inside(run, name), name)
    return {'run': str(run), 'pdf': str(pdf) if has_pdf else None, 'zip': str(archive),
            'complete': result['status'] == 'completed' and complete, 'message': result.get('message', '')}


class LatexPipeline:
    def __init__(self, *, codex_runner=None):
        self.events = queue.Queue()
        self.cancel_event = threading.Event()
        self.thread = None
        self.codex_runner = codex_runner

    @property
    def busy(self):
        return self.thread is not None and self.thread.is_alive()

    def emit(self, kind, value):
        self.events.put((kind, value))

    def start(self, config):
        if self.busy:
            raise RuntimeError('A LaTeX export is already running')
        config = export_config(config)
        self.cancel_event.clear()
        self.thread = threading.Thread(target=self._worker, args=(config,), name='whisper-latex', daemon=True)
        self.thread.start()

    def cancel(self):
        self.cancel_event.set()

    def shutdown(self):
        self.cancel()

    def _worker(self, config):
        folder = Path(config['folder'])
        run = None

        def state(status, message):
            editor.write_json(folder / '.whisper-studio/last-latex-job.json',
                              {'run': str(run) if run else None, 'status': status,
                               'message': message, 'updated_at': editor.now()})
        try:
            (folder / '.whisper-studio').mkdir(exist_ok=True)
            with FileLock(folder / '.whisper-studio/run.lock', timeout=0):
                self.emit('phase', {'step': 1, 'message': 'LaTeX · freezing the saved version and metadata'})
                run = prepare_export(config)
                state('running', 'HTML → LaTeX export')
                provider = config.get('ai_provider','codex')
                executable = pipeline.check_assistant(provider)
                pipeline.engine.check_cancelled(self.cancel_event)
                invocation = {'executable': executable, 'provider': provider,
                    'command': (pipeline.codex_arguments(executable, run, run / 'output-schema.json', run / 'codex-result.json')
                                if provider=='codex' else pipeline.ai_providers.arguments(provider,executable,run,RESULT_SCHEMA))}
                try:
                    probe = subprocess.run(pipeline.ai_providers.executable_command(executable,provider)+['--version'], capture_output=True, text=True,
                                           timeout=10, **pipeline.engine.hidden_process_options())
                    invocation['version'] = probe.stdout.strip() if probe.returncode == 0 else None
                except (OSError, subprocess.TimeoutExpired):
                    invocation['version'] = None
                editor.write_json(run / 'codex-invocation.json', invocation)
                prompt = (run / 'prompt.md').read_text(encoding='utf-8')
                self.emit('phase', {'step': 2, 'message': 'LaTeX · conversion, compilation, and page review'})
                self.emit('activity', pipeline.PROVIDERS[provider]['name']+' · converting approved text and figures, compiling, and reviewing pages')
                if self.codex_runner is None and provider=='codex':
                    result = pipeline.run_codex(executable, run, prompt, self.cancel_event, self.emit, output_schema=RESULT_SCHEMA)
                elif self.codex_runner is None:
                    result = pipeline.ai_providers.run_provider(provider,executable,run,prompt,self.cancel_event,self.emit,output_schema=RESULT_SCHEMA)
                else:
                    result = self.codex_runner(executable, run, prompt, self.cancel_event, self.emit)
                editor.write_json(run / 'export-result.json', result)
                pipeline.engine.check_cancelled(self.cancel_event)
                output = finish_export(run, result, event=self.emit)
                state('completed' if output['complete'] else 'partial', output['message'])
                editor.write_json(folder / '.whisper-studio/latest-latex.json', output)
                self.emit('phase', {'step': 5, 'message': 'LaTeX · export ready' if output['complete'] else 'LaTeX · partial export available'})
                self.emit('latex-completed', output)
        except pipeline.engine.TranscriptionCancelled:
            if run:
                state('cancelled', 'Export canceled; originals preserved')
            self.emit('cancelled', {'message': 'LaTeX export canceled.', 'run': str(run) if run else None})
        except Exception as exc:
            LOGGER.exception('LaTeX export failed')
            if run:
                state('failed', str(exc))
            self.emit('failed', {'message': str(exc), 'run': str(run) if run else None})
