"""Run the real editor/publisher on an included transcript, offline or with a CLI."""
from __future__ import annotations

import argparse
import json
import queue
import sys
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from studio_runtime import ROOT, PROVIDERS, load_installation, open_path, venv_python, hidden_process_options, configure_progress_style

EXAMPLE=ROOT/'examples/first-lesson'


def new_folder(parent=None):
    folder=Path(parent or ROOT/'demo-output').expanduser().resolve()/('first-lesson-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6])
    folder.mkdir(parents=True,exist_ok=False)
    return folder


def run_live(folder, event=lambda *_:None, *, provider=None, timeout=900):
    import time
    from lecture_pipeline import LecturePipeline
    provider=provider or load_installation().get('ai_provider','codex')
    worker=LecturePipeline();worker.start({'folder':str(folder),'title':'Ohm’s law · Live example','language':'en',
        'transcript':str(EXAMPLE/'transcript.txt'),'transcription_mode':'external','ai_provider':provider})
    started=time.monotonic()
    try:
        while worker.busy or not worker.events.empty():
            if time.monotonic()-started>timeout:raise TimeoutError('AI demo: time limit exceeded')
            try:kind,value=worker.events.get(timeout=.2)
            except queue.Empty:continue
            event(kind,value)
            if kind in {'failed','cancelled'}:raise RuntimeError(value['message'])
        if not (Path(folder)/'lecture.html').is_file():raise RuntimeError('The AI demo did not produce a complete result')
        return Path(folder)
    finally:
        if worker.busy:worker.cancel();worker.thread.join(15)


def run_local(folder, event=lambda *_:None, cancel=None):
    import lecture_pipeline as pipeline
    from lecture_document import publish
    from ai_providers import validate_schema
    import review_editor as editor
    cancel=cancel or threading.Event();folder=Path(folder)
    event('phase',{'step':1,'message':'Importing the sample file'})
    config=pipeline.normalize_config({'folder':str(folder),'title':'Ohm’s law · Guided demo',
                                     'transcript':str(EXAMPLE/'transcript.txt'),'transcription_mode':'external',
                                     'language':'en','device':'cpu'})
    controller=pipeline.LecturePipeline();controller.cancel_event=cancel
    raw,transcript,review=controller.transcript(config,folder/'.whisper-studio')
    pipeline.engine.check_cancelled(cancel)
    event('phase',{'step':2,'message':f'{len(transcript["segments"])} segments imported · Whisper and the second audio pass skipped'})
    draft=json.loads((EXAMPLE/'prepared-result.json').read_text(encoding='utf-8'))
    validate_schema(draft,pipeline.SCHEMA)
    event('phase',{'step':3,'message':'Loading the prepared result · no AI request'})
    technical=folder/'.whisper-studio';editor.write_json(technical/'demo-transcript.json',transcript)
    editor.write_json(technical/'demo-result.json',draft)
    pipeline.engine.check_cancelled(cancel)
    project=publish(folder,draft,transcript,{'selected_files':{'transcript':str(EXAMPLE/'transcript.txt')}})
    editor.write_json(technical/'project.json',config)
    editor.write_json(technical/'demo.json',{'mode':'prepared-offline','live_ai':False,'audio_used':False,
                                           'transcript_segments':len(transcript['segments'])})
    event('phase',{'step':4,'message':'Coverage verified · formula, figure, and editor ready'})
    event('completed',{'folder':str(folder),'project':project,'issues':0})
    return folder


class DemoApp:
    def __init__(self,root):
        import tkinter as tk
        from tkinter import ttk
        self.root=root;self.tk=tk;self.ttk=ttk;self.folder=None;self.controller=None;self.running=False
        self.events=queue.Queue();self.cancel=threading.Event()
        root.title('Whisper Studio · First demo');root.geometry('920x740');root.minsize(780,650)
        style=ttk.Style(root)
        if 'clam' in style.theme_names():style.theme_use('clam')
        style.configure('.',font=('Segoe UI',10));style.configure('TFrame',background='#FFFFFF')
        style.configure('TLabel',background='#FFFFFF',foreground='#20243A');style.configure('TButton',padding=(12,8))
        frame=ttk.Frame(root,padding=26);frame.pack(fill='both',expand=True);frame.columnconfigure(0,weight=1);frame.rowconfigure(4,weight=1)
        ttk.Label(frame,text='Your first lesson, step by step',font=('Segoe UI',22,'bold')).grid(row=0,column=0,sticky='w')
        ttk.Label(frame,text="From a transcript to editable notes · example: Ohm's law",foreground='#66718A').grid(row=1,column=0,sticky='w',pady=(7,18))
        controls=ttk.Frame(frame);controls.grid(row=2,column=0,sticky='ew')
        self.live=tk.BooleanVar(root,value=False)
        ttk.Checkbutton(controls,text='Live AI processing (uses your assistant account and quota)',variable=self.live).pack(side='left')
        self.start_button=ttk.Button(controls,text='Start demo →',command=self.start);self.start_button.pack(side='right')
        self.notice=tk.StringVar(root,value='Local demo: prepared result. Import, validation, and editor creation use the real app; no AI request is made.')
        ttk.Label(frame,textvariable=self.notice,wraplength=840,foreground='#6554D9').grid(row=3,column=0,sticky='w',pady=12)
        self.notebook=ttk.Notebook(frame);self.notebook.grid(row=4,column=0,sticky='nsew')
        source=ttk.Frame(self.notebook,padding=12);output=ttk.Frame(self.notebook,padding=12)
        self.notebook.add(source,text='1 · Source file');self.notebook.add(output,text='2 · Processing and result')
        text=tk.Text(source,wrap='word',font=('Segoe UI',12),padx=16,pady=16,bg='#F7F7FC',relief='flat')
        text.pack(fill='both',expand=True);text.insert('1.0',(EXAMPLE/'transcript.txt').read_text(encoding='utf-8'));text.configure(state='disabled')
        ttk.Label(source,text='Included file: examples/first-lesson/transcript.txt · 4 segments · no audio',foreground='#66718A').pack(anchor='w',pady=(10,0))
        self.output=tk.Text(output,wrap='word',font=('Segoe UI',11),padx=16,pady=16,bg='#F7F7FC',relief='flat',state='disabled')
        self.output.pack(fill='both',expand=True)
        self.progress=ttk.Progressbar(frame,maximum=4,style=configure_progress_style(style));self.progress.grid(row=5,column=0,sticky='ew',pady=(18,8))
        self.status=tk.StringVar(root,value='Read the example and start the demo.')
        ttk.Label(frame,textvariable=self.status,wraplength=840).grid(row=6,column=0,sticky='w',pady=5)
        actions=ttk.Frame(frame);actions.grid(row=7,column=0,sticky='ew',pady=(12,0))
        self.editor_button=ttk.Button(actions,text='Open and edit the lesson',command=self.open_editor,state='disabled');self.editor_button.pack(side='left')
        self.files_button=ttk.Button(actions,text='Open generated files',command=lambda:open_path(self.folder),state='disabled');self.files_button.pack(side='left',padx=10)
        self.cancel_button=ttk.Button(actions,text='Cancel',command=self.stop,state='disabled');self.cancel_button.pack(side='right')
        root.after(100,self.poll);root.protocol('WM_DELETE_WINDOW',self.close)

    def append(self,text):
        self.output.configure(state='normal');self.output.insert('end',text+'\n\n');self.output.see('end');self.output.configure(state='disabled')

    def start(self):
        from tkinter import messagebox
        if self.running:return
        self.running=True;self.cancel.clear();self.folder=new_folder()
        self.output.configure(state='normal');self.output.delete('1.0','end');self.output.configure(state='disabled')
        self.start_button.configure(state='disabled');self.editor_button.configure(state='disabled');self.files_button.configure(state='disabled');self.cancel_button.configure(state='normal')
        self.progress.configure(mode='determinate',value=0);self.notebook.select(1)
        self.current_live=self.live.get()
        if self.current_live:
            from lecture_pipeline import LecturePipeline
            provider=load_installation().get('ai_provider','codex')
            self.notice.set('Live AI processing with '+PROVIDERS[provider]['name']+'. The sample text is sent to the provider using your account and quota.')
            self.controller=LecturePipeline()
            self.events=self.controller.events
            self.controller.start({'folder':str(self.folder),'title':'Ohm’s law · Live example','language':'en',
                                   'transcript':str(EXAMPLE/'transcript.txt'),'transcription_mode':'external','ai_provider':provider})
        else:
            self.notice.set('Local demo: prepared result. No audio transcription or AI request. The editor and generated files are real.')
            def work():
                try:run_local(self.folder,lambda kind,value:self.events.put((kind,value)),self.cancel)
                except Exception as exc:self.events.put(('failed',{'message':str(exc)}))
            threading.Thread(target=work,daemon=True).start()

    def poll(self):
        # Display one real stage at a time so the walkthrough remains readable.
        try:
            kind,value=self.events.get_nowait()
            if kind=='phase':
                self.status.set(value['message']);self.append('✓ '+value['message'])
                self.progress.configure(value=min(4,value['step']*(4/5 if self.current_live else 1)))
            elif kind=='activity':self.status.set(value)
            elif kind=='completed':
                self.running=False;self.start_button.configure(state='normal',text='Repeat in a new project');self.cancel_button.configure(state='disabled')
                self.editor_button.configure(state='normal');self.files_button.configure(state='normal');self.progress.configure(value=4)
                self.status.set('Lesson ready. Open the editor, edit a sentence or caption, and click Save.')
                project=value['project']
                self.append('RESULT\n• Segment coverage verified by the pipeline\n• Text and formulas available in the editor\n• '+str(len(project.get('figures',[])))+' figures with editable captions\n• HTML, Markdown, and project JSON saved\n\nFolder: '+str(self.folder))
            elif kind in {'failed','cancelled'}:
                self.running=False;self.start_button.configure(state='normal');self.cancel_button.configure(state='disabled')
                self.status.set(value['message']);self.append(value['message'])
        except queue.Empty:pass
        self.root.after(650 if self.running else 100,self.poll)

    def open_editor(self):
        from lecture_pipeline import open_editor
        open_editor(self.folder)

    def stop(self):
        self.cancel.set()
        if self.controller:self.controller.cancel()

    def close(self):
        self.stop();self.root.destroy()


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headless',action='store_true',help='Create and verify the demo without a GUI')
    parser.add_argument('--open',action='store_true',help='Open the editor after creating the demo without a GUI')
    parser.add_argument('--output-dir',type=Path,help='Parent folder for new demo projects')
    parser.add_argument('--start',action='store_true',help='Start the local guided demo immediately')
    parser.add_argument('--live',action='store_true',help='Live AI processing: requires an account and quota')
    args=parser.parse_args(argv)
    if args.headless or args.open:
        execute=run_live if args.live else run_local
        folder=execute(new_folder(args.output_dir),lambda kind,value:print(kind,json.dumps(value if kind!='completed' else {'folder':value['folder']},ensure_ascii=False),flush=True))
        if args.open:
            from lecture_pipeline import open_editor
            open_editor(folder)
        return 0
    import tkinter as tk
    root=tk.Tk();app=DemoApp(root)
    if args.live:app.live.set(True)
    if args.start:root.after(600,app.start)
    root.mainloop();return 0


if __name__=='__main__':
    raise SystemExit(main())
