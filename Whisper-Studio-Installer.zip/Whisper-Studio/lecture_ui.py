"""Select lecture materials, edit the HTML and publish with project LaTeX metadata."""
from __future__ import annotations

import json
import logging
import os
import queue
import subprocess
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import review_editor as editor
from lecture_pipeline import LecturePipeline, ROOT, check_codex, discover, normalize_config, open_editor
from transcribe import hidden_process_options
from model_catalog import ModelCatalog, default_model, infer_english_only, language_choices
from latex_settings import TEXT_FIELDS, load_settings, normalize_settings, save_settings
from latex_export import LatexPipeline, available_latex, prepare_export
from studio_runtime import load_installation, open_path, venv_python, PROVIDERS
from lecture_pipeline import check_assistant

LOGGER=logging.getLogger(__name__)
LABELS={'audio':'Audio / video','transcript':'Existing transcript','clean_slides':'Clean slides','annotated_slides':'Annotated slides','whiteboard':'Whiteboard'}
PROGRESS_STEPS={'lecture':('Materials','Transcription','Context','Processing','Notes'),
    'latex':('Preparation','LaTeX and PDF','Checks','Archive','Result')}


class LectureApp:
    def __init__(self,root,*,controller=None,latex_controller=None,state_root=None):
        self.root=root;self.controller=controller or LecturePipeline();self.state_root=Path(state_root or ROOT/'.state')
        self.latex_controller=latex_controller or LatexPipeline()
        self.closing=False;self.events=queue.Queue();self.last_run=None;self.probe_thread=None;self.form_widgets=[]
        self.active_workflow=None;self.controls_busy=False;self.progress_animating=False
        self.progress_states={name:{'step':0,'percent':None,'outcome':None} for name in PROGRESS_STEPS}
        self.latex_target=None;self.result_refresh_at=0
        self.root.title('Whisper Studio · Lessons')
        self.root.geometry(f'{min(1240,self.root.winfo_screenwidth()-80)}x{min(820,self.root.winfo_screenheight()-90)}')
        self.root.minsize(1060,720)
        self.root.report_callback_exception=self.report_callback_exception
        self.catalog=ModelCatalog(self.state_root/'asr-models.json');self.project_models={};self.syncing_options=False
        self.variables={key:tk.StringVar(root,value='') for key in ['folder','title',*LABELS,'clean_start','annotated_start','language','model','ai_provider','transcription_mode','device']}
        defaults=load_installation()
        for key,value in [('ai_provider','codex'),('transcription_mode','whisper'),('device','auto')]:
            self.variables[key].set(defaults.get(key,value))
        self.variables['language'].set('en');self.variables['model'].set('distil-large-v3.5')
        self.latex_variables={key:tk.StringVar(root,value='') for key in TEXT_FIELDS if key!='instructions'}
        self.latex_toc=tk.BooleanVar(root,value=False)
        self.language_options=language_choices();self.language_choice=tk.StringVar(root)
        self.model_hint=tk.StringVar(root);self.readonly_widgets=set()
        self.context_files=[];self.context_label=tk.StringVar(root,value='No additional materials')
        self.status=tk.StringVar(root,value='Choose a folder and the lesson materials.')
        self.activity=tk.StringVar(root,value='English notes · technical style · teaching repetitions preserved')
        self.progress_context=tk.StringVar(root,value='LESSON')
        self.codex_status=tk.StringVar(root,value='Checking assistant…')
        self.build_ui()
        self.variables['language'].trace_add('write',lambda *_:self.update_model_options())
        self.variables['model'].trace_add('write',lambda *_:self.update_model_hint())
        self.restore();self.show_workflow_progress();self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.probe_provider=self.variables['ai_provider'].get() or 'codex'
        self.root.after(100,self.poll);self.probe_thread=threading.Thread(target=self.probe_codex,daemon=True);self.probe_thread.start()

    def build_ui(self):
        from studio_view import build_ui
        build_ui(self)


    def choose_folder(self):
        value=filedialog.askdirectory(title='Lesson project folder',initialdir=self.variables['folder'].get() or str(ROOT))
        if value:self.load_folder(value)
    def load_folder(self,value):
        config=discover(value);self.apply_config(config)
        self.status.set('Materials loaded. You can add or change files before processing.')
        self.last_run=None
        jobs=[]
        for name in ('last-job.json','last-latex-job.json'):
            last=Path(value)/'.whisper-studio'/name
            if not last.is_file():continue
            try:
                jobs.append(json.loads(last.read_text(encoding='utf-8')))
            except (OSError,ValueError):pass
        if jobs:
            job=max(jobs,key=lambda item:item.get('updated_at',''));self.last_run=job.get('run')
            if job.get('status')=='running':self.status.set('The previous job was interrupted. You can retry processing or export from its tab.')
    def choose_file(self,key):
        types=[('All files','*.*')]
        if key in {'clean_slides','annotated_slides','whiteboard'}:types=[('PDF document','*.pdf')]
        elif key=='transcript':types=[('Transcription','*.json *.txt *.srt *.md')]
        elif key=='audio':types=[('Audio and video','*.m4a *.mp3 *.wav *.flac *.aac *.ogg *.mp4 *.mkv *.mov *.webm *.opus')]
        value=filedialog.askopenfilename(title=LABELS[key],initialdir=self.variables['folder'].get() or str(ROOT),filetypes=types)
        if value:self.variables[key].set(value)
    def choose_context(self):
        values=filedialog.askopenfilenames(title='Additional materials: select all files you need',initialdir=self.variables['folder'].get() or str(ROOT),filetypes=[('Context','*.pdf *.txt *.md *.png *.jpg *.jpeg')])
        if values:
            self.context_files=list(values);self.context_label.set('; '.join(Path(p).name for p in self.context_files));self.refresh_materials()
    def clear_context(self):
        self.context_files=[];self.context_label.set('No additional materials');self.refresh_materials()
    def refresh_materials(self):
        from studio_view import refresh_materials
        refresh_materials(self)
    def model_entries(self):return {**self.project_models,**self.catalog.entries()}
    def update_model_options(self):
        if self.syncing_options:return
        self.syncing_options=True
        try:
            language=self.variables['language'].get() or 'en'
            self.language_choice.set(next((label for label,code in self.language_options.items() if code==language),language))
            compatible={s:m for s,m in self.model_entries().items() if language=='en' or not m['english_only']}
            self.model_combo.configure(values=tuple(compatible))
            current=self.variables['model'].get()
            if current not in compatible:self.variables['model'].set(default_model(language))
        finally:self.syncing_options=False
        self.update_model_hint()
    def update_model_hint(self):
        if self.syncing_options:return
        source=self.variables['model'].get();entry=self.model_entries().get(source,{})
        mode='English only' if entry.get('english_only',infer_english_only(source)) else 'Multilingual'
        detail=('Local folder' if Path(source).is_dir() else 'Download if needed')
        self.model_hint.set(f'{mode} · {detail}')
    def add_custom_model(self,source,*,name='',english_only=None):
        entry=self.catalog.register(source,name=name,english_only=english_only)
        self.update_model_options()
        language=self.variables['language'].get()
        if language=='en' or not entry['english_only']:
            self.variables['model'].set(entry['source']);self.status.set('Model added and selected.')
        else:self.status.set('Model added: select English as the audio language to use it.')
        return entry
    def show_add_model(self):
        dialog=tk.Toplevel(self.root);dialog.title('Add a Whisper model');dialog.transient(self.root);dialog.resizable(False,False)
        box=ttk.Frame(dialog,padding=24);box.pack(fill='both',expand=True);box.columnconfigure(1,weight=1)
        ttk.Label(box,text='Add a model',style='Title.TLabel').grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,8))
        ttk.Label(box,text='Use a Hugging Face repository in CTranslate2 format or a local folder.\nExample: Systran/faster-whisper-large-v3. Downloads on first use.',style='Muted.TLabel',wraplength=620).grid(row=1,column=0,columnspan=3,sticky='w',pady=(0,18))
        name=tk.StringVar(dialog);source=tk.StringVar(dialog);only=tk.BooleanVar(dialog,value=False)
        ttk.Label(box,text='Name (optional)').grid(row=2,column=0,sticky='w',padx=(0,12))
        ttk.Entry(box,textvariable=name,width=48).grid(row=2,column=1,columnspan=2,sticky='ew',pady=6)
        ttk.Label(box,text='Repository / folder').grid(row=3,column=0,sticky='w',padx=(0,12))
        entry=ttk.Entry(box,textvariable=source,width=48);entry.grid(row=3,column=1,sticky='ew',pady=6)
        def browse():
            folder=filedialog.askdirectory(parent=dialog,title='CTranslate2 model folder')
            if folder:source.set(folder)
        ttk.Button(box,text='Folder…',command=browse).grid(row=3,column=2,padx=(8,0))
        ttk.Checkbutton(box,text='English-only model',variable=only).grid(row=4,column=0,columnspan=3,sticky='w',pady=12)
        trace=source.trace_add('write',lambda *_:only.set(True) if infer_english_only(source.get()) else None)
        def close():
            source.trace_remove('write',trace);dialog.destroy()
        def accept():
            try:self.add_custom_model(source.get(),name=name.get(),english_only=only.get());close()
            except Exception as exc:messagebox.showerror('Add model',str(exc),parent=dialog)
        buttons=ttk.Frame(box);buttons.grid(row=5,column=0,columnspan=3,sticky='e',pady=(14,0))
        ttk.Button(buttons,text='Cancel',command=close).pack(side='left',padx=8)
        ttk.Button(buttons,text='Add model',style='Accent.TButton',command=accept).pack(side='left')
        dialog.grab_set();entry.focus_set();dialog.protocol('WM_DELETE_WINDOW',close)
        dialog.bind('<Return>',lambda _e:accept());dialog.bind('<Escape>',lambda _e:close())
    def config(self):
        source=self.variables['model'].get();entry=self.model_entries().get(source,{})
        return {**{key:var.get() for key,var in self.variables.items()},'context_files':self.context_files,
            'latex':self.latex_config(),
            'instructions':self.instructions.get('1.0','end').strip(),'glossary':self.glossary.get('1.0','end').strip(),
            'model_english_only':entry.get('english_only',infer_english_only(source)),
            'model_label':entry.get('name',source)}
    def apply_config(self,config):
        latex=normalize_settings(config.get('latex'))
        self.syncing_options=True
        language=config.get('language') or 'en';model=config.get('model') or default_model(language)
        if model not in self.catalog.entries():
            self.project_models[model]={'source':model,'name':config.get('model_label',Path(model).name),
                'english_only':bool(config.get('model_english_only',infer_english_only(model))),'custom':True}
        defaults=load_installation()
        for key,var in self.variables.items():
            fallback=defaults.get(key,{'ai_provider':'codex','transcription_mode':'whisper','device':'auto'}.get(key,''))
            var.set(str(config.get(key,fallback) or fallback))
        self.variables['language'].set(language);self.variables['model'].set(model);self.syncing_options=False
        for widget,key in [(self.instructions,'instructions'),(self.glossary,'glossary')]:
            widget.delete('1.0','end');widget.insert('1.0',config.get(key,'') or '')
        for key,var in self.latex_variables.items():var.set(latex[key])
        self.latex_toc.set(latex['include_toc'])
        self.latex_instructions.delete('1.0','end');self.latex_instructions.insert('1.0',latex['instructions'])
        self.context_files=list(config.get('context_files',[]));self.context_label.set('; '.join(Path(p).name for p in self.context_files) or 'No additional materials')
        self.update_model_options();self.update_open_button();self.refresh_materials()
    def restore(self):
        try:
            state=json.loads((self.state_root/'lecture-ui.json').read_text(encoding='utf-8'))
            if state.get('folder'):state['latex']=load_settings(state['folder'],state.get('latex'))
            self.apply_config(state)
        except (OSError,ValueError):pass
        self.update_model_options();self.update_open_button()
    def save(self):editor.write_json(self.state_root/'lecture-ui.json',self.config())
    @property
    def busy(self):return self.controls_busy or self.controller.busy or self.latex_controller.busy
    def selected_workflow(self):
        return 'latex' if self.workflow_tabs.index('current')==1 else 'lecture'
    def begin_workflow(self,workflow):
        self.active_workflow=workflow;self.last_run=None
        self.progress_states[workflow]={'step':1,'percent':None,'outcome':None}
        self.workflow_tabs.select(1 if workflow=='latex' else 0)
        self.show_workflow_progress(workflow)
    def show_workflow_progress(self,workflow=None):
        workflow=self.active_workflow or workflow or self.selected_workflow()
        state=self.progress_states[workflow];step=state['step'];outcome=state['outcome']
        self.progress_context.set('LATEX' if workflow=='latex' else 'LESSON')
        for i,(label,text) in enumerate(zip(self.step_labels,PROGRESS_STEPS[workflow]),1):
            style='Step.TLabel'
            if outcome=='completed' or (step and i<step):style='Done.Step.TLabel'
            elif i==step:
                style='Warning.Step.TLabel' if outcome in {'partial','failed','cancelled'} else 'Active.Step.TLabel'
            label.configure(text=f'{i:02d}  {text}',style=style)
        running=self.active_workflow==workflow and outcome is None
        if running and state['percent'] is None:
            if not self.progress_animating:
                self.progress.configure(mode='indeterminate',value=0);self.progress.start(12);self.progress_animating=True
        else:
            if self.progress_animating:self.progress.stop();self.progress_animating=False
            value=state['percent'] if running and state['percent'] is not None else 100 if outcome in {'completed','partial'} else 0
            self.progress.configure(mode='determinate',value=value)
    def project_folder_changed(self):
        self.last_run=None;self.latex_target=None;self.result_refresh_at=0
        if not self.active_workflow:
            self.progress_states={name:{'step':0,'percent':None,'outcome':None} for name in PROGRESS_STEPS}
            self.show_workflow_progress()
        self.update_open_button()
    def latex_config(self):
        return {**{key:var.get() for key,var in self.latex_variables.items()},
            'include_toc':self.latex_toc.get(),'instructions':self.latex_instructions.get('1.0','end').strip()}
    def save_latex(self):
        try:
            if self.busy:raise RuntimeError('Wait for the current job to finish')
            settings=normalize_settings(self.latex_config(),title=self.variables['title'].get())
            save_settings(self.variables['folder'].get(),settings)
            for key,var in self.latex_variables.items():var.set(settings[key])
            self.save();self.status.set('LaTeX settings saved for this lesson.');self.activity.set('The lesson text and figures are unchanged.')
        except Exception as exc:messagebox.showerror('Dati LaTeX',str(exc),parent=self.root)
    def prepare_latex(self):
        try:
            if self.busy:raise RuntimeError('Wait for the current job to finish')
            self.last_run=str(prepare_export(self.config()));self.save()
            self.status.set('LaTeX prompt prepared · no processing started')
            self.activity.set('Open Details to inspect the actual prompt, metadata, and input snapshot.')
        except Exception as exc:messagebox.showerror('Prepara prompt LaTeX',str(exc),parent=self.root)
    def start_latex(self):
        try:
            if self.busy:raise RuntimeError('Wait for the current job to finish')
            self.save();self.latex_controller.start(self.config());self.begin_workflow('latex');self.set_busy(True)
            self.status.set('Exporting LaTeX…')
        except Exception as exc:messagebox.showerror('LaTeX export',str(exc),parent=self.root)
    def update_open_button(self):
        value=self.variables['folder'].get();folder=Path(value) if value else None
        ready=folder is not None and (folder/'lecture_project.json').is_file() and (folder/'lecture.html').is_file()
        self.latex_target=available_latex(folder) if folder is not None else None
        for button,available in ((self.open_button,ready),(self.open_latex_button,self.latex_target is not None)):
            button.configure(state='normal' if available and not self.busy else 'disabled')
            if available:button.grid()
            else:button.grid_remove()
        for button in (self.latex_prompt_button,self.latex_export_button):button.configure(state='normal' if ready and not self.busy else 'disabled')
        selected=bool(self.variables['folder'].get()) and Path(self.variables['folder'].get()).is_dir()
        self.latex_save_button.configure(state='normal' if selected and not self.busy else 'disabled')
    def set_busy(self,value):
        self.controls_busy=value
        for widget in self.form_widgets:widget.configure(state='disabled' if value else 'readonly' if widget in self.readonly_widgets else 'normal')
        self.start_button.configure(state='disabled' if value else 'normal')
        for workflow,button in (('lecture',self.cancel_button),('latex',self.latex_cancel_button)):
            button.configure(state='normal' if value and self.active_workflow==workflow else 'disabled')
        self.update_open_button()
    def start(self):
        try:
            if self.busy:raise RuntimeError('Wait for the current job to finish')
            config=normalize_config(self.config());self.save();self.controller.start(config);self.begin_workflow('lecture');self.set_busy(True)
            self.status.set('Processing the lesson…')
        except Exception as exc:messagebox.showerror('Whisper Studio',str(exc),parent=self.root)
    def cancel(self):
        self.controller.cancel();self.latex_controller.cancel()
        for button in (self.cancel_button,self.latex_cancel_button):button.configure(state='disabled')
        self.status.set('Canceling…')
    def poll(self):
        if self.closing:return
        for source,workflow in ((self.controller.events,'lecture'),(self.latex_controller.events,'latex'),(self.events,None)):
            for _ in range(150):
                try:kind,payload=source.get_nowait()
                except queue.Empty:break
                self.handle_event(kind,payload,workflow=workflow)
        if not self.busy and time.monotonic()-self.result_refresh_at>=2:
            self.result_refresh_at=time.monotonic();self.update_open_button()
        self.root.after(100,self.poll)
    def handle_event(self,kind,payload,*,workflow=None):
        if kind=='codex':self.codex_status.set(payload);return
        workflow=workflow or ('latex' if kind=='latex-completed' else self.active_workflow or self.selected_workflow())
        state=self.progress_states[workflow]
        if kind=='phase':
            state['step']=max(1,min(5,int(payload['step'])));state['percent']=None;self.status.set(payload['message'])
            self.show_workflow_progress(workflow)
        elif kind=='activity':self.activity.set(str(payload)[:400])
        elif kind=='progress':
            state['percent']=max(0,min(100,float(payload)));self.show_workflow_progress(workflow)
            self.activity.set(('Audio transcription' if workflow=='lecture' else 'LaTeX export')+f": {state['percent']:.0f}%")
        elif kind in {'completed','latex-completed','failed','cancelled'}:
            state['percent']=None
            state['outcome']='completed' if kind=='completed' or (kind=='latex-completed' and payload['complete']) else 'partial' if kind=='latex-completed' else kind
            if kind in {'completed','latex-completed'}:state['step']=5
            self.active_workflow=None;self.show_workflow_progress(workflow);self.set_busy(False)
            # The worker may be returning just after its final event; do not leave buttons disabled.
            self.root.after(150,self.update_open_button)
            if kind=='latex-completed':
                self.last_run=payload['run']
                self.status.set('LaTeX and PDF ready' if payload['complete'] else 'Partial LaTeX export · see the report in Details')
                self.activity.set(payload['message'] or "Sources and the ZIP archive are in the lesson's latex folder.")
                if payload.get('pdf'):open_path(payload['pdf'])
            elif kind=='completed':
                last=Path(payload['folder'])/'.whisper-studio/last-job.json'
                if last.is_file():
                    try:self.last_run=json.loads(last.read_text(encoding='utf-8')).get('run')
                    except (OSError,ValueError):pass
                self.status.set('Lesson ready · editable HTML saved in the project folder')
                self.activity.set(f"{payload['issues']} items still flagged for review. Text, formulas, and figure notes are editable.")
                self.open_result(folder=payload['folder'])
            else:
                self.status.set(payload['message']);self.activity.set('Source files and completed results are preserved.')
                self.last_run=payload.get('run',self.last_run)
                if kind=='failed':messagebox.showerror('Processing incomplete',payload['message'],parent=self.root)
    def open_result(self,folder=None):
        try:open_editor(folder or self.variables['folder'].get())
        except Exception as exc:messagebox.showerror('Editable HTML',str(exc),parent=self.root)
    def open_latex(self):
        try:
            folder=self.variables['folder'].get()
            target=available_latex(folder) if folder else None
            if target is None:
                self.update_open_button();self.status.set('No LaTeX export is available for this lesson.');return
            open_path(target)
        except Exception as exc:messagebox.showerror('Open LaTeX',str(exc),parent=self.root)
    def probe_codex(self):
        provider=self.probe_provider
        try:
            check_assistant(provider)
            text=PROVIDERS[provider]['name']+' ready · '+('account checked during the first job' if provider=='gemini' else 'authentication available')
        except Exception as exc:text=str(exc)
        self.events.put(('codex',text))
    def refresh_codex(self):
        if self.probe_thread and self.probe_thread.is_alive():return
        self.probe_provider=self.variables['ai_provider'].get() or 'codex'
        self.codex_status.set('Checking assistant…');self.probe_thread=threading.Thread(target=self.probe_codex,daemon=True);self.probe_thread.start()
    def open_advanced(self):
        if self.busy:
            messagebox.showinfo('Processing in progress','Wait for lesson processing to finish before opening advanced transcription.',parent=self.root);return
        python=venv_python(windowless=True)
        subprocess.Popen([str(python) if python.is_file() else __import__('sys').executable,str(ROOT/'audio_selector.pyw'),'--transcription-only'],cwd=ROOT,**hidden_process_options())
    def open_setup(self):
        subprocess.Popen([__import__('sys').executable,str(ROOT/'setup_wizard.py')],cwd=ROOT,**hidden_process_options())
    def open_demo(self):
        subprocess.Popen([__import__('sys').executable,str(ROOT/'studio_demo.py')],cwd=ROOT,**hidden_process_options())
    def show_details(self):
        folder=Path(self.variables['folder'].get()) if self.variables['folder'].get() else ROOT
        name='last-latex-job.json' if self.active_workflow=='latex' else 'last-job.json'
        last=folder/'.whisper-studio'/name
        if (self.active_workflow or not self.last_run) and last.is_file():
            try:self.last_run=json.loads(last.read_text(encoding='utf-8')).get('run')
            except (OSError,ValueError):pass
        target=Path(self.last_run) if self.last_run else folder/'.whisper-studio'
        if target.is_dir():open_path(target)
        else:messagebox.showinfo('Details','Details are created when you start processing.',parent=self.root)
    def report_callback_exception(self,kind,value,tb):
        LOGGER.error('Lecture interface error',exc_info=(kind,value,tb));self.status.set(str(value))
    def close(self):
        if self.closing:return
        try:self.save()
        except OSError:LOGGER.exception('Could not save lecture UI state')
        self.closing=True;self.progress.stop();self.progress_animating=False
        for timer in self.root.tk.call('after','info'):self.root.tk.call('after','cancel',timer)
        self.controller.shutdown();self.latex_controller.shutdown();self.root.report_callback_exception=lambda *_:None
        for tooltip in getattr(self,'tooltips',[]):tooltip.hide()
        self.tooltips=[];self.root.destroy()
        for var in [*self.variables.values(),*self.latex_variables.values(),self.latex_toc]:
            # Release Tcl variables while still on the UI thread.
            var.__del__()
        self.variables.clear();self.latex_variables.clear();self.latex_toc=None
        for name in ('context_label','status','activity','codex_status','language_choice','model_hint','materials_count','connection_label','progress_context'):setattr(self,name,None)

