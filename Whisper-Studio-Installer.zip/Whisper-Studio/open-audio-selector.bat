@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "VENV_PYTHONW=%SCRIPT_DIR%.venv\Scripts\pythonw.exe"
set "APP_SCRIPT=%SCRIPT_DIR%studio.py"
if "%~1"=="--transcription-only" set "APP_SCRIPT=%SCRIPT_DIR%audio_selector.pyw"

if not exist "%VENV_PYTHONW%" (
  echo Virtual environment not found.
  echo Avvia prima Installa-Windows.bat
  exit /b 1
)

if not exist "%APP_SCRIPT%" (
  echo App script not found: "%APP_SCRIPT%"
  exit /b 1
)

start "" /D "%SCRIPT_DIR%" "%VENV_PYTHONW%" "%APP_SCRIPT%" %*
exit /b 0
