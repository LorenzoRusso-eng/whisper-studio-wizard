"""Fast, offline SVG previews for Codex and the lecture publisher."""
import argparse
from pathlib import Path

import resvg_py
from lecture_document import safe_svg


def render(source, destination, width=1400):
    svg=safe_svg(Path(source).read_text(encoding='utf-8-sig'))
    png=resvg_py.svg_to_bytes(svg_string=svg,width=width,background='white',font_family='Arial')
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(png)
    return destination


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Render an SVG preview without a browser')
    parser.add_argument('svg',type=Path);parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--width',type=int,default=1400);args=parser.parse_args()
    if not 100<=args.width<=3000:parser.error('Width must be between 100 and 3000 pixels')
    print(render(args.svg,args.output,args.width))
