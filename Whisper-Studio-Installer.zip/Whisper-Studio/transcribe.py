"""Local transcription engine shared by the CLI and desktop app."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import site
import subprocess
import tempfile
import textwrap
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from typing import Callable

PROJECT_ROOT = Path(__file__).resolve().parent
AUDIO_ROOT = PROJECT_ROOT / "Audio"
OUTPUT_ROOT = PROJECT_ROOT / "outputs"
KNOWN_EXTENSIONS = (
    ".m4a",
    ".mp3",
    ".wav",
    ".flac",
    ".aac",
    ".ogg",
    ".mp4",
    ".mkv",
    ".mov",
    ".webm",
    ".opus",
)
DLL_HANDLES: list = []
LOGGER = logging.getLogger(__name__)


class TranscriptionCancelled(Exception):
    """Checked between decoding, VAD windows and inference batches."""


class EmptyTranscriptError(RuntimeError):
    pass


def check_cancelled(cancel_event=None) -> None:
    if cancel_event is not None and cancel_event.is_set():
        raise TranscriptionCancelled('Transcription canceled.')


def _add_windows_nvidia_dlls() -> None:
    if os.name != "nt":
        return
    directories = []
    for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
        for package in ("cublas", "cudnn", "cuda_runtime", "cuda_nvrtc"):
            directory = Path(site_dir) / "nvidia" / package / "bin"
            if directory.is_dir():
                directories.append(str(directory))
                if hasattr(os, "add_dll_directory"):
                    DLL_HANDLES.append(os.add_dll_directory(str(directory)))
    if directories:
        os.environ["PATH"] = os.pathsep.join(directories + [os.environ.get("PATH", "")])


_add_windows_nvidia_dlls()

ASR_IMPORT_ERROR = None
try:
    import ctranslate2
    import numpy as np
    from faster_whisper import BatchedInferencePipeline, WhisperModel
    from faster_whisper.audio import decode_audio
    from faster_whisper.tokenizer import _LANGUAGE_CODES
    from faster_whisper.vad import VadOptions, get_speech_timestamps
except (ImportError, OSError) as exc:
    ASR_IMPORT_ERROR = str(exc)
    from model_catalog import LANGUAGE_CODES
    _LANGUAGE_CODES = LANGUAGE_CODES


def require_asr():
    if ASR_IMPORT_ERROR:
        raise RuntimeError('Whisper is not installed or cannot start. Open the wizard and choose local Whisper. '
                           'You can also import an external transcript. Details: ' + ASR_IMPORT_ERROR)


def hidden_process_options() -> dict:
    return {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}


def detect_vram_gb() -> float | None:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
            **hidden_process_options(),
        )
        return round(int(result.stdout.strip().splitlines()[0]) / 1024, 1)
    except (OSError, ValueError, IndexError, subprocess.SubprocessError):
        return None


def select_device(requested: str = "auto") -> str:
    require_asr()
    if requested not in {"auto", "cpu", "cuda"}:
        raise ValueError(f"Invalid device: {requested}")
    if requested != "auto":
        return requested
    try:
        return "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
    except RuntimeError:
        return "cpu"


def choose_defaults(
    preset: str,
    vram_gb: float | None,
    *,
    device: str = "cuda",
    task: str = "transcribe",
) -> dict:
    if preset not in {"speed", "balanced", "max"}:
        raise ValueError(f"Invalid preset: {preset}")
    low_memory = vram_gb is None or vram_gb < 6
    if preset == "speed":
        model, beam, batch = "small", 1, 8
    elif preset == "max":
        model, beam, batch = (
            ("medium" if low_memory or device == "cpu" else "large-v3"),
            5,
            2,
        )
    else:
        model, beam, batch = (
            ("medium" if task == "translate" else "large-v3-turbo"),
            3,
            4,
        )
    if device == "cpu":
        model = "small" if preset != "max" else "medium"
        batch = 2
    return {
        "model": model,
        "compute_type": "int8" if device == "cpu" else "int8_float16",
        "beam_size": beam,
        "batch_size": batch,
    }


def normalize_compute_type(device: str, requested: str | None = None) -> str:
    require_asr()
    supported = ctranslate2.get_supported_compute_types(device)
    if requested in {"auto", "default"}:
        return requested
    if requested:
        if requested not in supported:
            raise ValueError(
                f"Precision {requested!r} is not supported on {device}. Available: {', '.join(sorted(supported))}."
            )
        return requested
    candidates = (
        ("int8_float16", "float16", "int8_float32", "float32")
        if device == "cuda"
        else ("int8", "int8_float32", "float32")
    )
    for candidate in candidates:
        if candidate in supported:
            return candidate
    raise RuntimeError(f"No supported precision available for {device}.")


def validate_model_task(model_name: str, language: str | None, task: str) -> None:
    from model_catalog import is_english_only
    name = model_name.lower()
    if is_english_only(model_name):
        if language != "en" or task != "transcribe":
            raise ValueError(
                'This is an English-only model: use --language en --task transcribe or choose a multilingual model.'
            )
    if "turbo" in name and task == "translate":
        raise ValueError(
            'The turbo model is not trained for translation: choose small, medium, or large-v3.'
        )


def normalize_language(language: str | None) -> str | None:
    language = (language or "auto").strip().lower()
    if language == "auto":
        return None
    if language not in _LANGUAGE_CODES:
        raise ValueError(f"Invalid language: {language}. Use a language code such as it or en.")
    return language


def create_model(
    model_name: str,
    device: str,
    compute_type: str,
    *,
    download_root: Path | None = None,
) -> WhisperModel:
    compute_type = normalize_compute_type(device, compute_type)
    try:
        model = WhisperModel(
            model_name,
            device=device,
            compute_type=compute_type,
            download_root=str(download_root or PROJECT_ROOT / ".models"),
        )
    except Exception as exc:
        if device == "cuda":
            raise RuntimeError(
                f"GPU startup failed. Check the NVIDIA driver and run the installation wizard; CPU mode is also available. Details: {exc}"
            ) from exc
        raise
    model.studio_model_name = model_name
    return model


def unload_model(model) -> None:
    if model is not None:
        backend = getattr(model, "model", None)
        if backend is not None and hasattr(backend, "unload_model"):
            backend.unload_model()


def atomic_write_text(path: Path, text: str) -> None:
    """Publish each file only after it has been written completely."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=path.parent,
            prefix=".whisper-",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def output_file(output_base: Path, extension: str) -> Path:
    return output_base.parent / f"{output_base.name}.{extension.lstrip('.')}"


def build_output_base(
    input_path: Path, output_dir: Path, *, create: bool = True
) -> Path:
    input_path = input_path.resolve()
    try:
        relative = input_path.relative_to(AUDIO_ROOT.resolve())
        directory = output_dir / relative.parent / input_path.stem
        if any(
            (input_path.parent / (input_path.stem + ext)).is_file()
            for ext in KNOWN_EXTENSIONS
            if ext != input_path.suffix.lower()
        ):
            directory = (
                output_dir
                / relative.parent
                / f"{input_path.stem} [{input_path.suffix.lower().lstrip('.')}]"
            )
    except ValueError:
        digest = hashlib.sha256(
            os.path.normcase(str(input_path)).encode("utf-8")
        ).hexdigest()[:10]
        directory = output_dir / "external" / f"{input_path.stem}-{digest}"
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory / input_path.stem


def resolve_input_path(raw_input: str) -> Path:
    candidate = Path(raw_input).expanduser()
    if candidate.is_file():
        return candidate.resolve()
    if candidate.is_dir():
        raise ValueError(f"The input is a folder: {candidate}")
    if candidate.suffix.lower() not in KNOWN_EXTENSIONS:
        matches = [
            Path(str(candidate) + ext)
            for ext in KNOWN_EXTENSIONS
            if Path(str(candidate) + ext).is_file()
        ]
        if len(matches) == 1:
            return matches[0].resolve()
        if len(matches) > 1:
            raise ValueError('Multiple files match: specify the extension.')
    raise FileNotFoundError(raw_input)


def format_timestamp(seconds: float) -> str:
    total_ms = max(0, round(seconds * 1000))
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def subtitle_cues(segments: list[dict]) -> list[dict]:
    cues = []
    for segment in segments:
        words = segment.get("words") or []
        if not words:
            tokens = segment["text"].split()
            duration = max(0.001, segment["end"] - segment["start"])
            words = [
                {
                    "word": " " + word,
                    "start": segment["start"] + duration * i / len(tokens),
                    "end": segment["start"] + duration * (i + 1) / len(tokens),
                }
                for i, word in enumerate(tokens)
            ]
        group = []
        for word in words:
            text = "".join(w["word"] for w in group) + word["word"]
            if group and (
                len(text.strip()) > 84
                or len(textwrap.wrap(text.strip(), width=42)) > 2
                or word["end"] - group[0]["start"] > 7
                or word["start"] - group[-1]["end"] > 1
            ):
                cues.append(
                    {
                        "start": group[0]["start"],
                        "end": group[-1]["end"],
                        "text": "".join(w["word"] for w in group).strip(),
                    }
                )
                group = []
            group.append(word)
        if group:
            cues.append(
                {
                    "start": group[0]["start"],
                    "end": group[-1]["end"],
                    "text": "".join(w["word"] for w in group).strip(),
                }
            )
    return [cue for cue in cues if cue["text"]]


def write_text_output(path: Path, segments: list[dict]) -> None:
    atomic_write_text(
        path, "\n".join(s["text"].strip() for s in segments if s["text"].strip()) + "\n"
    )


def write_srt_output(path: Path, segments: list[dict]) -> None:
    blocks = []
    previous_end = 0.0
    for cue in subtitle_cues(segments):
        start = max(previous_end, cue["start"])
        end = min(start + 7, max(start + 0.001, cue["end"]))
        text = "\n".join(textwrap.wrap(cue["text"], width=42))
        blocks.append(
            f"{len(blocks) + 1}\n{format_timestamp(start)} --> {format_timestamp(end)}\n{text}"
        )
        previous_end = end
    atomic_write_text(path, "\n\n".join(blocks) + "\n")


def write_json_output(path: Path, payload: dict) -> None:
    atomic_write_text(
        path, json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    )


def fixed_clips(duration: float, chunk_seconds: float = 30) -> list[dict]:
    clips = []
    start = 0.0
    while start < duration:
        end = min(duration, start + chunk_seconds)
        clips.append({"start": start, "end": end})
        start = end
    return clips


def stable_vad_clips(
    audio: np.ndarray,
    sampling_rate: int = 16000,
    *,
    cancel_event=None,
    progress_callback=None,
) -> tuple[list[dict], list[str]]:
    """Reset recurrent state each minute; retry suspicious empty windows."""
    options = VadOptions(
        max_speech_duration_s=29, min_silence_duration_ms=300, speech_pad_ms=400
    )
    spans, warnings = [], []
    window_size = sampling_rate * 60
    for offset in range(0, len(audio), window_size):
        check_cancelled(cancel_event)
        end = min(len(audio), offset + window_size)
        context_start = max(0, offset - sampling_rate)
        window = audio[context_start:end].copy()
        speech = get_speech_timestamps(window, options, sampling_rate=sampling_rate)
        rms = float(np.sqrt(np.mean(window * window))) if len(window) else 0
        if not speech and rms > 0.001:
            for local_offset in range(0, len(window), sampling_rate * 10):
                check_cancelled(cancel_event)
                part = window[local_offset : local_offset + sampling_rate * 10].copy()
                for item in get_speech_timestamps(
                    part, options, sampling_rate=sampling_rate
                ):
                    speech.append(
                        {
                            "start": item["start"] + local_offset,
                            "end": item["end"] + local_offset,
                        }
                    )
            if speech:
                warnings.append(
                    f"VAD recovered using short windows at {offset / sampling_rate:.0f}s."
                )
            elif rms > 0.003:
                speech = [{"start": offset - context_start, "end": end - context_start}]
                warnings.append(
                    f"Uncertain VAD at {offset / sampling_rate:.0f}s: block retained without filtering."
                )
        for item in speech:
            start_sample = max(offset, context_start + item["start"])
            end_sample = min(end, context_start + item["end"])
            if end_sample > start_sample:
                spans.append(
                    {
                        "start": start_sample / sampling_rate,
                        "end": end_sample / sampling_rate,
                    }
                )
        if progress_callback:
            progress_callback(
                min(5, end / len(audio) * 5),
                end / sampling_rate,
                len(audio) / sampling_rate,
            )
    merged = []
    for span in sorted(spans, key=lambda item: item["start"]):
        if merged and span["start"] <= merged[-1]["end"] + 1.0:
            merged[-1]["end"] = max(merged[-1]["end"], span["end"])
        else:
            merged.append(span.copy())
    clips = []
    for span in merged:
        for part in fixed_clips(span["end"] - span["start"]):
            clips.append(
                {
                    "start": span["start"] + part["start"],
                    "end": span["start"] + part["end"],
                }
            )
    return clips, warnings


def is_out_of_memory(exc: Exception) -> bool:
    return any(
        token in str(exc).lower()
        for token in (
            "out of memory",
            "cuda_error_out_of_memory",
            "cublas_status_alloc_failed",
        )
    )


def transcribe_file(
    input_path: Path,
    model: WhisperModel,
    *,
    preset: str,
    compute_type: str,
    beam_size: int,
    batch_size: int,
    language: str | None,
    task: str,
    output_dir: Path,
    formats: list[str],
    no_vad: bool,
    word_timestamps: bool,
    phase_callback: Callable | None = None,
    progress_callback: Callable | None = None,
    cancel_event=None,
    model_name: str | None = None,
    device: str | None = None,
    initial_prompt: str | None = None,
) -> dict:
    if beam_size < 1 or batch_size < 1:
        raise ValueError('Beam size and batch size must be greater than zero.')
    if not formats or set(formats) - {"txt", "srt", "json"}:
        raise ValueError('Invalid formats.')
    model_name = model_name or getattr(model, "studio_model_name", "unknown")
    language = normalize_language(language)
    validate_model_task(model_name, language, task)
    if getattr(getattr(model, "model", None), "is_multilingual", None) is False and language != "en":
        raise ValueError('The loaded model supports English only: choose English or a multilingual model.')
    phase = phase_callback or (lambda _: None)
    started = time.perf_counter()
    check_cancelled(cancel_event)
    phase("Decodifica audio")
    audio = decode_audio(str(input_path))
    check_cancelled(cancel_event)
    if not len(audio) or not np.isfinite(audio).all():
        raise EmptyTranscriptError('Audio is empty or contains invalid samples.')
    if float(np.max(np.abs(audio))) < 0.00001:
        raise EmptyTranscriptError(
            'The audio is silent. Previous transcripts have been preserved.'
        )
    duration = len(audio) / 16000
    phase("Analyzing speech in blocks")
    clips, warnings = (
        (fixed_clips(duration), [])
        if no_vad
        else stable_vad_clips(
            audio, cancel_event=cancel_event, progress_callback=progress_callback
        )
    )
    if not clips:
        raise EmptyTranscriptError(
            'No speech detected. Previous transcripts have been preserved. Try without the VAD filter.'
        )
    speech_duration = sum(clip["end"] - clip["start"] for clip in clips)
    if speech_duration / duration < 0.1:
        warnings.append(
            'VAD retained less than 10% of the audio: check completeness or retry without filtering.'
        )
    align_words = word_timestamps or "srt" in formats
    effective_batch, fallback = batch_size, False
    while True:
        check_cancelled(cancel_event)
        segments = []
        pipeline = BatchedInferencePipeline(model=model)
        phase(f"Transcribing (batch {effective_batch})")
        try:
            iterator, info = pipeline.transcribe(
                audio,
                clip_timestamps=clips,
                vad_filter=False,
                batch_size=effective_batch,
                beam_size=beam_size,
                language=language,
                task=task,
                word_timestamps=align_words,
                without_timestamps=False,
                condition_on_previous_text=False,
                initial_prompt=initial_prompt,
            )
            for segment in iterator:
                check_cancelled(cancel_event)
                start, end = max(0, min(duration, segment.start)), max(
                    0, min(duration, segment.end)
                )
                if not segment.text.strip() or end < start:
                    continue
                item = {"start": start, "end": end, "text": segment.text.strip()}
                words = getattr(segment, "words", None)
                if words:
                    item["words"] = [
                        {
                            "start": max(start, min(end, w.start)),
                            "end": max(start, min(end, w.end)),
                            "word": w.word,
                            "probability": w.probability,
                        }
                        for w in words
                    ]
                for key in ("avg_logprob", "no_speech_prob", "compression_ratio"):
                    value = getattr(segment, key, None)
                    if value is not None and math.isfinite(value):
                        item[key] = value
                segments.append(item)
                if progress_callback:
                    progress_callback(min(99, 5 + end / duration * 94), end, duration)
            check_cancelled(cancel_event)
        except Exception as exc:
            if is_out_of_memory(exc) and effective_batch > 1:
                effective_batch = max(1, effective_batch // 2)
                del pipeline
                warnings.append(
                    f"Insufficient GPU memory: retrying with batch size {effective_batch}."
                )
                phase(warnings[-1])
                continue
            raise
        if not segments and not no_vad and not fallback:
            warnings.append('Empty transcript with VAD: retrying without filtering.')
            clips, fallback = fixed_clips(duration), True
            continue
        if not segments:
            raise EmptyTranscriptError(
                'No text recognized. Previous transcripts have been preserved.'
            )
        break
    uncertain = sum(
        s.get("avg_logprob", 0) < -1
        or s.get("no_speech_prob", 0) > 0.6
        or s.get("compression_ratio", 0) > 2.4
        for s in segments
    )
    if uncertain / len(segments) > 0.2:
        warnings.append(
            f"{uncertain} of {len(segments)} segments have low confidence or possible repetitions: review the text."
        )
    missing_clips = [
        clip
        for clip in clips
        if not any(
            s["start"] < clip["end"] and s["end"] > clip["start"] for s in segments
        )
    ]
    untranscribed = sum(c["end"] - c["start"] for c in missing_clips)
    effective_duration = sum(c["end"] - c["start"] for c in clips)
    if untranscribed > 30 and untranscribed / effective_duration > 0.15:
        warnings.append(
            f"{untranscribed:.0f}s of analyzed blocks have no text: check completeness."
        )
    elapsed = time.perf_counter() - started
    file_stat = input_path.stat()
    versions = {
        name: version(name)
        for name in ("faster-whisper", "ctranslate2", "onnxruntime", "av", "numpy")
    }
    payload = {
        "schema_version": 2,
        "input": str(input_path.resolve()),
        "input_size_bytes": file_stat.st_size,
        "input_mtime_ns": file_stat.st_mtime_ns,
        "model": model_name,
        "device": device or getattr(getattr(model, "model", None), "device", "unknown"),
        "compute_type": compute_type,
        "preset": preset,
        "task": task,
        "requested_language": language,
        "language": info.language,
        "language_probability": info.language_probability,
        "duration_seconds": duration,
        "duration_after_vad_seconds": effective_duration,
        "untranscribed_clip_seconds": untranscribed,
        "vad_enabled": not no_vad and not fallback,
        "batch_size": effective_batch,
        "beam_size": beam_size,
        "word_timestamps": word_timestamps,
        "initial_prompt": initial_prompt,
        "elapsed_seconds": elapsed,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "versions": versions,
        "warnings": list(dict.fromkeys(warnings)),
        "segments": [
            {k: v for k, v in segment.items() if k != "words" or word_timestamps}
            for segment in segments
        ],
    }
    check_cancelled(cancel_event)
    phase('Saving transcript')
    output_base = build_output_base(input_path, output_dir)
    payload["formats"] = list(dict.fromkeys(formats))
    payload["output_sha256"] = {}
    if "txt" in formats:
        path = output_file(output_base, "txt")
        write_text_output(path, segments)
        payload["output_sha256"][path.name] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    if "srt" in formats:
        path = output_file(output_base, "srt")
        write_srt_output(path, segments)
        payload["output_sha256"][path.name] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    if "json" in formats:
        write_json_output(output_file(output_base, "json"), payload)
    if progress_callback:
        progress_callback(100, duration, duration)
    return {
        "payload": payload,
        "output_base": output_base,
        "duration_seconds": duration,
        "elapsed_seconds": elapsed,
        "language": info.language,
        "language_probability": info.language_probability,
        "warnings": payload["warnings"],
    }


def positive_int(value: str) -> int:
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError('The value must be greater than zero.')
    return number


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description='Whisper Studio: local multilingual transcription on GPU or CPU.'
    )
    parser.add_argument("input", help='Audio/video file; the extension can be omitted')
    parser.add_argument(
        "--preset", choices=["speed", "balanced", "max"], default="balanced"
    )
    parser.add_argument(
        "--model", help='Whisper model or path to a local model'
    )
    parser.add_argument(
        "--compute-type", help='CTranslate2 precision; automatic if omitted'
    )
    parser.add_argument(
        "--language", help='Spoken language, for example it or en; auto if omitted'
    )
    parser.add_argument(
        "--task", choices=["transcribe", "translate"], default="transcribe"
    )
    parser.add_argument("--beam-size", type=positive_int)
    parser.add_argument("--batch-size", type=positive_int)
    parser.add_argument("--output-dir", default=str(OUTPUT_ROOT))
    parser.add_argument(
        "--formats",
        nargs="+",
        choices=["txt", "srt", "json"],
        default=["txt", "srt", "json"],
    )
    parser.add_argument("--device", choices=["auto", "cuda", "cpu"], default="auto")
    parser.add_argument("--cpu", action="store_true", help='Alias for --device cpu')
    parser.add_argument(
        "--no-vad", action="store_true", help='Transcribe all audio without filtering'
    )
    parser.add_argument(
        "--word-timestamps",
        action="store_true",
        help='Save word alignments in JSON',
    )
    parser.add_argument(
        "--initial-prompt", help='Context or technical terms for speech recognition'
    )
    parser.add_argument(
        "--audio-review", action=argparse.BooleanOptionalAction, default=True,
        help='Targeted second audio pass; use --no-audio-review to disable it',
    )
    parser.add_argument("--review-model", help='Second-pass model; automatic if omitted')
    return parser


def emit_phase(message: str) -> None:
    print(f"PHASE|{message}", flush=True)


def emit_progress(percent: float, current_seconds: float, total_seconds: float) -> None:
    print(
        f"PROGRESS|{max(0, min(100, percent)):.2f}|{current_seconds:.2f}|{total_seconds:.2f}",
        flush=True,
    )


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    model = None
    try:
        input_path = resolve_input_path(args.input)
        device = select_device("cpu" if args.cpu else args.device)
        defaults = choose_defaults(
            args.preset, detect_vram_gb(), device=device, task=args.task
        )
        model_name = args.model or defaults["model"]
        language = normalize_language(args.language)
        validate_model_task(model_name, language, args.task)
        compute_type = normalize_compute_type(device, args.compute_type)
        emit_phase(
            f"Loading model {model_name} on {device} (download on first use)"
        )
        model = create_model(model_name, device, compute_type)
        result = transcribe_file(
            input_path,
            model,
            preset=args.preset,
            compute_type=compute_type,
            beam_size=args.beam_size or defaults["beam_size"],
            batch_size=args.batch_size or defaults["batch_size"],
            language=language,
            task=args.task,
            output_dir=Path(args.output_dir).expanduser().resolve(),
            formats=args.formats,
            no_vad=args.no_vad,
            word_timestamps=args.word_timestamps,
            phase_callback=emit_phase,
            progress_callback=emit_progress,
            model_name=model_name,
            device=device,
            initial_prompt=args.initial_prompt,
        )
        if args.audio_review:
            from audio_review import attach_review

            def acquire_reviewer(name):
                nonlocal model
                unload_model(model)
                model = None
                emit_phase(f"Second audio pass: loading {name}")
                model = create_model(name, device, compute_type)
                return model

            attach_review(result, acquire_reviewer, device=device,
                model_name=args.review_model, phase_callback=emit_phase,
                progress_callback=emit_progress)
        print(f"Output: {result['output_base'].parent}")
        print(f"Model: {model_name} | {device} | {compute_type}")
        print(f"Language: {result['language']} ({result['language_probability']:.1%})")
        print(
            f"Audio duration: {result['duration_seconds']:.1f}s | processing: {result['elapsed_seconds']:.1f}s"
        )
        for warning in result["warnings"]:
            print(f"WARNING: {warning}")
        return 0
    except KeyboardInterrupt:
        print('Transcription interrupted.')
        return 130
    except (OSError, ValueError, RuntimeError) as exc:
        parser.exit(1, f"Error: {exc}\n")
    finally:
        unload_model(model)


if __name__ == "__main__":
    raise SystemExit(main())
