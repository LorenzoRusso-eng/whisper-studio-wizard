# Template comune delle lezioni

La proposta PDF mostra il template realmente compilato: due pagine con metadati,
testo, titoli, formule e segnaposto, una pagina dedicata alle tabelle,
una pagina dimostrativa dei box e una guida in italiano. Il testo dell'anteprima è materiale dimostrativo.
Non contiene la conversione delle lezioni Tognetti.

## Impostazione grafica

Testo serif Palatino con matematica coordinata; titoli ed etichette sans-serif;
accento blu petrolio, metadati su fondo chiaro, numeri di sezione in piccoli
riquadri arrotondati, didascalie e testatine coordinate. I box hanno angoli
arrotondati e un fondo uniforme specifico per categoria, senza bordi pesanti.

## Compilazione

Compilare `lecture-template.tex` con pdfLaTeX, due volte per i riferimenti.
Per l'anteprima di cinque pagine compilare `preview.tex`, che usa anche
`preview-content.tex`. La base per una lezione reale è `lecture-template.tex`:
sostituire soltanto il corpo campione, senza attivare `TemplatePreview`.
I file dell'anteprima non sono necessari al documento finale.
Le diciture tra parentesi quadre sono campi da compilare.

Il comando `\MakeLectureTitle` costruisce la testata. I metadati si compilano
nei comandi `\Course`, `\GeneralTopic`, `\LectureTitle`, `\LectureDate`,
`\Lecturer` e `\LectureNumber` definiti con `\providecommand` nel preambolo.
L'opzionale `\LectureScope` è vuoto per default: non aggiungere un riassunto
che non esista nella versione approvata.

In Whisper Studio questi campi si compilano nella scheda **LaTeX e PDF** e
si salvano per progetto. L'esportazione crea `metadata.tex` con valori testuali
già protetti tramite escaping; il documento finale lo include dopo
`documentclass`, prima dei valori di default. La data accetta GG/MM/AAAA o
AAAA-MM-GG, senza deduzioni dal nome dei file. Lo Scope vuoto viene omesso;
l'indice si aggiunge soltanto se richiesto dalla relativa opzione.
**Prepara prompt** permette di conservare il prompt e lo snapshot senza
avviare Codex; **Genera LaTeX** produce una nuova cartella di esportazione.

Se l'HTML approvato termina con **Additional material from the lecture slides**,
la sezione fa parte della lezione: mantenere testo, figure, formule, segnaposto
e citazioni con nome del PDF e pagine. I contenitori `lecture-supplements` /
`lecture-supplement` e le citazioni `slide-citation` non sono note editoriali
da eliminare. Le integrazioni vengono preparate durante la rielaborazione,
non inventate nel passaggio LaTeX. NDR, vecchie note di revisione e righe
tecniche `Sources:` rimangono escluse.

Dipendenze principali: mathpazo, helvet, lmodern, microtype, titlesec, caption,
enumitem, booktabs, tabularx, array, colortbl (tramite xcolor con opzione table),
longtable, multirow, etoolbox, tcolorbox con librerie skins e breakable,
hyperref e i pacchetti standard per matematica, grafica, margini e testatine.
Non è richiesto shell escape.

## Box e futura corrispondenza HTML

| Tipo HTML | Ambiente LaTeX | Uso |
| --- | --- | --- |
| `aside` | `AsideBox` | Digressione nominata dal docente, fuori dallo scopo attuale |
| `important` | `ImportantBox` | Concetto importante esplicitamente segnalato |
| `alert` | `AlertBox` | Ipotesi, limitazione, errore comune o cautela |
| `option` | `OptionBox` | Metodo alternativo o approfondimento facoltativo |
| `prof-suggestion` | `ProfSuggestionBox` | Consiglio metodologico o pratico espresso dal docente |

Esempio della convenzione da supportare nella futura fase HTML:

```html
<div class="lecture-callout" data-callout="aside" id="aside-001">
  <p class="callout-title">Related topic mentioned in passing</p>
  <p>Testo approvato del passaggio, nella sua posizione originale.</p>
</div>
```

Corrispondenza LaTeX:

```tex
\begin{AsideBox}{Related topic mentioned in passing}
\label{box:aside-001}
Testo approvato del passaggio, nella sua posizione originale.
\end{AsideBox}
```

L'ID identifica il blocco per tracciabilità. I box non hanno un contatore:
non usare `\ref` per attribuire loro un numero. Un'eventuale numerazione
dei box potrà essere aggiunta in una fase successiva.

Questa è una specifica per il passaggio futuro: l'editor HTML attuale non è
stato modificato per inserire o conservare gli attributi `data-callout`.
Prima di usarli andranno aggiornati sia editor sia sanitizzatori.

Per il consiglio del docente è già possibile usare la classe HTML conservata
dall'editor: `<div class="lecture-callout prof-suggestion" id="prof-suggestion-001">`.
La conversione riconosce sia questa classe sia `data-callout="prof-suggestion"`.
Un titolo può essere indicato con `<p class="callout-title">...</p>`.
I marcatori legacy `PROF SUGGESTION` / `END PROF SUGGESTION` delimitano lo stesso
tipo: il contenuto diventa `\begin{ProfSuggestionBox}{Titolo} ... \end{ProfSuggestionBox}`,
senza stampare i marcatori letterali. Questo è contenuto della lezione,
non una nota editoriale da escludere. Il box usa un fondo verde salvia uniforme.

I box non sono elementi flottanti: rimangono nel flusso. Quelli lunghi possono
proseguire sulla pagina successiva grazie a tcolorbox; non serve dividerli
manualmente. Non eliminare, sintetizzare o duplicare il contenuto.
Una classificazione dubbia si segnala alla revisione; non si inventa.

## Figure ed equazioni mancanti

I comandi `FigurePlaceholder` ed `EquationPlaceholder` riservano un numero
e mantengono un identificativo stabile. Registrare sempre file, pagina PDF,
pannello o posizione, contenuto atteso e azione manuale. Se sconosciuti,
indicarli come da verificare. Sostituire l'intero comando con l'elemento
definitivo mantenendo il suo `label`. Non inserire formule presunte.

Le istruzioni di lavoro nei segnaposto sono visibili nella bozza PDF;
andranno rimosse dopo il completamento. I riferimenti restano validi.
Le firme dei comandi restano invariate: cinque argomenti per la figura,
tre per l'equazione. L'altezza della figura riserva l'area grafica; il testo
di provenienza e azione si espande sotto, evitando di tagliare istruzioni lunghe.

## Tabelle

Lo stile segue le tabelle Highlights della lezione completata L11_27-10-2026:
sfondo bianco uniforme, separatori verticali sottili, filetti superiore,
inferiore e sotto l'intestazione, intestazioni sans-serif in blu petrolio,
didascalia sotto. La spaziatura è compatta (`scriptsize`, `tabcolsep=2pt`,
`arraystretch=1.1`). Le celle unite esprimono i raggruppamenti del contenuto.
Non applicare righe alternate o bande colorate e non dividere ogni riga con
una linea orizzontale. Le cinque colonne dell'esempio sono una struttura
adatta a quella tassonomia, non uno schema obbligatorio per tutte le lezioni.
Le label sono `tab:<id>`; passa ai comandi soltanto l'ID senza il prefisso.

### Tabella normale

```tex
\begin{LectureTable}{quantities}{Approved descriptive caption.}{|L|L|R|}
  [Optional approved note about the table.]
  \TableHead{Symbol} & \TableHead{Meaning} & \TableHead{Unit}\\
  \midrule
  $P$ & Applied pressure & $\mathrm{Pa}$\\
  $R$ & Electrical resistance & $\Omega$\\
\end{LectureTable}

See Table~\ref{tab:quantities}.
```

Argomenti: `[posizionamento]`, `{id}`, `{didascalia}`, `{colonne}`, `[nota]`.
Il corpo contiene le righe; il template aggiunge i filetti superiore e inferiore.
Indica la griglia nella specifica delle colonne, includendo i bordi esterni:
`|L|L|R|`. Il posizionamento predefinito è `!t`, come nel riferimento;
usa ad esempio `[htbp]` quando occorre mantenere la tabella vicina al testo.
`L`, `C`, `R` sono colonne flessibili allineate a sinistra, al centro o a destra;
`X` è la colonna flessibile standard. Puoi combinarle con `l`, `c`, `r` e
`p{larghezza}`: almeno una colonna flessibile deve essere presente in LectureTable.
La didascalia e la label vengono create una sola volta. Un ambiente `table`
esterno non serve. La nota è per informazioni scientifiche approvate, come
condizioni o unità; non vi si reinseriscono NDR, note editoriali o istruzioni.

### Tabella su più pagine

```tex
\begin{LectureLongTable}{comparison}{Approved comparison.}
  {|p{.18\linewidth}|p{.60\linewidth}|r|}
  {\TableHead{Method} & \TableHead{Description} & \TableHead{Unit}}
  [Optional approved note.]
  Approved entry & Approved description & Unit\\
  Another entry & Another approved description & Unit\\
\end{LectureLongTable}
```

Argomenti: `{id}`, `{didascalia}`, `{colonne}`, `{celle dell'intestazione}`,
`[nota]`. Nel corpo vanno solo le righe di dati. L'intestazione si ripete,
la didascalia sotto indica la continuazione e il numero della tabella resta unico.
Usa colonne `l/c/r/p{larghezza}`, non `X/L/C/R`; lascia spazio anche ai margini
delle celle. Non annidare l'ambiente in `table`, minipage o box, altrimenti
non può proseguire sulla pagina seguente. Non eliminare righe per farlo stare.

### Celle unite e intestazioni su più righe

Usa `\multirow{numero-righe}{\hsize}{\raggedright Testo}` nelle colonne
di testo a larghezza definita per i gruppi presenti nella fonte. Lascia vuote
le posizioni occupate dalla cella nelle righe successive; non ripetere il testo
come se fossero dati indipendenti. `\multicolumn` conserva gli accorpamenti
orizzontali. Per intestazioni compatte usa, ad esempio,
`\TableHead{\shortstack{Sensing\\principle}}`.
Non spezzare un gruppo multirow tra pagine: scegli il punto di interruzione
prima o dopo il gruppo. Le celle realmente vuote restano vuote, senza valori
o relazioni dedotti. L'anteprima mostra la struttura della tabella di riferimento.

### Tabella da inserire manualmente

```tex
\TablePlaceholder{comparison-to-insert}
  {Approved caption, or [To be completed].}
  {Source file; PDF page; table position, or [To be verified].}
  {Extract or transcribe the table; verify headings, values and units.}
  {22mm}

See Table~\ref{tab:comparison-to-insert}.
```

I cinque argomenti sono ID, didascalia, fonte, azione e altezza riservata.
Non aggiungere un secondo `label`: il comando crea `tab:<id>`.
Quando completi il segnaposto, usa lo stesso ID in LectureTable o
LectureLongTable. Le referenze create dall'editor HTML continueranno a funzionare.
La descrizione e l'azione del segnaposto non autorizzano a inventare celle,
valori, unità o intestazioni. Se la tabella manca, resta un segnaposto.

## Metadati e stile

Corso, tema generale, titolo specifico, data, docente, numero/ID e breve
descrizione del contenuto. Campi ignoti da compilare, senza deduzioni.
Lezioni in inglese, esposizione tecnica autonoma prevalentemente neutra o
impersonale, ordine e contenuto approvati conservati. Il modello di
rielaborazione ricavato dalle revisioni Tognetti è definito nel prompt di
generazione; la conversione LaTeX non riscrive il testo approvato.
Sezioni 1, sottosezioni 1.1, terzo livello 1.1.1 solo se utile.
LaTeX genera i numeri: non inserirli nel testo dei titoli.

## Contenuto da esportare

Il menu del tasto destro dell'editor consente segnaposto con label, richiami,
immagini inserite e NDR. La mappa `structure` del handoff registra ID, label,
ordine HTML e collegamenti. Le figure spostate mantengono l'identità: rispettare
la nuova posizione, senza dedurla dall'ordine dell'array delle figure.
La scelta `caption_mode: generate` autorizza a generare la sola didascalia
durante l'esportazione; le altre didascalie restano quelle scritte dall'utente.
Le NDR hanno ruolo editoriale e restano escluse dal PDF.

Il PDF della lezione contiene il corpo approvato e le sue sezioni, con figure,
formule, segnaposto e box didattici pertinenti. Non contiene note del revisore,
blocchi Editorial note / Slide context / Annotation, righe Sources, inventari
o descrizioni del processo ASR. Questi materiali restano nel progetto/revisione.
Le note obsolete non modificano né invalidano il testo approvato. I consigli
effettivi del docente e le citazioni bibliografiche nel corpo restano inclusi.

I file `PROMPT_ORGANIZZAZIONE_LEZIONE.md` e `PROMPT_HTML_TO_LATEX.md` contengono
le istruzioni operative aggiornate. La guida PDF illustra lo stile e l'uso;
i prompt Markdown definiscono la rielaborazione e il passaggio di formato.
La conversione è disponibile nella scheda **LaTeX e PDF** di Whisper Studio.
