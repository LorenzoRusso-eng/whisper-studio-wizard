# Shared lecture template

`lecture-template.tex` is the base for a real lesson. Replace its sample body
with the approved lesson content. Preview documents demonstrate the design;
they are not lecture sources and are not required by the final document.

## Appearance and compilation

The template uses Palatino serif text with coordinated mathematics,
sans-serif headings/labels, a petroleum-blue accent, a light metadata panel,
rounded section numbers, coordinated captions, and running headers. Teaching
boxes have rounded corners and a solid background for their category.

Compile twice with pdfLaTeX for stable references, without shell escape:

```text
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
```

The main packages include mathpazo, helvet, lmodern, microtype, titlesec,
caption, enumitem, booktabs, tabularx, array, colortbl through xcolor's table
option, longtable, multirow, etoolbox, tcolorbox with skins/breakable,
hyperref, and standard mathematics/graphics/page-layout packages.

## Metadata

Set `\Course`, `\GeneralTopic`, `\LectureTitle`, `\LectureDate`,
`\Lecturer`, and `\LectureNumber`. `\MakeLectureTitle` creates the heading
and metadata panel. `\LectureScope` is optional and empty by default; it is
supplied approved text, not a summary to generate. Bracketed fields are
completion markers, never facts to infer.

In Whisper Studio, use **LaTeX and PDF → Save metadata**. Dates accept
DD/MM/YYYY or YYYY-MM-DD and are saved as ISO. Unknown dates remain unknown.
The app creates escaped plain-text values in `metadata.tex`; include it
immediately after documentclass and before the template's providecommand
defaults. Metadata do not authorize changing the approved lesson body.
Include the table of contents only when the project's option requests it.

**Prepare prompt** preserves a snapshot and effective prompt without calling
the assistant. **Generate LaTeX** creates a new export folder. Neither repeats
Whisper. The frozen contract identifies all input files and helpers.

## Approved lesson content

The PDF contains the approved body, figures, formulas, placeholders, and
teaching boxes. It excludes editorial notes, review-only blocks, technical
Sources lines, inventories, and ASR process descriptions. Obsolete review
notes do not override user-approved text. Authentic lecturer advice and
relevant bibliographic citations in the body are preserved.

The final **Additional material from the lecture slides** section is approved
lesson content when present. Preserve its `lecture-supplements` and
`lecture-supplement` blocks and `slide-citation` references, including actual
PDF filenames and page numbers. It is not a review note to discard. New slide
supplements are created during organization, not invented during LaTeX export.

HTML order determines where figures belong, including figures moved by the
user. The handoff's `structure` maps IDs, labels, order, and references.
Do not restore the order of the figures array. User-inserted image assets and
written captions are preserved. Only caption_mode generate authorizes a new
caption, without rewriting the surrounding prose.

## Teaching boxes

| Approved HTML role | LaTeX environment | Use |
| --- | --- | --- |
| `aside` | `AsideBox` | An explicitly identified aside outside the current scope |
| `important` | `ImportantBox` | An explicitly marked important concept |
| `alert` | `AlertBox` | A caution, assumption, limitation, or common error |
| `option` | `OptionBox` | An optional extension or alternative method |
| `prof-suggestion` | `ProfSuggestionBox` | Practical or methodological advice from the lecturer |

For example:

```html
<div class="lecture-callout" data-callout="aside" id="aside-001">
  <p class="callout-title">Related topic mentioned in passing</p>
  <p>The approved passage, at its original position.</p>
</div>
```

```tex
\begin{AsideBox}{Related topic mentioned in passing}
\label{box:aside-001}
The approved passage, at its original position.
\end{AsideBox}
```

Box IDs provide traceability. These boxes have no counter: do not use ref to
give them a number. Preserve their title, content, and position without
duplicating prose outside. Do not infer a new classification from perceived
importance. Unknown or ambiguous classifications are documented for review.

Do not assume data-callout survives every editor/sanitizer. The current
`lecture-callout prof-suggestion` class is preserved and can identify a
ProfSuggestionBox, with a callout-title child for its title. Legacy
`PROF SUGGESTION` / `END PROF SUGGESTION` delimiters identify the same lecturer
advice; preserve its content without printing delimiters or reclassifying it
as an editorial note. The box uses a solid sage-green background.

Boxes remain in the text flow. Long boxes can continue on the next page
through tcolorbox; avoid unnecessary manual splitting, nesting, truncation,
or tiny type. Editorial notes retain their review-only role and are excluded
even when visually styled like a callout. Inline editorial notes must be
removed without losing any surrounding paragraph text.

## Missing figures and equations

`FigurePlaceholder` reserves a figure number and graphical area. Its five
arguments are ID, caption, source, manual action, and reserved height:

```tex
\FigurePlaceholder{fig04}
  {Approved descriptive caption, or [To be completed].}
  {Source file; PDF page; panel, or [To be verified].}
  {Extract or insert the specified figure manually.}
  {45mm}
```

It creates label fig:fig04. Pass the ID without fig: and do not add a second
label. Source/action text expands below the reserved area so long instructions
are not clipped. Preserve all instructions until manual completion. Replace
the whole command with the final element while retaining its label.

`EquationPlaceholder` takes three arguments and creates its equation number
and eq: label:

```tex
\EquationPlaceholder{eq07}
  {Meaning of the missing relation and known variables.}
  {Source file; PDF page; position; manual transcription required.}
```

Record expected content, source, position, and action. Use verification or
completion markers for unknown details. Do not invent a plausible formula
or image to fill a placeholder.

For existing equations, use the saved data-latex source and preserve inline
versus display format and the stable label. Referenced inline formulas reserve
their number in place with refstepcounter/label and remain inside the paragraph.

## Tables

The Highlights-style table has a white background, thin vertical separators,
top/header/bottom rules, petroleum-blue sans-serif headings, and a caption
below. Spacing is compact: scriptsize, tabcolsep 2pt, arraystretch 1.1.
Do not add alternating row colors or a horizontal rule after every row.
Preserve row/column order, merged cells, blank cells, values, units, notes,
captions, and labels. The example's column count is not a requirement for
other tables. Pass label IDs without the tab: prefix.

### Ordinary table

```tex
\begin{LectureTable}{quantities}{Approved descriptive caption.}{|L|L|R|}
  [Optional approved scientific note.]
  \TableHead{Symbol} & \TableHead{Meaning} & \TableHead{Unit}\\
  \midrule
  $P$ & Applied pressure & $\mathrm{Pa}$\\
  $R$ & Electrical resistance & $\Omega$\\
\end{LectureTable}

See Table~\ref{tab:quantities}.
```

Arguments: optional [placement], {id}, {caption}, {columns}, optional [note].
The body contains rows; the template adds the top/bottom rules and a single
caption/label. Specify the full vertical grid, such as `|L|L|R|`.
The default placement is !t; [htbp] may keep a table closer to its discussion.
L/C/R are flexible left/center/right-aligned columns and X is the standard
flexible column. Combine them with l/c/r/p{width}; LectureTable requires at
least one flexible column. Do not wrap it in another table environment.
The optional note is for approved scientific context, not editorial notes.

### Multipage table

```tex
\begin{LectureLongTable}{comparison}{Approved comparison.}
  {|p{.18\linewidth}|p{.60\linewidth}|r|}
  {\TableHead{Method} & \TableHead{Description} & \TableHead{Unit}}
  [Optional approved scientific note.]
  Approved entry & Approved description & Unit\\
  Another entry & Another approved description & Unit\\
\end{LectureLongTable}
```

Arguments: {id}, {caption}, {columns}, {header cells}, optional [note]. The
body contains data rows only. Headers repeat and continuation captions retain
one table number. Use l/c/r/p{width}, not X/L/C/R, and allow cell padding in
width calculations. Do not nest it inside table, minipage, or a box: that would
prevent page continuation. Never drop rows to make it fit.

Use multirow for shared vertical cells and multicolumn for horizontal merges.
Leave covered positions empty in later rows instead of repeating shared text
as independent data. TableHead with shortstack supports compact multiline
headers. Keep a multirow group on one page, breaking before or after it.
Truly blank cells remain blank without inferred values or relationships.

### Manual table placeholder

```tex
\TablePlaceholder{comparison-to-insert}
  {Approved caption, or [To be completed].}
  {Source file; PDF page; table position, or [To be verified].}
  {Extract or transcribe the table; verify headings, values, and units.}
  {22mm}

See Table~\ref{tab:comparison-to-insert}.
```

The five arguments are ID, caption, source, action, and reserved height. The
command creates tab:<id>; do not add another label. When completing it, reuse
the ID in LectureTable or LectureLongTable so existing references still work.
A placeholder description does not authorize invented cells, values, units,
or headings. A missing table remains a placeholder.

## Prompts and verification

Use English autonomous technical exposition and preserve the approved order
and content. LaTeX generates structural numbers: do not put them into heading
text. Use section/subsection/subsubsection where supported by the source.
Missing metadata are completion fields, not facts to infer.

The operational rules are in `PROMPT_LECTURE_ORGANIZATION.md` and
`PROMPT_HTML_TO_LATEX.md` in the application root. The LaTeX prompt requires
sequential content/structure checks, unique resolved references, compilation,
visual review of all final pages, and unchanged original inputs. Report
unavailable tools and incomplete checks honestly. Explicit manual placeholders
are preserved and listed in the report.
