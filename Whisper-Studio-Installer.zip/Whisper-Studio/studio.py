"""Cross-platform desktop entry point (also works without Whisper installed)."""
from __future__ import annotations

import sys
from pathlib import Path
from studio_runtime import ROOT, load_installation, venv_python


def main():
    import argparse
    parser=argparse.ArgumentParser(description='Whisper Studio: lezioni, installazione e demo')
    parser.add_argument('--setup',action='store_true')
    parser.add_argument('--demo',action='store_true')
    parser.add_argument('--project',help='Cartella della lezione da aprire')
    args=parser.parse_args()
    if args.setup or not load_installation():
        from setup_wizard import main as setup
        return setup([])
    if args.demo:
        from studio_demo import main as demo
        return demo([])
    try:
        import tkinter as tk
        from lecture_ui import LectureApp
        root=tk.Tk();app=LectureApp(root)
        if args.project:app.load_folder(args.project)
        elif not app.variables['folder'].get():
            defaults=load_installation();source=defaults.get('initial_transcript')
            if source and Path(source).is_file():
                app.apply_config({**defaults,'folder':str(ROOT/'projects'/Path(source).stem),
                                  'title':Path(source).stem,'transcript':source,'language':'auto'})
        root.mainloop()
        for controller in (app.controller,app.latex_controller):
            if controller.thread is not None:controller.thread.join()
        return 0
    except ImportError as exc:
        print(f'Dipendenze mancanti: {exc}. Avvia di nuovo il wizard di installazione.',file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
