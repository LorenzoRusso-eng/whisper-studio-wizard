"""Print a self-contained SVG to a vector PDF with an isolated headless browser."""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


def browser_executable():
    for name in ('google-chrome','google-chrome-stable','chromium','chromium-browser','microsoft-edge','msedge'):
        found=shutil.which(name)
        if found:return found
    for value in ('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
                  '/Applications/Chromium.app/Contents/MacOS/Chromium'):
        if Path(value).is_file():return value
    for name in ('chrome', 'chrome.exe', 'msedge', 'msedge.exe', 'chromium', 'chromium-browser'):
        found = shutil.which(name)
        if found:
            return found
    for variable in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA'):
        root = os.environ.get(variable)
        if not root:
            continue
        for relative in ('Google/Chrome/Application/chrome.exe', 'Microsoft/Edge/Application/msedge.exe'):
            candidate = Path(root) / relative
            if candidate.is_file():
                return str(candidate)
    raise FileNotFoundError('Chrome/Edge non trovato per la conversione vettoriale SVG → PDF')


def svg_to_pdf(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    if source == output:
        raise ValueError('La destinazione PDF deve essere diversa dalla sorgente SVG')
    svg = source.read_text(encoding='utf-8')
    root = ET.fromstring(svg)
    if root.tag.rsplit('}', 1)[-1] != 'svg':
        raise ValueError('La sorgente non è un SVG')
    viewbox = root.get('viewBox', '').replace(',', ' ').split()
    if len(viewbox) != 4:
        raise ValueError('L’SVG deve dichiarare un viewBox con quattro valori')
    width, height = float(viewbox[2]), float(viewbox[3])
    if not 0 < width <= 20000 or not 0 < height <= 20000:
        raise ValueError('Dimensioni SVG non valide')
    for element in root.iter():
        if element.tag.rsplit('}', 1)[-1] in {'script', 'foreignObject'}:
            raise ValueError('L’SVG deve essere un asset grafico autonomo, senza script')
        for key, value in element.attrib.items():
            if key.lower().startswith('on') or (key.rsplit('}', 1)[-1] == 'href' and not value.startswith('#')):
                raise ValueError('L’SVG contiene contenuti attivi o riferimenti esterni')
    browser = browser_executable()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.svg-render-', dir=output.parent) as temporary:
        temporary = Path(temporary)
        html = temporary / 'figure.html'
        rendered = temporary / 'figure.pdf'
        html.write_text(f'<!doctype html><meta charset="utf-8"><style>'
                        f'@page{{size:{width}px {height}px;margin:0}}'
                        f'html,body{{margin:0;width:{width}px;height:{height}px;overflow:hidden;background:white}}'
                        'svg{display:block;width:100%;height:100%}</style>' + svg, encoding='utf-8')
        command = [browser, '--headless=new', '--disable-gpu', '--disable-extensions',
                   '--disable-background-networking', '--no-first-run', '--no-default-browser-check',
                   '--no-pdf-header-footer', '--hide-scrollbars',
                   '--user-data-dir=' + str(temporary / 'profile'),
                   '--print-to-pdf=' + str(rendered), html.as_uri()]
        options = {}
        if os.name == 'nt':
            startup = subprocess.STARTUPINFO()
            startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startup.wShowWindow = subprocess.SW_HIDE
            options = {'startupinfo': startup, 'creationflags': subprocess.CREATE_NO_WINDOW}
        process = subprocess.run(command, capture_output=True, timeout=90, **options)
        if process.returncode or not rendered.is_file():
            error = process.stderr.decode('utf-8', errors='replace')[-1200:]
            raise RuntimeError('Conversione SVG → PDF non completata: ' + error)
        from pypdf import PdfReader
        reader = PdfReader(rendered)
        if len(reader.pages) != 1:
            raise ValueError('La figura deve produrre esattamente una pagina PDF')
        page = reader.pages[0]
        expected = (width * .75, height * .75)
        actual = (float(page.mediabox.width), float(page.mediabox.height))
        if any(abs(a - e) > 2 for a, e in zip(actual, expected)):
            raise ValueError('Il browser non ha rispettato le dimensioni della figura')
        shutil.copyfile(rendered, output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='SVG autonomo con viewBox')
    parser.add_argument('output', type=Path, help='PDF vettoriale da creare nella cartella di esportazione')
    args = parser.parse_args()
    print(svg_to_pdf(args.source, args.output))


if __name__ == '__main__':
    main()
