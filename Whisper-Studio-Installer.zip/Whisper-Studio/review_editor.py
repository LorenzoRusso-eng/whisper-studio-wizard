"""Local lecture editor and durable handoff to the later LaTeX stage."""

from __future__ import annotations

import argparse
import copy
import hashlib
import html
import json
import mimetypes
import os
import re
import threading
import uuid
import webbrowser
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse
from filelock import FileLock
from lecture_markup import HTML_ATTRIBUTES, IDENTIFIER, MAX_IMAGE_BYTES, label_for, store_image, structure, validate_image_asset

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "editor"
LOCK = threading.RLock()
MAX_PROJECT_BYTES = 30_000_000


def now():
    return datetime.now(timezone.utc).isoformat()


def atomic_text(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def write_json(path, data):
    atomic_text(path, json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


class Cleaner(HTMLParser):
    """Keep editable prose/slots, never executable content from an imported file."""
    tags = {"p", "div", "span", "h1", "h2", "h3", "h4", "strong", "b", "em", "i",
            "u", "s", "sub", "sup", "br", "hr", "blockquote", "ul", "ol", "li", "a",
            "code", "pre", "table", "thead", "tbody", "tr", "th", "td", "figure"}
    dangerous = {"script", "style", "iframe", "object", "embed", "svg", "math"}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.output, self.stack, self.skip = [], [], 0

    def handle_starttag(self, tag, attrs):
        if self.skip or tag in self.dangerous:
            self.skip += 1
            return
        if tag not in self.tags:
            return
        allowed = []
        for key, value in attrs:
            value = value or ""
            if key in {"id", "class", "data-block-id", "data-latex", "data-figure-id", "colspan", "rowspan"} | HTML_ATTRIBUTES:
                allowed.append((key, value))
            elif key == "href" and not re.match(r"\s*(javascript|data|vbscript):", value, re.I):
                allowed.append((key, value))
        attributes = "".join(f' {key}="{html.escape(value, quote=True)}"' for key, value in allowed)
        self.output.append(f"<{tag}{attributes}>")
        if tag not in {"br", "hr"}:
            self.stack.append(tag)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in {"br", "hr"}:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if self.skip:
            self.skip -= 1
            return
        if tag in self.stack:
            while self.stack:
                current = self.stack.pop()
                self.output.append(f"</{current}>")
                if current == tag:
                    break

    def handle_data(self, data):
        if not self.skip:
            self.output.append(html.escape(data, quote=False))

    def result(self):
        return "".join(self.output) + "".join(f"</{tag}>" for tag in reversed(self.stack))


def clean_html(source):
    parser = Cleaner()
    parser.feed(source)
    return parser.result()


def plain(source):
    return html.unescape(re.sub(r"<[^>]+>", "", source)).strip()


def prepare_lesson(folder: Path) -> dict:
    folder = folder.resolve()
    project_path = folder / "lecture_project.json"
    if project_path.exists():
        project = json.loads(project_path.read_text(encoding="utf-8"))
        render_project(folder, project)
        return project
    source = (folder / "lecture.html").read_text(encoding="utf-8")
    match = re.search(r'<article class="notes">([\s\S]*?)</article>', source)
    if not match:
        raise ValueError('Unrecognized lesson HTML document')
    content = re.sub(r'<div class="toc">[\s\S]*?</ol></div>', "", match.group(1))
    figures = []

    def figure_slot(match):
        markup, identifier = match.group(0), match.group(1)
        title = re.search(r"<h3>([\s\S]*?)</h3>", markup)
        caption = re.search(r"<figcaption>([\s\S]*?)</figcaption>", markup)
        caption_text = plain(caption[1]) if caption else ""
        explicit_source = re.search(r'\bdata-source="([^"]+)"', markup.split(">", 1)[0])
        page_label = re.search(r"\b[A-Z]\d+(?:-[A-Z]?\d+)?\b", caption_text)
        annotated_page = re.search(r"annotated PDF page (\d+)", caption_text, re.I)
        source_label = (html.unescape(explicit_source[1]) if explicit_source else
                        page_label[0] if page_label else
                        "Annotated PDF p. " + annotated_page[1] if annotated_page else
                        "Source not specified")
        figures.append({"id": identifier, "title": plain(title[1]) if title else identifier,
            "asset": f"assets/{identifier}.svg", "caption": caption_text,
            "source": source_label, "notes": []})
        return f'<figure data-figure-id="{identifier}"></figure>'

    content = re.sub(r'<figure class="diagram" id="([\w-]+)"(?:\s+data-source="[^"]*")?>[\s\S]*?</figure>', figure_slot, content)
    markdown = (folder / "lecture_notes.md").read_text(encoding="utf-8")
    formula_sources = re.findall(r"\\\[([\s\S]*?)\\\]", markdown)
    if len(formula_sources) != len(re.findall(r'<div class="equation">[\s\S]*?</div>', content)):
        raise ValueError('The number of HTML formulas does not match the LaTeX sources in the Markdown')
    formulae = iter(formula_sources)

    def formula_slot(match):
        latex = next(formulae, "").strip().rstrip(".,")
        return f'<div class="equation" data-latex="{html.escape(latex, quote=True)}">{html.escape(latex)}</div>'

    content = re.sub(r'<div class="equation">[\s\S]*?</div>', formula_slot, content)
    title = re.search(r"<h1>([\s\S]*?)</h1>", content)
    inventory = json.loads((folder / "source_inventory.json").read_text(encoding="utf-8")) if (folder / "source_inventory.json").exists() else {}
    project = {"schema_version": 1, "project_id": str(uuid.uuid4()), "lesson": folder.name,
        "revision": 0, "title": plain(title[1]) if title else folder.name,
        "language": "en", "voice": "direct", "created_at": now(), "updated_at": now(),
        "document": {"html": clean_html(content), "markdown": markdown}, "figures": figures,
        "sources": inventory, "audio_review_file": "audio_review.json" if (folder / "audio_review.json").exists() else None}
    atomic_text(folder / ".editor-template.html", source)
    write_json(project_path, project)
    publish_handoff(folder, project)
    render_project(folder, project)
    return project


def validate_project(project, current, *, folder=None):
    if not isinstance(project, dict) or project.get("schema_version") != 1:
        raise ValueError('Invalid project format')
    if project.get("project_id") != current["project_id"]:
        raise ValueError('The project belongs to another lesson')
    document = project.get("document")
    if not isinstance(document, dict) or not all(isinstance(document.get(k), str) for k in ("html", "markdown")):
        raise ValueError('Invalid project text')
    if not document["html"].strip() or not document["markdown"].strip():
        raise ValueError('The document cannot be empty')
    known = {f["id"]: copy.deepcopy(f) for f in current["figures"]}
    if (not isinstance(project.get("figures"), list) or len(project["figures"]) > 1000
        or not all(isinstance(f, dict) for f in project["figures"])
        or not all(isinstance(f.get('id'),str) and IDENTIFIER.fullmatch(f['id']) for f in project['figures'])
        or len({f['id'] for f in project['figures']}) != len(project['figures'])):
        raise ValueError('Figure identifiers do not match')
    result = copy.deepcopy(current)
    result["title"] = str(project.get("title", current["title"]))[:500]
    result["document"] = {"html": clean_html(document["html"]), "markdown": document["markdown"]}
    for figure in project["figures"]:
        if figure['id'] not in known:
            if figure.get('kind') != 'image' or folder is None:raise ValueError('Invalid new figure')
            asset = store_image(folder,figure['embedded_data']) if figure.get('embedded_data') else validate_image_asset(folder,figure.get('asset'))
            known[figure['id']] = {'id':figure['id'],'kind':'image','asset':asset,
                'title':str(figure.get('title') or 'Imported figure')[:500],
                'source':str(figure.get('source') or 'User-supplied image')[:2000]}
            if figure.get('embedded_data'):
                pattern=r'(<!-- FIGURE:'+re.escape(figure['id'])+r' -->[\s\S]*?!\[[^\n]*\]\()'+re.escape(str(figure.get('asset','')))+r'(\))'
                result['document']['markdown']=re.sub(pattern,lambda match:match[1]+asset+match[2],result['document']['markdown'],count=1)
        original = known[figure["id"]]
        original["caption"] = str(figure.get("caption", ""))[:20000]
        if 'label' in figure:original['label']=label_for(figure['label'],'figure',figure['id'])
        if 'caption_mode' in figure:
            if figure['caption_mode'] not in {'manual','generate'}:raise ValueError('Invalid caption mode')
            original['caption_mode']=figure['caption_mode']
        if 'caption_prompt' in figure:original['caption_prompt']=str(figure['caption_prompt'])[:10000]
        notes = figure.get("notes", [])
        if not isinstance(notes, list) or len(notes) > 200:
            raise ValueError('Invalid figure note list')
        original["notes"] = []
        for note in notes:
            if not isinstance(note, dict) or note.get("status") not in {"pending", "done"}:
                raise ValueError('Invalid figure note')
            original["notes"].append({"id": str(note.get("id", uuid.uuid4().hex))[:100],
                "text": str(note.get("text", ""))[:20000], "status": note["status"]})
    # The submitted figure list is authoritative. The structural check below still
    # rejects a missing slot, an orphan figure, a duplicate or a dangling reference.
    # save_project archives the previous metadata; binary assets are retained.
    result["figures"] = [known[figure['id']] for figure in project['figures']]
    structure(result,validate=True)
    return result


def CounterList(values):
    from collections import Counter
    return Counter(values)


def publish_handoff(folder, project):
    from latex_settings import load_settings
    atomic_text(folder / "lecture_notes.md", project["document"]["markdown"])
    rows = ["# Figure instructions for the LaTeX stage", "", f"Project revision: {project['revision']}", ""]
    for figure in project["figures"]:
        rows += [f"## {figure['id']} - {figure['title']}", "",
                 "Asset: " + figure["asset"], "", "Caption: " + figure["caption"], ""]
        rows += ['Label: '+label_for(figure.get('label'),'figure',figure['id']),
                 'Caption mode: '+figure.get('caption_mode','manual'),
                 'Caption guidance: '+figure.get('caption_prompt',''), '']
        for note in figure["notes"]:
            rows += [f"- [{'x' if note['status'] == 'done' else ' '}] {note['text']}"]
        rows.append("")
    atomic_text(folder / "figure_notes.md", "\n".join(rows))
    write_json(folder / "latex_handoff.json", {"schema_version": 1,
        "project_id": project["project_id"], "revision": project["revision"],
        "language": project["language"], "voice": project["voice"],
        "authoritative_project": "lecture_project.json", "edited_markdown": "lecture_notes.md",
        "figure_instructions": "figure_notes.md", "figures": project["figures"],
        "audio_review": project.get("audio_review_file"),
        "latex": load_settings(folder),
        "structure": structure(project),
        "instruction": "Use the saved edited text. Apply pending figure instructions and retain an audit of their resolution. Do not regenerate from the old ASR transcript."})


def render_project(folder, project):
    from figure_comparison import render_comparison
    template = (folder / ".editor-template.html").read_text(encoding="utf-8")
    bootstrap = {"project": project, "review": None, "figure_svgs": {}}
    for figure in project["figures"]:
        asset = (folder / figure["asset"]).resolve()
        if asset.is_relative_to(folder.resolve()) and asset.suffix.lower() == ".svg" and asset.is_file():
            bootstrap["figure_svgs"][figure["id"]] = asset.read_text(encoding="utf-8")
    report = folder / (project.get("audio_review_file") or "audio_review.json")
    if report.is_file():
        bootstrap["review"] = json.loads(report.read_text(encoding="utf-8"))
    relative = editor_asset_url(folder)
    head = f'<link rel="stylesheet" href="{relative}/editor.css"><link rel="stylesheet" href="{relative}/vendor/katex/katex.min.css">'
    scripts = f'<script id="lecture-editor-data" type="application/json">{json.dumps(bootstrap, ensure_ascii=False).replace("<", chr(92)+"u003c")}</script><script defer src="{relative}/vendor/katex/katex.min.js"></script><script defer src="{relative}/insertions.js"></script><script defer src="{relative}/editor.js"></script>'
    body = re.sub(r'<article class="notes">[\s\S]*?</article>',
        lambda m: '<article class="notes" id="lecture-document">' + project["document"]["html"] + '</article>', template)
    body = body.replace("</head>", head + "</head>").replace("</body>", scripts + "</body>")
    if 'href="figure-comparison.html"' not in body:
        body = body.replace('</nav>', '<a href="figure-comparison.html">Compare figures</a></nav>', 1)
    atomic_text(folder / "figure-comparison.html", render_comparison(folder, project))
    atomic_text(folder / "lecture.html", body)


def editor_asset_url(folder):
    try:
        return os.path.relpath(ASSETS, folder).replace("\\", "/")
    except ValueError:  # Project and application can be on different Windows drives.
        return ASSETS.as_uri()


def save_project(folder, candidate, expected_revision):
    with LOCK, FileLock(folder / ".project-save.lock", timeout=10):
        current = json.loads((folder / "lecture_project.json").read_text(encoding="utf-8"))
        if type(expected_revision) is not int or expected_revision != current["revision"]:
            raise FileExistsError('The project was updated in another window. Export your draft before reloading.')
        if (folder / "lecture_notes.md").read_text(encoding="utf-8") != current["document"]["markdown"]:
            raise FileExistsError('The Markdown was modified outside the editor. The file is preserved; reconcile changes before saving.')
        validated = validate_project(candidate, current, folder=folder)
        same = all(validated[k] == current[k] for k in ("document", "figures", "title"))
        if same:
            return current
        write_json(folder / "revisions" / "editor" / f"revision-{current['revision']:05d}.json", current)
        validated["revision"] += 1
        validated["updated_at"] = now()
        write_json(folder / "lecture_project.json", validated)
        publish_handoff(folder, validated)
        render_project(folder, validated)
        return validated


def make_server(notes_root: Path, port=8765, *, projects=None, audio_sources=None):
    notes_root = notes_root.resolve()
    project_map = {key: Path(value).resolve() for key, value in (projects or {}).items()}
    selected_audio = {key: Path(value).resolve() for key, value in (audio_sources or {}).items()}

    def lesson(slug):
        if not re.fullmatch(r"[A-Za-z0-9_-]+", slug):
            raise ValueError('Invalid lesson')
        folder = project_map.get(slug, (notes_root / slug).resolve())
        if (slug not in project_map and not folder.is_relative_to(notes_root)) or not (folder / "lecture_project.json").is_file():
            raise FileNotFoundError('Project not found')
        return folder

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send_json(self, status, data):
            raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)

        def valid_host(self):
            host = self.headers.get("Host", "").split(":")[0]
            return host in {"127.0.0.1", "localhost", "[::1]"}

        def do_GET(self):
            if not self.valid_host():
                return self.send_json(403, {"error": 'Host not allowed'})
            try:
                route = unquote(urlparse(self.path).path)
                if route == "/api/health":
                    return self.send_json(200, {"service": "whisper-lecture-editor", "notes_root": str(notes_root),
                        "editor_features":["structured-insertions","structured-deletions","image-upload"]})
                if route == "/":
                    listed = project_map or {p.name:p for p in notes_root.iterdir() if p.is_dir() and (p / "lecture_project.json").is_file()}
                    content = '<!doctype html><html lang="en"><meta charset="utf-8"><title>Lessons</title><h1>Editable lessons</h1>' + "".join(f'<p><a href="/lesson/{html.escape(key, quote=True)}/lecture.html">{html.escape(folder.name)}</a></p>' for key,folder in listed.items())
                    raw = content.encode("utf-8")
                    self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
                    return
                match = re.fullmatch(r"/api/(project|review|audio)/([\w-]+)", route)
                if match:
                    kind, slug = match.groups(); folder = lesson(slug)
                    if kind in {"project", "review"}:
                        name = "lecture_project.json" if kind == "project" else "audio_review.json"
                        return self.send_json(200, json.loads((folder / name).read_text(encoding="utf-8")))
                    if slug in selected_audio:
                        target = selected_audio[slug]
                    else:
                        source = json.loads((folder / "sources" / "transcript.json").read_text(encoding="utf-8-sig"))
                        target = Path(source["input"]).resolve()
                        if not target.is_relative_to((ROOT / "Audio").resolve()):
                            raise ValueError('Audio is not in the local library')
                    return self.send_file(target, ranges=True)
                match = re.fullmatch(r"/lesson/([\w-]+)/(.+)", route)
                if match:
                    folder = lesson(match[1]); relative = match[2]
                    if "/editor/" in route or relative.startswith("../../editor/"):
                        raise ValueError('Invalid path')
                    target = (folder / relative).resolve()
                    if not target.is_relative_to(folder) or any(part.startswith(".") for part in Path(relative).parts):
                        raise ValueError('Invalid path')
                    if target.suffix.lower() not in {".html", ".json", ".md", ".svg", ".png", ".jpg", ".jpeg", ".webp"}:
                        raise ValueError('File type not allowed')
                    return self.send_file(target, lesson_html=target.name == "lecture.html")
                # Relative asset URLs from /lesson/<id>/ resolve to /editor/.
                if route.startswith("/editor/"):
                    target = (ASSETS / route.removeprefix("/editor/")).resolve()
                    if not target.is_relative_to(ASSETS.resolve()):
                        raise ValueError('Invalid path')
                    return self.send_file(target)
                raise FileNotFoundError('Page not found')
            except FileNotFoundError as exc:
                self.send_json(404, {"error": str(exc)})
            except (ValueError, KeyError, json.JSONDecodeError) as exc:
                self.send_json(400, {"error": str(exc)})

        def send_file(self, target, ranges=False, lesson_html=False):
            if lesson_html:
                raw = target.read_text(encoding="utf-8").replace('"' + editor_asset_url(target.parent) + '/', '"/editor/').encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(raw)
                return
            size = target.stat().st_size
            start, end, status = 0, max(0, size - 1), 200
            requested = self.headers.get("Range") if ranges else None
            if requested:
                match = re.fullmatch(r"bytes=(\d+)-(\d*)", requested)
                if not match or int(match[1]) >= size:
                    return self.send_json(416, {"error": 'Invalid range'})
                start, end = int(match[1]), min(int(match[2]) if match[2] else size-1, size-1)
                if end < start:
                    return self.send_json(416, {"error": 'Invalid range'})
                status = 206
            self.send_response(status)
            content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            self.send_header("Content-Type", content_type + ("; charset=utf-8" if content_type.startswith("text/") else ""))
            self.send_header("Content-Length", str(end-start+1))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if ranges:
                self.send_header("Accept-Ranges", "bytes")
                if status == 206:
                    self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            with target.open("rb") as stream:
                stream.seek(start); left = end-start+1
                while left:
                    block = stream.read(min(65536, left))
                    if not block:
                        break
                    try:
                        self.wfile.write(block)
                    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                        break
                    left -= len(block)

        def do_POST(self):
            if not self.valid_host():
                return self.send_json(403, {"error": 'Host not allowed'})
            origin = self.headers.get("Origin")
            if origin and origin not in {f"http://127.0.0.1:{self.server.server_port}", f"http://localhost:{self.server.server_port}"}:
                return self.send_json(403, {"error": 'Origin not allowed'})
            try:
                match = re.fullmatch(r"/api/(project|assets)/([\w-]+)", urlparse(self.path).path)
                if not match or self.headers.get_content_type() != "application/json":
                    raise ValueError('Invalid request')
                length = int(self.headers.get("Content-Length", 0))
                if not 0 < length <= (MAX_IMAGE_BYTES*4//3+1000 if match[1]=='assets' else MAX_PROJECT_BYTES):
                    raise ValueError('Invalid project size')
                request = json.loads(self.rfile.read(length))
                if match[1]=='assets':
                    return self.send_json(200, {'asset':store_image(lesson(match[2]),request['data'])})
                saved = save_project(lesson(match[2]), request["project"], request["expected_revision"])
                self.send_json(200, {"project": saved})
            except FileExistsError as exc:
                self.send_json(409, {"error": str(exc)})
            except (ValueError, KeyError, TypeError, FileNotFoundError) as exc:
                self.send_json(400, {"error": str(exc)})
            except OSError as exc:
                self.send_json(500, {"error": f"Save failed: {exc}"})

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def main():
    parser = argparse.ArgumentParser(description='Local lesson editor')
    parser.add_argument("command", choices=("prepare", "serve", "open"))
    parser.add_argument("lesson", nargs="?")
    parser.add_argument("--notes-root", type=Path, default=ROOT / "notes")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--project-dir", type=Path, help='Open a project in any folder')
    args = parser.parse_args()
    project_map, audio_map = None, None
    if args.project_dir:
        folder = args.project_dir.resolve()
        project = json.loads((folder / "lecture_project.json").read_text(encoding="utf-8"))
        render_project(folder, project)
        args.lesson = project["lesson"]
        args.notes_root = folder.parent
        project_map = {args.lesson: folder}
        settings_path = folder / ".whisper-studio" / "project.json"
        if settings_path.is_file():
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            if settings.get("audio"):
                audio_map = {args.lesson: Path(settings["audio"])}
    if args.command == "prepare":
        if not args.lesson:
            parser.error('Specify the lesson folder to prepare')
        folder = (args.notes_root / args.lesson).resolve()
        prepare_lesson(folder)
        print(folder / "lecture_project.json")
        return
    target_route = f"/lesson/{args.lesson}/lecture.html" if args.lesson else "/"
    if args.command == "open" and not project_map and args.port:
        import urllib.request
        try:
            health = json.load(urllib.request.urlopen(f"http://127.0.0.1:{args.port}/api/health", timeout=2))
            if health.get("service") == "whisper-lecture-editor" and Path(health["notes_root"]).resolve() == args.notes_root.resolve():
                webbrowser.open(f"http://127.0.0.1:{args.port}{target_route}")
                return
        except OSError:
            pass
    server = make_server(args.notes_root, args.port, projects=project_map, audio_sources=audio_map)
    if args.command == "open":
        webbrowser.open(f"http://127.0.0.1:{server.server_port}{target_route}")
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    import logging
    (ROOT / ".logs").mkdir(exist_ok=True)
    logging.basicConfig(filename=ROOT / ".logs" / "lecture-editor.log", level=logging.INFO)
    try:
        main()
    except Exception:
        logging.exception("Lecture editor failed")
        raise
