# Whisper Studio

App desktop per **Windows, macOS e Linux** che trasforma i materiali di una lezione in **appunti HTML modificabili**. Puoi trascrivere localmente con Whisper oppure importare un testo già pronto, e scegliere **Codex CLI, Claude Code o Gemini CLI** per l'organizzazione con slide e appunti. La schermata principale permette di scegliere una cartella, selezionare i file per ruolo e aggiungere indicazioni facoltative. La CLI e la precedente interfaccia di sola trascrizione restano disponibili.

La trascrizione audio avviene sul computer con `faster-whisper` e CTranslate2, su CPU o con NVIDIA compatibile. Con una trascrizione esterna Whisper e il secondo passaggio audio vengono saltati. Il lavoro dell'assistente AI richiede una connessione e utilizza il tuo account: testo e contesto selezionati vengono elaborati dal relativo servizio. Non è necessario aggiungere una chiave API se la CLI scelta è già autenticata con un account supportato.

## Wizard e pacchetto da condividere

Leggi **[INIZIA-QUI.md](INIZIA-QUI.md)**. Avvia `Installa-Windows.bat`, `Installa-macOS.command` oppure `sh install-linux.sh`. Il wizard chiede prima il metodo di trascrizione, spiega e installa l'assistente scelto, verifica le dipendenze e propone accesso e demo. Su macOS/Linux senza permessi eseguibili usa `sh launch.sh setup`. Gli strumenti TeX per il PDF sono un passaggio facoltativo esplicito nel wizard.

`Demo-Windows.bat`, `Demo-macOS.command` e `sh demo-linux.sh` aprono la prima dimostrazione dinamica con una trascrizione inclusa: la modalità locale usa un risultato precompilato dichiarato e l'editor reale; quella AI avvia la pipeline con l'account scelto. `python build_release.py` prepara `release/Whisper-Studio-Installer.zip` con una selezione esplicita dei file del programma, senza registrazioni, lezioni personali, ambienti, modelli o credenziali. [Dettagli tecnici e fonti ufficiali](INSTALLAZIONE.md).

Nell'editor puoi usare **tasto destro → Elimina** su segnaposti, formule, figure/immagini, NDR e riferimenti. Il comando indica i riferimenti rimossi insieme all'elemento; numerazione, file salvati ed esportazione LaTeX si aggiornano. La revisione precedente e gli asset originali sono conservati. Dopo un aggiornamento riapri la lezione dall'app. [Novità della versione](CHANGELOG.md).

Nei dettagli sottostanti i riferimenti a Codex descrivono l'integrazione originale. Il wizard e i selettori in alto nell'app consentono di scegliere anche Claude Code e Gemini per lezioni ed esportazione. Il setup manuale seguente rimane il percorso storico Windows con Whisper e librerie NVIDIA.

## Setup manuale Windows

È necessario Python **3.11, 3.12 o 3.13 a 64 bit**, con Tcl/Tk incluso. Per la GPU serve un driver NVIDIA compatibile con CUDA 12. Le librerie CUDA/cuDNN vengono installate nel virtualenv. FFmpeg esterno è facoltativo: la decodifica usa PyAV, che include le librerie necessarie.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1
.\open-audio-selector.bat
```

Per scegliere un Python specifico:

```powershell
.\setup.ps1 -PythonCommand "py -3.13"
.\setup.ps1 -PythonCommand "C:\Percorso con spazi\Python\python.exe"
```

Per verificare un'installazione esistente senza modificare le dipendenze:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -CheckOnly
```

Il setup controlla gli exit code e termina con errore se installazione, dipendenze o Tkinter non funzionano. Le versioni sono fissate in `requirements.lock.txt`, a partire dall'ambiente verificato del progetto. Un virtualenv dipende dalla sua installazione Python: se cambi computer, ricrealo con il setup. I launcher trovano il progetto tramite il proprio percorso.

## Interfaccia

La schermata iniziale è ora **Lezioni**:

L'interfaccia usa una sola schermata senza scorrimento: materiali e glossario a sinistra, le schede **Elaborazione** e **LaTeX e PDF** a destra. Ogni scheda contiene il proprio comando di generazione e il pulsante **Annulla**, attivo durante il relativo lavoro. Cartella e titolo sono in alto. In basso restano **Apri lezione** e **Apri LaTeX**, visibili quando i risultati sono disponibili, e **Dettagli**. Le pagine iniziali si impostano direttamente accanto alle slide. Il menu Strumenti è in alto a destra.

La barra inferiore segue il lavoro attivo anche cambiando scheda. Per la lezione indica materiali, trascrizione, contesto, elaborazione e appunti; per LaTeX indica preparazione, conversione/PDF, verifiche, archivio e risultato. Durante ciascun passaggio audio mostra la percentuale realmente comunicata dal riconoscimento; il controllo audio mirato ha il proprio avanzamento. Nelle fasi senza una percentuale misurabile, comprese quelle affidate a Codex, la barra resta animata. A lavoro terminato conserva lo stato di ciascuna scheda e distingue i risultati parziali. **Apri LaTeX** apre il PDF dell'esportazione disponibile oppure il sorgente se il PDF manca; riconosce anche le esportazioni precedenti all'introduzione del comando nell'app.

1. Scegli la cartella del progetto e il titolo della lezione. La cartella viene usata per tutti i risultati; i file selezionati possono trovarsi anche altrove.
2. Seleziona audio/video oppure una trascrizione esistente. Puoi aggiungere slide pulite, slide annotate, lavagna e altri PDF, testi o immagini. Per le slide puoi indicare la pagina PDF iniziale. Con una trascrizione JSON o SRT si conservano i timestamp disponibili.
3. Inserisci eventuali indicazioni per l'organizzazione e un glossario tecnico facoltativo per Whisper.
4. Nella scheda **Elaborazione**, premi **Elabora lezione**. La schermata mostra le fasi e permette di annullare. Se l'audio era già stato trascritto con gli stessi parametri, viene riutilizzato.
5. Al termine viene aperto **l'HTML modificabile**. Puoi correggere testo e formule, modificare didascalie e scrivere istruzioni per le figure. Salva dall'editor prima di passare alla pubblicazione.
6. Apri **LaTeX e PDF**: compila corso, tema generale, titolo della lezione, docente, data e numero. Puoi aggiungere uno Scope già approvato, attivare l'indice e scrivere indicazioni per l'impaginazione. **Salva dati** li conserva per questo progetto; non serve selezionare di nuovo audio o trascrizione.
7. **Prepara prompt** congela gli input e prepara il prompt effettivo senza chiamare Codex. **Genera LaTeX** avvia la conversione del testo salvato, la compilazione quando possibile e la creazione dello ZIP. Il PDF viene aperto al termine; **Dettagli** apre la cartella del lavoro. Whisper non viene eseguito in questa fase.

I dati di pubblicazione sono in `.whisper-studio/latex-settings.json`, vengono ripristinati scegliendo la cartella e sono inclusi in `latex_handoff.json`. Le date accettano `GG/MM/AAAA` o `AAAA-MM-GG`; vengono salvate in formato ISO. Una data vuota rimane sconosciuta. Il titolo LaTeX vuoto usa quello del progetto approvato; gli altri metadati mancanti diventano `[To be completed]`. Lo Scope vuoto viene omesso. Le indicazioni LaTeX riguardano l'esportazione: non riscrivono il corpo della lezione.

Ogni esportazione crea `latex/export-<data-UTC>-<id>/`: conserva `prompt.md`, `export-input.json`, `metadata.tex`, il template copiato, `source-snapshot/`, gli eventi Codex e il rapporto. HTML e JSON devono contenere lo stesso corpo; se divergono, l'app si ferma prima della conversione conservandoli entrambi. Le bozze non salvate rimaste nel browser non sono acquisibili da questo comando: salva le correzioni tramite l'editor dell'applicazione. I file approvati non sono sovrascritti e le correzioni alle figure si applicano alle copie di esportazione.

Il risultato comprende `main.tex`, `main.pdf` se compilabile, `figures/`, manifest, rapporto, istruzioni per ricompilare e `lecture-latex.zip`. Per compilare occorrono pdfLaTeX e i pacchetti del template; per il controllo visivo serve un renderer PDF. `latex_assets.py` converte gli SVG in PDF vettoriali con Chrome/Edge in modalità headless e un profilo temporaneo isolato. L'app verifica i file, il collegamento ai metadati, l'opzione dell'indice, gli hash e la presenza dei controlli dichiarati da Codex; le verifiche dettagliate del testo e delle pagine sono svolte da Codex secondo il prompt e documentate nel rapporto. Un risultato privo delle verifiche richieste non è presentato come completato. La riproducibilità conserva input e procedura; una nuova chiamata generativa può produrre differenze di impaginazione.

Il template include `LectureTable` nello stile delle tabelle Highlights della lezione completata L11_27-10-2026: sfondo bianco, griglia verticale sottile, intestazioni blu petrolio, spaziatura compatta, celle unite e didascalia sotto. `LectureLongTable` ripete l'intestazione sulle pagine successive. `TablePlaceholder` conserva numero, label `tab:…`, fonte e azione manuale di una tabella ancora da inserire. Il prompt LaTeX usa questi ambienti e mantiene i riferimenti creati nell'HTML. Gli esempi compilabili e le firme dei comandi sono in `output/latex-template/ISTRUZIONI.md`.

Sotto i selettori audio e trascrizione trovi **Lingua audio** e **Modello Whisper**. La lingua iniziale è Inglese, con `distil-large-v3.5`. Per una lingua diversa o per il rilevamento automatico, l'elenco esclude i modelli solo inglesi; se il modello corrente diventa incompatibile, viene selezionato `large-v3-turbo`. Puoi poi scegliere un altro modello compatibile. I selettori restano bloccati durante un lavoro. La selezione viene conservata per il progetto e nell'ultima configurazione usata. La lingua riguarda il riconoscimento dell'audio: gli appunti organizzati restano in inglese, come previsto dal prompt. Se il transcript JSON dichiara una lingua diversa da quella scelta, viene chiesto di correggere la selezione o usare il rilevamento automatico.

Con **+ Modello** puoi salvare un repository Hugging Face (`autore/modello`, anche tramite URL) o una cartella locale. Il modello deve essere una variante Whisper compatibile con **CTranslate2**; una cartella locale deve contenere almeno `model.bin` e `config.json`. Per un modello personalizzato puoi assegnare un nome e specificare se è solo inglese. Le capacità note dei modelli standard vengono mantenute. L'aggiunta registra il modello nell'elenco `.state/asr-models.json`; un repository viene scaricato nella cache `.models/` al primo utilizzo, mentre una cartella locale viene usata direttamente. L'aggiunta da sola non scarica i pesi né verifica la qualità del modello. Riferimenti: [modelli CTranslate2 supportati da faster-whisper](https://github.com/SYSTRAN/faster-whisper#model-conversion), [scheda del modello inglese Distil-Large-v3.5](https://huggingface.co/distil-whisper/distil-large-v3.5).

La cartella scelta contiene `lecture.html`, il progetto modificabile `lecture_project.json`, il Markdown sincronizzato, le figure e i file di revisione. I dettagli tecnici (ASR, immagini PDF, prompt effettivo, manifest, risultati strutturati ed eventi Codex) sono in **`.whisper-studio/`**, accessibile con il pulsante **Dettagli**. Le selezioni e le indicazioni vengono ricordate per progetto. Non devi gestire TXT o JSON durante l'uso normale.

Il prompt base è `PROMPT_ORGANIZZAZIONE_LEZIONE.md`. A ogni lavoro l'app aggiunge i materiali realmente selezionati, le pagine iniziali, le istruzioni scritte nell'interfaccia e il contratto per generare il documento. Codex lavora in una directory dedicata con sandbox `workspace-write`, senza ereditare questa chat. La chiamata usa `codex exec`, input tramite stdin, eventi JSONL e un risultato vincolato a uno schema. L'app verifica che ogni segmento sia assegnato una volta alla lezione o esplicitamente conservato nella revisione prima di pubblicare il risultato. Riferimento: [modalità non interattiva di Codex](https://learn.chatgpt.com/docs/non-interactive-mode).

Per le nuove lezioni, lo stile predefinito segue le revisioni approvate di Tognetti: esposizione tecnica inglese autonoma, prevalentemente neutra o impersonale; ragionamento completo, esempi e ripetizioni didattiche conservati; eliminazione della regia dell'aula e delle ripartenze; domande retoriche rese espositive e veri scambi domanda-risposta preservati. Le lezioni già approvate non vengono riscritte automaticamente. Il prompt `PROMPT_HTML_TO_LATEX.md` trasferisce solo il corpo approvato e la sua struttura, incluse figure, formule e box didattici: note editoriali/di revisione, vecchi blocchi di revisione Slide context / Annotation, righe Sources e metadati ASR restano fuori dal PDF e non prevalgono sulle correzioni dell'utente. La conversione mantiene segnaposto e Prof's suggestion, cura le didascalie, dispone i pannelli correlati in modo leggibile ed evita pagine di soli float quando la figura può convivere con il testo.

Durante l'elaborazione, Codex confronta la trascrizione con le slide pertinenti alla lezione. I contenuti sostanziali presenti nei materiali ma assenti dalla trascrizione vengono aggiunti in fondo, nella sezione **Additional material from the lecture slides**, con nome del PDF e pagine per ogni argomento. Si dà priorità alle fonti del professore; gli appunti dello studente integrano solo informazioni coerenti e attribuite. L'app verifica le fonti e le pagine citate e pubblica questa sezione dopo il testo dell'audio, senza assegnarle segmenti audio inventati. Le classi `lecture-supplements` / `lecture-supplement` / `slide-citation` ne mantengono il contenuto nell'HTML modificabile e nel successivo LaTeX. Restano esclusi argomenti di altre lezioni, duplicati e interpretazioni incerte; eventuali dubbi sono riportati nella revisione. Se si dispone solo della trascrizione, la sezione dichiara l'assenza da quella fonte senza sostenere che l'audio sia stato ascoltato. Non compare una sezione vuota quando non servono integrazioni.

Se Codex non è disponibile, installalo e completa una volta `codex login`. **Strumenti → Verifica Codex** controlla la disponibilità senza avviare una lezione. Se manca l'autenticazione, un'elaborazione fallisce o viene annullata, il progetto conserva gli input e i risultati intermedi completati; lo stato non viene presentato come successo. Un'interruzione si riprende premendo nuovamente Elabora.

Se aggiorni una lezione esistente, Codex riceve la versione modificata come riferimento prioritario. Le note e le didascalie delle figure già esistenti vengono conservate; testo e SVG precedenti vengono archiviati in `revisions/editor/`. Se l'utente modifica il progetto durante l'elaborazione, il nuovo risultato resta nei dettagli e non sovrascrive il testo modificato.

La precedente interfaccia è in **Strumenti → Trascrizione avanzata**; si può avviare anche con `open-audio-selector.bat --transcription-only`. Le sue funzioni rimangono:

- **Libreria e output:** selezione multipla, doppio clic per accodare, importazione in background, drag-and-drop, menu contestuale e navigazione dei transcript.
- **Coda e cronologia:** pausa tra file, ripresa, annullamento corrente o dei selezionati, nuovo tentativo e dettagli degli errori. Doppio clic su un lavoro completato per aprire il suo output.
- **Impostazioni:** preset, lingua, CPU/GPU/auto, trascrizione o traduzione in inglese, modello personalizzato, VAD, allineamenti delle parole e contesto tecnico.

Ogni lavoro conserva le impostazioni presenti quando viene accodato. Cambiare le impostazioni non modifica lavori già in coda. I file già presenti dentro `Audio` vengono riutilizzati; quelli esterni sono copiati senza sostituire file omonimi.

La coda è salvata in `.state/queue.json`. Dopo una chiusura o un'interruzione i lavori incompleti vengono recuperati **in pausa**: usa `Riprendi coda`. Un lavoro interrotto riparte dall'inizio del file. L'annullamento è cooperativo: aspetta che termini la decodifica, il caricamento/download del modello o il batch corrente. La chiusura conserva il lavoro per il prossimo avvio.

Gli output precedenti alla revisione sono riconosciuti, ma vengono indicati come **da verificare**. Un transcript vuoto, parziale o relativo a un audio modificato non viene marcato come completato.

## Preset

| Preset | GPU da 4 GB | Batch iniziale | CPU | Uso |
| --- | --- | ---: | --- | --- |
| `speed` | `small`, int8/float16 | 8 | `small`, int8, batch 2 | Bozze rapide |
| `balanced` | `large-v3-turbo`, int8/float16 | 4 | `small`, int8, batch 2 | Trascrizione multilingue |
| `max` | `medium`, int8/float16 | 2 | `medium`, int8, batch 2 | Modello completo, elaborazione più lenta |

Con almeno 6 GB il preset `max` sceglie `large-v3` quantizzato. Il batch viene dimezzato automaticamente in caso di memoria insufficiente, fino a 1; se il modello stesso non entra in memoria viene riportato l'errore. La qualità dipende da lingua e registrazione: `max` non garantisce di superare `balanced` su ogni audio.

Per la **traduzione**, `balanced` usa `medium`: turbo non è addestrato per questa attività. I modelli Distil-Whisper inglesi sono consentiti solo con lingua `en` e attività `transcribe`. Riferimenti: [modelli e traduzione Whisper](https://github.com/openai/whisper#available-models-and-languages), [scheda Distil-Whisper](https://huggingface.co/distil-whisper/distil-large-v3).

La precisione viene scelta tra quelle effettivamente supportate dal dispositivo. La modalità `auto` usa la GPU se disponibile, altrimenti la CPU. I modelli sono memorizzati in `.models/` e possono essere riutilizzati senza connessione. La GUI conserva un solo modello e libera quello precedente prima di cambiarlo.

## CLI

```powershell
.\run-whisper.bat "Audio\lezione.m4a" --language it
.\run-whisper.bat "Audio\lezione.m4a" --preset speed
.\run-whisper.bat "Audio\lezione.m4a" --cpu --language it
.\run-whisper.bat "Audio\lezione.m4a" --task translate --language it
.\run-whisper.bat "Audio\lezione.m4a" --no-vad
.\run-whisper.bat "Audio\lezione.m4a" --word-timestamps --initial-prompt "Neuroni, plasticità sinaptica, Hodgkin-Huxley."
.\run-whisper.bat "Audio\lezione.m4a" --model medium --batch-size 1 --formats txt json
.\run-whisper.bat --help
```

`--device auto|cuda|cpu`, `--compute-type`, `--beam-size`, `--batch-size` e `--output-dir` permettono ulteriori personalizzazioni. Batch e beam devono essere positivi. `--cpu` equivale a `--device cpu`. Un percorso senza estensione è accettato solo se identifica un unico file. L'output predefinito è sempre la cartella `outputs` del progetto, anche quando il launcher viene eseguito altrove.

## Output e affidabilità

Per `Audio\Lezioni\lezione.v1.m4a`:

```text
outputs\Lezioni\lezione.v1\lezione.v1.txt
outputs\Lezioni\lezione.v1\lezione.v1.srt
outputs\Lezioni\lezione.v1\lezione.v1.json
```

File esterni alla libreria usano `outputs/external/<nome>-<identificativo-del-percorso>/`; file con lo stesso nome in cartelle diverse non si sovrascrivono. Se nella libreria ci sono media con lo stesso nome base ma estensioni diverse, le cartelle vengono distinte tramite l'estensione.

Il VAD viene eseguito su finestre di un minuto con stato indipendente, contesto ai bordi e recupero con finestre brevi per blocchi sospetti. Questo evita l'anomalia verificata sui file CNS, in cui la scansione dell'intera registrazione eliminava il parlato. Blocchi incerti vengono conservati e segnalati. `--no-vad` usa clip esplicite di massimo 30 secondi e funziona anche su registrazioni lunghe.

Una trascrizione vuota con VAD viene ritentata senza filtro. Audio senza parlato rilevato o testo ancora vuoto termina con errore, senza sostituire transcript precedenti. Gli avvisi di recupero e di bassa copertura sono visibili nella coda e nel JSON; non costituiscono una misura di accuratezza linguistica.

Gli SRT usano l'allineamento delle parole e vengono suddivisi in cue brevi, con righe di circa 42 caratteri. Il JSON contiene modello, dispositivo, precisione, lingua, attività, batch effettivo, durata, tempi di elaborazione, versione delle librerie, identificazione dell'input e avvisi. Vengono segnalate anche bassa confidenza e ampie regioni analizzate senza testo. `--word-timestamps` aggiunge gli allineamenti delle parole nel JSON; l'allineamento è comunque usato per produrre gli SRT. Ogni file viene scritto tramite un temporaneo e sostituito atomicamente; il JSON registra le impronte SHA-256 di TXT e SRT per riconoscere output modificati o salvataggi parziali.

## Secondo passaggio per le correzioni

Per i nuovi lavori il **secondo passaggio audio è attivo**: si può disattivare dalla relativa casella nelle impostazioni o con `--no-audio-review` nella CLI. Le lezioni inglesi possono usare `distil-large-v3.5` nel primo passaggio; sulla GPU il controllo usa normalmente `large-v3`. Se il primo modello è già `large-v3`, per l'inglese il controllo usa `distil-large-v3.5`. Sulla CPU viene riutilizzato il modello corrente. La GUI libera il modello precedente prima di caricare il successivo.

Il controllo cerca bassa confidenza, ripetizioni sospette e intervalli ampi senza testo. Rielabora gli estratti con contesto, finestre brevi sovrapposte, beam 5, senza VAD e senza trascinare il testo della finestra precedente. Il lavoro selezionato automaticamente è limitato al 35% della durata, contando anche le sovrapposizioni. Gli intervalli oltre questo limite restano elencati come differiti. Se non ci sono candidati, il modello di controllo non viene caricato. Questi criteri possono lasciare inosservati errori plausibili: non garantiscono una trascrizione priva di errori.

Gli output aggiuntivi `<nome>.review.json` e `<nome>.review.md` confrontano primo e secondo riconoscimento. **Le differenze sono proposte da valutare con il contesto, non correzioni automatiche né ascolto umano.** Il testo ASR originale resta conservato; le correzioni supportate vengono applicate alla stesura organizzata, registrando la decisione. Se il secondo passaggio fallisce, il primo resta salvato e viene mostrato un avviso.

Durante la preparazione degli appunti si possono segnalare altri tratti, anche per termini tecnici o possibili negazioni mancanti, in un JSON come `[{"id":"U01","start":120,"end":138,"reason":"Termine tecnico dubbio"}]`. Gli intervalli indicati esplicitamente vengono mantenuti anche oltre il limite automatico. Per riesaminarli:

```powershell
.\.venv\Scripts\python.exe audio_review.py "notes\tognetti-2026-11-03\sources\transcript.json" --model distil-large-v3.5 --issues "notes\tognetti-2026-11-03\audio_issues.json" --prompt-file "notes\tognetti-2026-11-03\audio_glossary.txt" --output "notes\tognetti-2026-11-03\audio_review.json"
```

Questo comando rigenera il confronto: conserva prima una copia del report se contiene già decisioni editoriali. `--plan-only` mostra gli intervalli senza eseguire il modello. Il glossario aiuta il riconoscimento, ma non autorizza a inserire parole assenti dal discorso.

## Appunti HTML modificabili e passaggio a LaTeX

### Inserimenti con il tasto destro

Con **Modifica testo** attivo, posiziona il cursore nel paragrafo e usa il
selettore **Stile** nella barra: Testo normale, Titolo lezione, Titolo,
Sottotitolo o Sottotitolo di secondo livello. Puoi anche selezionare più
paragrafi. Il cambio conserva testo, formule inline, riferimenti e ID;
l’indice viene aggiornato quando aggiungi o togli un titolo.

Apri la lezione dall'applicazione per usare l'editor e il server aggiornati.
Il menu del tasto destro nel testo funziona anche prima di premere **Modifica testo**:

- **Segnaposto figura / equazione / tabella / altro**: scegli una label univoca,
  una descrizione e, se note, la fonte, la pagina e l'azione manuale. I prefissi
  `fig:`, `eq:`, `tab:` e `item:` vengono aggiunti quando scrivi solo il nome.
- **Inserisci riferimento**: seleziona una figura generata, un'immagine caricata,
  una formula inline/display o un segnaposto. Il collegamento usa l'ID stabile
  e aggiorna il numero visibile secondo l’ordine degli elementi; i pannelli
  della figura e della formula consentono di cambiare label.
- **Inserisci immagine**: scegli PNG, JPEG o WebP (massimo 10 MB), label e titolo.
  Puoi scrivere la didascalia oppure chiederne la generazione durante HTML → LaTeX,
  aggiungendo indicazioni facoltative. L'immagine viene copiata nel progetto;
  spostare o cancellare il file di partenza non rompe il documento.
- **Inserisci formula inline / display**: scrivi il sorgente LaTeX, controlla
  l’anteprima e scegli una label `eq:…`. **Modifica formula** (✎ per le inline)
  riapre il pannello e permette di cambiare sorgente, label e formato.
  Anche le formule display precedenti diventano disponibili nei riferimenti.
- **Inserisci NDR inline / a blocco**: aggiungi una nota del redattore nel punto scelto. La nota
  è modificabile in HTML, viene salvata come nota editoriale e resta esclusa dal
  PDF secondo il prompt di esportazione.

Per spostare una figura già presente, scegli **Sposta questa figura** dal suo
menu, oppure premi **Sposta** sotto l'immagine. Poi fai tasto destro nel punto
desiderato e scegli **Sposta qui l'elemento selezionato**. L'immagine conserva
identità, didascalia, note e riferimenti. Puoi spostare anche i nuovi segnaposto.
Gli inserimenti a blocco a metà paragrafo lo dividono senza eliminare parole;
formule e NDR inline restano nella frase.

Il salvataggio conserva label, collegamenti, ordine HTML e scelte di didascalia
nel JSON e in `latex_handoff.json`. Gli asset importati sono in `assets/imported/`.
Il passaggio LaTeX congela anche le immagini e la mappa degli elementi. Nella
modalità `file://`, le nuove immagini restano incorporate nel progetto JSON
esportato; importandolo nell'editor dell'app vengono salvate come file nel progetto.
Le note NDR non autorizzano riscritture del testo approvato. Solo la scelta
esplicita di una didascalia da generare autorizza la generazione di quel testo.

Apri **`open-lecture-editor.bat`** e scegli la lezione, oppure avvia direttamente Tognetti:

```powershell
.\open-lecture-editor.bat tognetti-2026-11-03
```

Il launcher avvia un servizio sul solo computer locale (`http://127.0.0.1:8765`) e apre l'editor. Non invia contenuti a un servizio esterno. Nell'HTML:

- **Modifica testo** abilita la scrittura direttamente nei paragrafi. Il salvataggio sul PC è automatico dopo una breve pausa; **Salva progetto** o `Ctrl+S` lo esegue subito. Verifica lo stato “Salvato sul PC”.
- **Modifica formula** conserva il sorgente LaTeX e mostra un'anteprima della formula.
- **Note e didascalia** su ogni figura permette di cambiare la didascalia e aggiungere istruzioni con stato “Da applicare in LaTeX” o “Già applicata”. Gli identificativi `fig01`, `fig02`, ecc. collegano le istruzioni alla figura corretta.
- **Confronto audio** mostra le due letture ASR, le decisioni registrate e un lettore per gli estratti originali.
- **Esporta progetto / Importa progetto** permette di conservare o riprendere una copia JSON della stessa lezione.

Il file `lecture.html` aperto direttamente con `file://` consente comunque modifiche, bozze nel browser ed esportazione del progetto. Per scrivere automaticamente nei file del progetto usa l'indirizzo locale aperto dal launcher. Una bozza nel browser non equivale al salvataggio sul PC: in modalità file conserva il JSON esportato e reimportalo nell'editor locale.

La versione autorevole è **`notes/<lezione>/lecture_project.json`**. Ogni salvataggio aggiorna anche `lecture_notes.md`, `lecture.html`, `figure_notes.md` e **`latex_handoff.json`**. Il passaggio finale a LaTeX deve usare questa versione modificata e applicare le istruzioni ancora pendenti, senza ripartire dal vecchio transcript ASR. Il progetto contiene il testo HTML e il Markdown, il sorgente delle formule, le didascalie, gli identificativi e le note delle figure. I disegni SVG restano in `assets/`.

Le revisioni precedenti sono in `revisions/editor/`; un conflitto tra due finestre blocca la sovrascrittura e conserva la bozza da esportare. Se `lecture_notes.md` viene modificato fuori dall'editor, il salvataggio si ferma per permettere la riconciliazione senza cancellare quelle modifiche. Per aggiungere una nuova lezione già organizzata nel formato HTML del progetto:

```powershell
.\.venv\Scripts\python.exe review_editor.py prepare nome-lezione
```

La preparazione conserva l'HTML iniziale in `.editor-template.html`. Dopo la preparazione, aggiorna il progetto tramite l'editor: evita di ricreare l'HTML partendo dal vecchio ASR. Le istruzioni complete per l'organizzazione sono in `PROMPT_ORGANIZZAZIONE_LEZIONE.md`. L'editor include una copia locale di KaTeX 0.19.1 con licenza MIT, per le formule anche senza connessione.

## Diagnostica e sviluppo

Gli errori dell'app sono registrati in `.logs/whisper-studio.log` con rotazione. Gli errori prima dell'apertura della finestra vengono salvati anche in `open-audio-selector-error.log`.

```powershell
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
```

I test verificano regressioni di VAD, CPU, audio lungo senza filtro, recupero dopo memoria insufficiente, annullamento, salvataggi, nomi dei file, sottotitoli, concorrenza e persistenza della coda. Non scaricano modelli e non modificano gli audio o i transcript della libreria.

Struttura: `lecture_ui.py` contiene la schermata principale; `lecture_pipeline.py` gestisce materiali, ASR e Codex; `lecture_document.py` verifica e pubblica il documento; `review_editor.py` serve l'editor locale. `transcribe.py` contiene il motore ASR e la CLI; `job_queue.py` gestisce la coda avanzata; `audio_selector.pyw` avvia l'app e conserva l'interfaccia precedente. Tutte le operazioni Tkinter avvengono sul thread principale. Le copie precedenti alla nuova schermata sono in `.backups/before-lecture-app-20261104/`.
