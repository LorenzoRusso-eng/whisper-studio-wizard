# Whisper Studio

Turn lecture recordings, transcripts, slides, and notes into **editable HTML
lecture notes**, then export the approved lesson to LaTeX and PDF. The desktop
app and installation wizard use English throughout and support Windows, macOS,
and Linux.

Choose **Codex CLI, Claude Code, or Gemini CLI** for organization, diagrams,
contextual corrections, and LaTeX conversion. Whisper handles local speech
recognition; you can instead import a transcript created elsewhere and skip
both audio passes.

## Install and run

Extract the entire installer ZIP into a writable local folder, then run:

| Operating system | Install | Start | Demo |
| --- | --- | --- | --- |
| Windows | `Install-Windows.bat` | `Start-Windows.bat` | `Demo-Windows.bat` |
| macOS | `Install-macOS.command` | `Start-macOS.command` | `Demo-macOS.command` |
| Linux | `sh install-linux.sh` | `sh start-linux.sh` | `sh demo-linux.sh` |

On macOS, `sh launch.sh setup` also works when executable permissions are
missing. The wizard first asks whether to use local Whisper or an existing
transcript. It then explains the assistants, installs missing components,
checks dependencies, and offers sign-in and a guided demo.

Read [QUICKSTART.md](QUICKSTART.md) for prerequisites and the first session, or
[INSTALLATION.md](INSTALLATION.md) for dependency profiles and CLI details.
Python **3.11–3.13, 64-bit**, with Tcl/Tk, pip, and venv is required. CPU mode
works on all supported systems. NVIDIA CUDA is optional on Windows/Linux x64;
faster-whisper uses the CPU on Mac, including Apple Silicon.

To reopen setup, choose **Tools → Installation and AI assistant**. Each person
sets up their own environment and account. Share the installer ZIP instead of
copying an installed `.venv`, `.tools`, or the full working folder.

## Accounts and processing

Whisper transcribes audio on your computer. Its model weights download on
first use and are cached in `.models/`. The selected AI assistant processes
your chosen text and context online using its own account, access rules, and
quota. An existing supported CLI sign-in can be reused; the app does not
request or copy passwords or API keys.

Codex and Claude provide an account-status check. For Gemini, the availability
check confirms that the CLI starts; its account and quota are confirmed by the
first live job. Authentication happens in the provider's interactive terminal.
CLI permissions differ between providers; a denied tool or incomplete result
is reported instead of being presented as a successful job.

## Prepare a lesson

1. Choose a project folder and lesson title. Results are saved there; source
   files may be elsewhere.
2. Choose `whisper` or `external` and the AI assistant in the project bar.
   Select audio/video or an existing TXT, Markdown, SRT, or JSON transcript.
   In external mode, a transcript is required and both audio passes are skipped,
   even if an old audio selection remains in the form.
3. Add clean slides, annotated slides, whiteboard PDFs, or additional PDFs,
   text, and images. Set the first PDF page where appropriate. Optional
   absent materials do not block processing.
4. Set the source audio language and Whisper model when transcribing. Add an
   optional technical glossary and organization instructions.
5. Click **Process lesson**. The app shows preparation, transcription, context,
   AI organization, and publication. **Cancel** preserves completed work.
6. Open the editable HTML, make corrections, and save in the editor before
   moving to LaTeX export.

The source-language choice controls recognition. Organized lesson notes and
review reports are written in English, including when the source is in
another language. An imported JSON transcript with a conflicting declared
language requires a matching selection or automatic detection.

The default editorial model produces complete technical exposition, usually
neutral or impersonal. It preserves reasoning, examples, meaningful teaching
repetitions, qualifications, and genuine questions and answers. It removes
nonsemantic classroom staging and restarts without turning the lesson into
a summary. The prompt is [PROMPT_LECTURE_ORGANIZATION.md](PROMPT_LECTURE_ORGANIZATION.md).

Relevant substantive slide content absent from the transcript is appended in
**Additional material from the lecture slides**, with the actual PDF filename
and page references. Professor-provided material takes priority; consistent
student notes are attributed. Material outside the lesson's scope, unsupported
interpretations, and duplicates are excluded. Uncertain conflicts remain in
the review. An omission from a transcript does not establish that something
was absent from the audio.

## Edit the HTML

The project contains `lecture.html`, `lecture_project.json`, synchronized
Markdown, figure assets, and review files. Use the local editor opened by the
app to save directly to disk. In file mode, export the JSON project to keep
changes and import it later in the local editor. Unsaved browser edits are
not automatically available to the LaTeX pipeline.

Use the toolbar to edit prose, choose heading levels, save, and import/export
projects. Figure controls manage captions, labels, and revision instructions.
The figure-comparison view displays reconstructions beside available source
pages; a selectable page is not automatically a verified match.

Right-click at the intended insertion point to add:

- Inline or display LaTeX formulas, with a preview and stable equation label.
- Figure, equation, table, or generic placeholders, with description, source,
  and manual action.
- References linked to stable element IDs rather than displayed numbers.
- PNG, JPEG, or WebP images, stored as content-addressed assets.
- Inline or block editorial notes, visible in review and excluded from print.

Right-click an existing element and choose **Delete** to remove a placeholder,
formula, generated figure, imported image, editorial note, or reference. When
deleting a target, the menu shows how many linked references will also be
removed. Deleting a single reference leaves its target intact. Numbering,
HTML, Markdown, metadata, and LaTeX handoff update together. Previous revisions
and original asset bytes are preserved. Reopen the lesson from the app after
updating to load the current editor and server.

Move figures and placeholders through their context menu: select **Move**,
right-click the destination, and choose **Move the selected element here**.
HTML order is authoritative. Labels and references survive moves and label
changes. Typing or pasting across protected structured elements is blocked;
use their dedicated controls instead.

For imported images, write the caption now or choose to generate it during
HTML → LaTeX. Generation authorizes the caption alone. Existing written
captions and approved prose are preserved. Uncertain figure instructions stay
unresolved when their supporting sources are unavailable.

## Export LaTeX and PDF

Open **LaTeX and PDF** after saving the approved lesson. Set course, general
topic, lesson title, date, lecturer, and lesson number. The date accepts
`DD/MM/YYYY` or `YYYY-MM-DD` and is stored as ISO. Missing values are not inferred
from filenames or the current date. Unknown metadata remain `[To be completed]`;
blank Scope is omitted. The table of contents is included only when selected.

**Save metadata** stores per-project settings without changing the body.
**Prepare prompt** freezes inputs and the effective prompt without calling
the assistant. **Generate LaTeX** converts the approved snapshot, compiles when
possible, verifies the result, and creates a ZIP. Whisper is not rerun.

Each export uses `latex/export-<UTC timestamp>-<id>/` and preserves its prompt,
contract, metadata, template, `source-snapshot/`, CLI events, report, sources,
and assets. The expected outputs include `main.tex`, `figures/`, manifests,
`README-compilation.md`, and `lecture-latex.zip`, plus `main.pdf` when available.
HTML and JSON must agree before conversion; an inconsistency stops export
without overwriting either version. Changes to original inputs during a job
also stop publication of a completed result.

The selected assistant handles both organization and export. The template
uses pdfLaTeX and its documented packages; SVG-to-vector-PDF conversion uses
Chrome, Chromium, or Edge with an isolated headless profile. The wizard offers
checks and TeX installation commands. Without the required tools, sources and
an explicitly partial result can still be produced. A result is completed
only with the PDF and all required verification flags.

The conversion prompt is [PROMPT_HTML_TO_LATEX.md](PROMPT_HTML_TO_LATEX.md).
The template's [README](output/latex-template/README.md) documents metadata,
teaching boxes, table environments, and placeholder commands. The printed PDF
contains approved lesson content, including its final slide supplements;
editorial notes, legacy review blocks, technical source lines, and ASR process
metadata remain outside the lesson body.

## Whisper and the second audio pass

The main interface defaults to English and `distil-large-v3.5`. For another
language or automatic detection, incompatible English-only models are removed
from the list and the default becomes `large-v3-turbo`. Select a compatible
model for your recording and available memory.

**+ Model** registers a CTranslate2-compatible Hugging Face repository
(`owner/model`) or local directory containing `model.bin` and `config.json`.
Registration alone does not download weights or assess model quality. Custom
models are stored in `.state/asr-models.json`; repository weights download on
first use. Known built-in model capabilities are preserved.

The second pass is enabled by default for new audio jobs. It finds low
confidence, possible repetitions, and suspicious text-free intervals, then
reprocesses selected excerpts with context, short overlapping windows, beam 5,
and no VAD. Automatic review is limited to 35% of the recording, counting
overlap. Deferred intervals and unresolved differences remain visible.

On GPU, English `distil-large-v3.5` is normally checked with `large-v3`; when
the first model is `large-v3`, an English Distil model can provide the second
hypothesis. CPU review normally reuses the current model. The previous model
is unloaded before switching. A second ASR result is a hypothesis, not human
listening or proof of the words spoken. Contextual corrections must preserve
uncertain numbers, negations, and scientific meaning when evidence conflicts.

Imported external transcripts skip both recognition and audio review. The
application does not connect to external transcription services on your behalf.

## Advanced transcription and queue

Choose **Tools → Advanced transcription** for the original transcription
interface. It supports library import, multiple selection, drag-and-drop,
queued jobs, pause/resume, cancellation, retry, history, and transcript browsing.
Settings are captured when a job is queued; later changes affect new jobs.
Files already inside `Audio/` are reused. External files are copied without
overwriting names already in the library.

Queue state is stored in `.state/queue.json`. After interruption, incomplete
jobs are recovered paused; click **Resume queue**. An interrupted audio job
restarts from the beginning of that file. Cancellation is cooperative and
may wait for decoding, model loading/download, or the current batch to finish.
Closing preserves queued work for the next session.

| Preset | Typical 4 GB GPU model | Initial batch | CPU | Purpose |
| --- | --- | ---: | --- | --- |
| `speed` | `small` | 8 | `small`, int8, batch 2 | Fast drafts |
| `balanced` | `large-v3-turbo` | 4 | `small`, int8, batch 2 | Multilingual transcription |
| `max` | `medium` | 2 | `medium`, int8, batch 2 | Full model, slower processing |

With at least 6 GB, `max` selects a quantized `large-v3`. Batch size is reduced
on out-of-memory errors down to 1; a model that cannot fit still reports an
error. Higher presets do not guarantee better accuracy for every recording.
Translation uses a compatible multilingual model such as `medium` rather
than turbo. English-only Distil models require English transcription.

## Command line

After installation, use the virtualenv's Python to run `transcribe.py`:

```text
python transcribe.py Audio/lesson.m4a --language en
python transcribe.py Audio/lesson.m4a --preset speed --cpu
python transcribe.py Audio/lesson.m4a --task translate --language it
python transcribe.py Audio/lesson.m4a --no-vad
python transcribe.py Audio/lesson.m4a --word-timestamps --initial-prompt "Technical terms"
python transcribe.py Audio/lesson.m4a --model medium --batch-size 1 --formats txt json
python transcribe.py Audio/lesson.m4a --no-audio-review
python transcribe.py --help
```

On Windows, `run-whisper.bat` selects the virtualenv automatically. Otherwise
use `.venv/bin/python` on Unix or `.venv/Scripts/python.exe` on Windows.
Options include `--device auto|cuda|cpu`, precision, beam/batch size, output
folder, language, and formats. Beam and batch sizes must be positive. An
extension may be omitted only when one file matches. Outputs default to the
project's `outputs/` regardless of the terminal's current directory.

For `Audio/Lectures/lesson.v1.m4a`, outputs are stored under
`outputs/Lectures/lesson.v1/` as TXT, SRT, and JSON. External media use a
path-derived identifier to prevent collisions. Files with the same stem and
different extensions are distinguished. SRT cues use word alignment and short
readable lines. JSON records language, model, device, precision, duration,
processing time, effective batch size, versions, input identity, and warnings.

The VAD scans independent one-minute windows with boundary context and retries
suspect intervals. `--no-vad` uses explicit clips of at most 30 seconds. An
empty filtered result is retried without VAD. Empty, partial, modified, or
silent input does not replace a valid transcript or count as completed work.
Atomic writes and JSON hashes identify changed or partial TXT/SRT outputs.
Warnings about confidence and coverage are review signals, not accuracy scores.

## Storage, diagnostics, and development

Technical inputs, PDF page images, manifests, prompts, drafts, and CLI logs
are stored in each lesson's `.whisper-studio/`, accessible through **Details**.
Publication settings are in `.whisper-studio/latex-settings.json`. Previous
editor revisions are archived in `revisions/editor/`. Concurrent edits are
detected rather than overwritten. A failed or canceled job preserves completed
intermediate work, including reusable transcription output.

Installation logs are in `.logs/install.log`; application logs are in
`.logs/`. Use the wizard to check the selected CLI and dependencies.
The legacy Windows `setup.ps1 -CheckOnly` command verifies the original
full Whisper environment without changing its dependencies.

Run Python regressions with the virtualenv:

```text
python -m unittest discover -s tests
```

GUI tests need a graphical desktop; editor HTTP tests need localhost access.
Browser checks use isolated sample lessons. Native testing has been performed
on Windows. Mac Intel, Apple Silicon, and Linux x64 launchers and binary
dependency resolution have been checked, but native runs remain unverified.
Codex has a live-demo check; Claude/Gemini require their own account-based
end-to-end verification.

Run `python build_release.py` to create
`release/Whisper-Studio-Installer.zip` and its SHA-256 checksum. The release uses
an explicit file allowlist and excludes personal lessons, recordings, output,
environments, downloaded models, settings, credentials, and temporary tests.

See [CHANGELOG.md](CHANGELOG.md) for version history.
