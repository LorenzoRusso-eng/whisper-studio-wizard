@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "VENV_PYTHON=%SCRIPT_DIR%.venv\Scripts\python.exe"

if not exist "%VENV_PYTHON%" (
  echo Virtual environment not found.
  echo Run setup first: powershell -ExecutionPolicy Bypass -File "%SCRIPT_DIR%setup.ps1"
  exit /b 1
)

"%VENV_PYTHON%" "%SCRIPT_DIR%transcribe.py" %*
exit /b %errorlevel%
