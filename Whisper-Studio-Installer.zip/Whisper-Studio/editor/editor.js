(() => {
  'use strict';
  const bootstrap = JSON.parse(document.getElementById('lecture-editor-data').textContent);
  let project = structuredClone(bootstrap.project);
  const figureSvgs = bootstrap.figure_svgs || {};
  const report = bootstrap.review;
  const editorSource = document.currentScript?.src;
  let insertions = null;
  const article = document.getElementById('lecture-document');
  const connected = /^https?:$/.test(location.protocol) && /^(127\.0\.0\.1|localhost)$/.test(location.hostname);
  const storageKey = 'whisper-lecture-draft:' + project.project_id;
  let editing = false, dirty = false, editVersion = 0, saveTimer, inFlight = null, conflict = false;
  let activeFigure = null, audioEnd = null, textRange = null;
  const allowedTags = new Set('p div span h1 h2 h3 h4 strong b em i u s sub sup br hr blockquote ul ol li a code pre table thead tbody tr th td figure'.split(' '));
  const uid = () => crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2);
  const element = (tag, attrs = {}, text) => {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const toolbar = element('div', {id:'lecture-toolbar', role:'toolbar', 'aria-label':'Lesson review'});
  const modeButton = element('button', {id:'editor-toggle',type:'button'}, 'Edit text');
  const formatLabel = element('label', {for:'editor-block-format'}, 'Style');
  const formatSelect = element('select', {id:'editor-block-format','aria-label':'Text style',disabled:''});
  for(const [value,label] of [['p','Normal text'],['h1','Lesson title'],['h2','Title'],['h3','Subheading'],['h4','Second-level subheading']]) {
    formatSelect.append(element('option',{value},label));
  }
  const saveButton = element('button', {id:'editor-save',type:'button',class:'primary'}, 'Save project');
  const exportButton = element('button', {id:'editor-export',type:'button'}, 'Export project');
  const importButton = element('button', {id:'editor-import',type:'button'}, 'Import project');
  const audioButton = element('button', {id:'editor-audio',type:'button'}, 'Audio comparison' + (report ? ` (${report.cases.length})` : ''));
  const status = element('span', {id:'lecture-save-state',role:'status','aria-live':'polite'});
  toolbar.append(modeButton,formatLabel,formatSelect,saveButton,exportButton,importButton,audioButton,status);
  document.querySelector('nav').after(toolbar);
  const drawer = element('aside', {class:'editor-drawer',id:'lecture-drawer','aria-label':'Review notes',hidden:''});
  document.body.append(drawer);
  const importInput = element('input',{type:'file',accept:'.json,application/json',class:'editor-hidden'});
  document.body.append(importInput);

  function setStatus(message, error=false) {
    status.textContent=message;
    status.classList.toggle('error',error);
  }
  function sanitize(source) {
    const parsed = new DOMParser().parseFromString('<body>'+source+'</body>','text/html');
    function copy(node) {
      if (node.nodeType===Node.TEXT_NODE) return document.createTextNode(node.data);
      if (node.nodeType!==Node.ELEMENT_NODE || ['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH'].includes(node.tagName)) return document.createDocumentFragment();
      const target=allowedTags.has(node.localName)?document.createElement(node.localName):document.createDocumentFragment();
      if(target.nodeType===Node.ELEMENT_NODE) for(const attr of node.attributes) {
        if(['id','class','data-block-id','data-latex','data-math-display','data-figure-id','colspan','rowspan','data-placeholder-kind','data-label','data-description','data-source','data-action','data-reference-target','data-reference-kind'].includes(attr.name)) target.setAttribute(attr.name,attr.value);
        if(attr.name==='href' && !/^\s*(javascript|data|vbscript):/i.test(attr.value)) target.setAttribute('href',attr.value);
      }
      for(const child of node.childNodes) target.append(copy(child));
      return target;
    }
    const container=document.createElement('div');
    for(const node of parsed.body.childNodes) container.append(copy(node));
    return container.innerHTML;
  }
  function stampBlocks() {
    const used = new Set([...article.querySelectorAll('[data-block-id]')].map(n=>n.dataset.blockId));
    let count=1;
    for(const node of article.querySelectorAll('h1,h2,h3,h4,p,li,blockquote')) {
      if(node.closest('figure,.equation') || node.dataset.blockId) continue;
      while(used.has('b'+String(count).padStart(5,'0'))) count++;
      node.dataset.blockId='b'+String(count++).padStart(5,'0');
      used.add(node.dataset.blockId);
    }
  }
  function headingText(node) {
    const clone=node.cloneNode(true);clone.querySelectorAll('[data-editor-ui],.ndr').forEach(n=>n.remove());
    clone.querySelectorAll('[data-latex]').forEach(n=>{n.textContent=n.dataset.latex;});return clone.textContent.trim();
  }
  function toc() {
    document.getElementById('lecture-editor-toc')?.remove();
    const details=element('details',{id:'lecture-editor-toc',class:'editor-toc'});
    details.append(element('summary',{},'Lesson contents'));
    const list=element('ol');
    for(const [index,h] of [...article.querySelectorAll('h2')].entries()) {
      if(!h.id) h.id='section-user-'+index+'-'+uid().slice(0,6);
      const li=element('li');li.append(element('a',{href:'#'+h.id},headingText(h)));list.append(li);
    }
    details.append(list);article.before(details);
  }
  function hydrate() {
    textRange=null;
    article.innerHTML=sanitize(project.document.html);
    for(const slot of article.querySelectorAll('figure[data-figure-id]')) {
      const f=project.figures.find(f=>f.id===slot.dataset.figureId);
      if(!f) continue;
      slot.replaceChildren();
      slot.className='diagram';slot.id=f.id;slot.contentEditable='false';
      const head=element('div',{class:'figure-head'});
      head.append(element('span',{class:'figure-number'},f.id+' · '+f.source),element('h3',{},f.title));
      const picture=element('div',{class:'figure-svg'});
      if(f.kind==='image') {
        const src=/^data:image\/(png|jpeg|webp);base64,/.test(f.embedded_data||'')?f.embedded_data:
          /^assets\/imported\/[a-f0-9]{64}\.(png|jpg|webp)$/.test(f.asset)?new URL(f.asset,location.href).href:null;
        if(src)picture.append(element('img',{src,alt:f.title||'Imported figure',class:'imported-figure',draggable:'false'}));
        else picture.append(element('p',{},'Image unavailable.'));
      } else picture.innerHTML=figureSvgs[f.id] || '<p>Diagram unavailable.</p>';
      const caption=element('figcaption',{},f.caption_mode==='generate'?'Caption to be generated during LaTeX export.':f.caption);
      const controls=element('div',{class:'figure-editor-actions','data-editor-ui':''});
      const button=element('button',{type:'button',class:'editor-button','data-figure-note':f.id},'Notes and caption');
      const count=element('span',{class:'figure-note-count'},figureCount(f));
      controls.append(button,count);slot.append(head,picture,caption,controls);
      controls.append(element('a',{href:'figure-comparison.html#'+encodeURIComponent(f.id)},'Compare with sources'));
      button.addEventListener('click',()=>openFigure(f.id));
    }
    const usedIds=new Set([...article.querySelectorAll('[id]')].map(n=>n.id).concat(project.figures.map(f=>f.id)));
    const usedLabels=new Set([...article.querySelectorAll('[data-label]')].map(n=>n.dataset.label).concat(project.figures.map(f=>f.label||'fig:'+f.id)));
    for(const eq of article.querySelectorAll('[data-latex]')) {
      if(eq.closest('figure'))continue;
      const inline=eq.dataset.mathDisplay==='inline'||(!eq.dataset.mathDisplay&&eq.tagName==='SPAN');
      eq.classList.toggle('equation',!inline);eq.classList.toggle('equation-inline',inline);
      eq.dataset.mathDisplay=inline?'inline':'display';
      if(!eq.id){do{eq.id='equation-'+uid();}while(usedIds.has(eq.id));usedIds.add(eq.id);}
      if(!eq.dataset.label){let label='eq:'+eq.id.slice(0,80);while(usedLabels.has(label))label='eq:'+uid();eq.dataset.label=label;usedLabels.add(label);}
      eq.contentEditable='false';renderEquation(eq);
      const edit=element('button',{type:'button',class:'equation-editor-label','data-editor-ui':'','aria-label':'Edit formula',title:'Edit LaTeX formula'},inline?'✎':'Edit formula');
      eq.append(edit);edit.addEventListener('click',()=>openEquation(eq));
    }
    article.contentEditable=String(editing);stampBlocks();toc();insertions?.refresh();updateFormat();
  }
  function renderEquation(node) {
    node.replaceChildren();
    try {
      if(!window.katex) throw new Error('Formula rendering is unavailable');
      katex.render(node.dataset.latex,node,{displayMode:node.dataset.mathDisplay!=='inline',throwOnError:false,trust:false,maxExpand:1000,maxSize:20});
    } catch(error) {node.textContent=node.dataset.latex;}
  }
  function figureCount(f) {
    const pending=f.notes.filter(n=>n.status==='pending').length;
    return f.notes.length ? `${pending} notes pending · ${f.notes.length} total` : 'No notes';
  }
  function canonicalHtml() {
    const clone=article.cloneNode(true);
    clone.querySelectorAll('[data-editor-ui],.toc').forEach(n=>n.remove());
    clone.querySelectorAll('figure[data-figure-id]').forEach(n=>{const id=n.dataset.figureId;n.replaceChildren();n.removeAttribute('id');n.removeAttribute('class');n.dataset.figureId=id;});
    clone.querySelectorAll('.lecture-placeholder').forEach(n=>n.replaceChildren());
    clone.querySelectorAll('[data-latex]').forEach(n=>{n.textContent=n.dataset.latex;});
    clone.querySelectorAll('*').forEach(n=>{for(const a of [...n.attributes]) if(['contenteditable','spellcheck','tabindex','role','aria-label','aria-describedby'].includes(a.name)) n.removeAttribute(a.name);});
    return sanitize(clone.innerHTML);
  }
  function markdownFromHtml(source) {
    const container=document.createElement('div');container.innerHTML=source;
    const escape=s=>s.replace(/\\/g,'\\\\').replace(/([`*_\[\]<>])/g,'\\$1').replace(/\u00a0/g,' ');
    const children=n=>[...n.childNodes].map(convert).join('');
    function convert(n) {
      if(n.nodeType===Node.TEXT_NODE) return escape(n.textContent);
      if(n.nodeType!==Node.ELEMENT_NODE) return '';
      if(n.classList.contains('lecture-placeholder'))return '\n\n<!-- PLACEHOLDER '+JSON.stringify({id:n.id,kind:n.dataset.placeholderKind,label:n.dataset.label,description:n.dataset.description,source:n.dataset.source,action:n.dataset.action}).replace(/--/g,'\\u002d\\u002d')+' -->\n\n';
      if(n.matches('figure[data-figure-id]')) {
        const f=project.figures.find(f=>f.id===n.dataset.figureId);
        return `\n\n<!-- FIGURE:${f.id} -->\n\n![${f.title}](${f.asset})\n\n*${f.caption}*\n\n`;
      }
      if(n.hasAttribute('data-latex')) return n.dataset.mathDisplay==='inline'||(!n.dataset.mathDisplay&&n.tagName==='SPAN')?'\\('+n.dataset.latex+'\\)':'\n\n\\[\n'+n.dataset.latex+'\n\\]\n\n';
      const inner=()=>children(n);
      switch(n.tagName) {
        case 'H1':case 'H2':case 'H3':case 'H4':return '\n\n'+'#'.repeat(Number(n.tagName[1]))+' '+inner().trim()+'\n\n';
        case 'P':return inner().trim()+'\n\n';
        case 'DIV':return inner()+'\n';
        case 'BR':return '  \n';
        case 'HR':return '\n\n---\n\n';
        case 'STRONG':case 'B':return '**'+inner()+'**';
        case 'EM':case 'I':return '*'+inner()+'*';
        case 'S':return '~~'+inner()+'~~';
        case 'SUB':return '<sub>'+inner()+'</sub>';
        case 'SUP':return '<sup>'+inner()+'</sup>';
        case 'PRE':return '\n\n```\n'+n.textContent+'\n```\n\n';
        case 'CODE':return '`'+n.textContent.replace(/`/g,'\\`')+'`';
        case 'BLOCKQUOTE':return inner().trim().split('\n').map(l=>'> '+l).join('\n')+'\n\n';
        case 'UL':case 'OL':return '\n'+[...n.children].map((li,i)=>(n.tagName==='OL'?`${i+1}. `:'- ')+children(li).trim().replace(/\n/g,'\n  ')).join('\n')+'\n\n';
        case 'A':return n.classList.contains('unclear')?n.textContent:'['+inner()+']('+n.getAttribute('href')+')';
        case 'TABLE': {
          const rows=[...n.querySelectorAll('tr')].map(tr=>[...tr.children].map(c=>children(c).trim().replace(/\|/g,'\\|').replace(/\n/g,' ')));
          if(!rows.length)return '';
          const lines=rows.map(r=>'| '+r.join(' | ')+' |');lines.splice(1,0,'| '+rows[0].map(()=>'---').join(' | ')+' |');return '\n\n'+lines.join('\n')+'\n\n';
        }
        default:return inner();
      }
    }
    return children(container).replace(/\n{3,}/g,'\n\n').trim()+'\n';
  }
  function capture() {
    stampBlocks();
    const result=structuredClone(project);
    result.document.html=canonicalHtml();result.document.markdown=markdownFromHtml(result.document.html);
    const title=article.querySelector('h1');result.title=(title&&headingText(title))||result.title;
    return result;
  }
  function storeDraft() {
    try {localStorage.setItem(storageKey,JSON.stringify({project:capture(),baseRevision:project.revision,changedAt:new Date().toISOString()}));}
    catch(error){setStatus('The draft could not be saved in the browser. Use Save or Export.',true);}
  }
  function changed() {
    dirty=true;editVersion++;storeDraft();clearTimeout(saveTimer);
    setStatus(connected?'Changes waiting to be saved…':'Local draft · use Export project');
    if(connected && !conflict)saveTimer=setTimeout(()=>save(),1800);
  }
  async function save() {
    clearTimeout(saveTimer);
    if(inFlight)return inFlight;
    if(!connected) {download(capture(),'lecture_project.json');setStatus('Project exported. Keep the JSON file containing your changes.');return false;}
    if(conflict){setStatus('Conflict: export your draft before reloading.',true);return false;}
    const snapshot=capture(),version=editVersion;
    setStatus('Saving to your computer…');saveButton.disabled=true;
    inFlight=(async()=>{
      try {
        const response=await fetch(`/api/project/${encodeURIComponent(project.lesson)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expected_revision:project.revision,project:snapshot})});
        const result=await response.json();
        if(!response.ok){if(response.status===409)conflict=true;throw new Error(result.error || 'Save failed');}
        project.revision=result.project.revision;project.updated_at=result.project.updated_at;
        for(const saved of result.project.figures){
          const local=project.figures.find(f=>f.id===saved.id);
          if(local && saved.kind==='image'){local.asset=saved.asset;local.kind='image';delete local.embedded_data;}
        }
        if(editVersion===version){dirty=false;localStorage.removeItem(storageKey);}else{storeDraft();saveTimer=setTimeout(()=>save(),1000);}
        setStatus(dirty?'More changes waiting…':`Saved to your computer · revision ${project.revision}`);
        return true;
      } catch(error){setStatus(error.message+' · your draft remains in the browser.',true);return false;}
      finally {inFlight=null;saveButton.disabled=false;}
    })();
    return inFlight;
  }
  function download(data,name) {
    const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
    const a=element('a',{href:url,download:name});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function closeDrawer() {drawer.hidden=true;drawer.replaceChildren();activeFigure=null;}
  function drawerHeader(title) {
    drawer.replaceChildren();drawer.hidden=false;
    const close=element('button',{type:'button',class:'drawer-close','aria-label':'Close panel'},'×');close.addEventListener('click',closeDrawer);
    drawer.append(close,element('h2',{},title));
  }
  function updateFigureView(f) {
    const figure=article.querySelector(`[data-figure-id="${f.id}"]`);
    if(!figure)return;
    figure.querySelector('figcaption').textContent=f.caption_mode==='generate'?'Caption to be generated during LaTeX export.':f.caption;
    figure.querySelector('.figure-note-count').textContent=figureCount(f);
    insertions?.refresh();
  }
  function openFigure(id) {
    const f=project.figures.find(f=>f.id===id);if(!f)return;
    activeFigure=id;drawerHeader(f.id+' · '+f.title);
    drawer.append(element('p',{class:'muted'},'Notes remain attached to this figure and are included in the LaTeX handoff.'));
    const figureLabel=element('input',{id:'figure-label',type:'text','aria-label':'Figure label'});figureLabel.value=f.label||'fig:'+f.id;
    const structuredReady=insertions?.isReady()===true;figureLabel.disabled=!structuredReady;
    figureLabel.addEventListener('change',()=>{try{const value=insertions.normalizeLabel(figureLabel.value,'figure',f.id);insertions.assertLabel(value,f.id);f.label=value;figureLabel.value=value;updateFigureView(f);changed();}catch(error){setStatus(error.message,true);figureLabel.value=f.label||'fig:'+f.id;}});
    drawer.append(element('label',{for:'figure-label'},'Reference label'),figureLabel);
    const captionMode=element('select',{id:'figure-caption-mode','aria-label':'Caption mode'});
    captionMode.append(element('option',{value:'manual'},'Use the written caption'),element('option',{value:'generate'},'Generate during HTML → LaTeX'));captionMode.value=f.caption_mode||'manual';
    captionMode.disabled=!structuredReady;
    if(!structuredReady&&connected)drawer.append(element('p',{class:'muted'},'Reopen the lesson from the app to enable saving labels and generated captions.'));
    drawer.append(element('label',{for:'figure-caption-mode'},'Caption mode'),captionMode);
    const label=element('label',{for:'figure-caption'},'Final caption');
    const caption=element('textarea',{id:'figure-caption','aria-label':'Final caption'});caption.value=f.caption;
    caption.addEventListener('input',()=>{f.caption=caption.value;updateFigureView(f);changed();});
    const promptLabel=element('label',{for:'figure-caption-prompt'},'Generation instructions (optional)');
    const prompt=element('textarea',{id:'figure-caption-prompt','aria-label':'Caption instructions'});prompt.value=f.caption_prompt||'';
    function setCaptionMode(){caption.disabled=captionMode.value==='generate';prompt.hidden=promptLabel.hidden=captionMode.value!=='generate';}
    captionMode.addEventListener('change',()=>{f.caption_mode=captionMode.value;setCaptionMode();updateFigureView(f);changed();});
    prompt.addEventListener('input',()=>{f.caption_prompt=prompt.value;changed();});setCaptionMode();
    drawer.append(label,caption,promptLabel,prompt,element('h3',{},'Figure instructions'));
    const list=element('div',{id:'figure-notes-list'});drawer.append(list);
    function addRow(note) {
      const row=element('div',{class:'editor-note','data-note-id':note.id});
      const input=element('textarea',{'aria-label':'Note for '+f.id});input.value=note.text;
      const select=element('select',{'aria-label':'Note status'});
      select.append(element('option',{value:'pending'},'Apply during LaTeX export'),element('option',{value:'done'},'Already applied'));select.value=note.status;
      const remove=element('button',{type:'button'},'Remove note');
      input.addEventListener('input',()=>{note.text=input.value;changed();});
      select.addEventListener('change',()=>{note.status=select.value;updateFigureView(f);changed();});
      remove.addEventListener('click',()=>{f.notes=f.notes.filter(n=>n.id!==note.id);row.remove();updateFigureView(f);changed();});
      row.append(input,select,remove);list.append(row);return input;
    }
    f.notes.forEach(addRow);
    const add=element('button',{type:'button',class:'editor-button primary',id:'add-figure-note'},'Add note');
    add.addEventListener('click',()=>{const note={id:uid(),text:'',status:'pending'};f.notes.push(note);addRow(note).focus();updateFigureView(f);changed();});drawer.append(add);
  }
  function openEquation(target) {
    if(insertions?.isReady())insertions.equation(target);
    else setStatus('Reopen the lesson from the app to edit and save formulas.',true);
  }
  function openAudio() {
    drawerHeader('Second-pass comparison');
    if(!report){drawer.append(element('p',{},'No second pass is available for this lesson.'));return;}
    drawer.append(element('p',{class:'muted'},`${report.first_model} → ${report.second_model}. Differences are ASR proposals, not an accuracy measurement.`));
    const player=element('audio',{controls:'',preload:'metadata'});
    if(connected) {player.src=`/api/audio/${encodeURIComponent(project.lesson)}`;drawer.append(player);player.addEventListener('timeupdate',()=>{if(audioEnd!==null && player.currentTime>=audioEnd)player.pause();});}
    else drawer.append(element('p',{class:'muted'},'Open the local editor to play audio excerpts and save directly to your computer.'));
    for(const c of report.cases) {
      const box=element('section',{class:'editor-audio-case'});
      box.append(element('h3',{},`${c.id} · ${c.start.toFixed(1)}–${c.end.toFixed(1)} s`),element('p',{class:'muted'},c.issue_ids.join(', ')));
      if(connected){const listen=element('button',{type:'button',class:'editor-button'},'Play excerpt');listen.addEventListener('click',async()=>{audioEnd=c.end;player.currentTime=c.start;try{await player.play();}catch(e){setStatus('Click Play in the audio player.',true);}});box.append(listen);}
      box.append(element('p',{},'First pass'),element('div',{class:'comparison'},c.first_text),element('p',{},'Second pass'),element('div',{class:'comparison'},c.second_text || '[No text recognized]'),element('p',{class:'decision'},(c.decision || 'pending')+(c.decision_note?' · '+c.decision_note:'')));
      drawer.append(box);
    }
  }
  function setEditing(value) {
    editing=value;article.contentEditable=String(value);modeButton.textContent=value?'Finish editing':'Edit text';modeButton.classList.toggle('primary',value);
    modeButton.setAttribute('aria-pressed',String(value));
    updateFormat();
  }
  const proseSelector='p,h1,h2,h3,h4,div';
  const protectedSelector='figure,[data-latex],.lecture-placeholder,.ndr,a[data-reference-target]';
  function formatBlocks(range) {
    if(!range||!article.contains(range.startContainer)||!article.contains(range.endContainer))return [];
    const eligible=node=>node!==article&&!node.closest(protectedSelector)&&!node.querySelector(proseSelector);
    if(range.collapsed){const parent=range.startContainer.nodeType===1?range.startContainer:range.startContainer.parentElement;const block=parent?.closest(proseSelector);return block&&eligible(block)?[block]:[];}
    return [...article.querySelectorAll(proseSelector)].filter(node=>{
      if(!eligible(node)||!range.intersectsNode(node))return false;
      const contents=document.createRange();contents.selectNodeContents(node);
      if(range.compareBoundaryPoints(Range.END_TO_START,contents)>=0||range.compareBoundaryPoints(Range.START_TO_END,contents)<=0)return false;
      const overlap=range.cloneRange();
      if(range.compareBoundaryPoints(Range.START_TO_START,contents)<0)overlap.setStart(contents.startContainer,contents.startOffset);
      if(range.compareBoundaryPoints(Range.END_TO_END,contents)>0)overlap.setEnd(contents.endContainer,contents.endOffset);
      const fragment=overlap.cloneContents();return Boolean(fragment.textContent||fragment.querySelector('br,[data-latex],.ndr,a[data-reference-target]'));
    });
  }
  function updateFormat() {
    const selection=getSelection();
    if(selection.rangeCount){const range=selection.getRangeAt(0);if(article.contains(range.startContainer)&&article.contains(range.endContainer))textRange=range.cloneRange();}
    const blocks=formatBlocks(textRange);formatSelect.disabled=!editing||!blocks.length;
    const tags=new Set(blocks.map(n=>n.tagName.toLowerCase()==='div'?'p':n.tagName.toLowerCase()));
    formatSelect.value=tags.size===1?[...tags][0]:'';
  }
  formatSelect.addEventListener('change',()=>{
    const tag=formatSelect.value,range=textRange?.cloneRange(),blocks=formatBlocks(range);
    if(!editing||!['p','h1','h2','h3','h4'].includes(tag)||!blocks.length)return;
    const points={start:range.startContainer,startOffset:range.startOffset,end:range.endContainer,endOffset:range.endOffset};
    const replacements=new Map();
    for(const block of blocks){
      if(block.tagName.toLowerCase()===tag)continue;
      const replacement=document.createElement(tag);for(const attr of block.attributes)replacement.setAttribute(attr.name,attr.value);
      replacement.append(...block.childNodes);block.replaceWith(replacement);replacements.set(block,replacement);
    }
    const restored=document.createRange();restored.setStart(replacements.get(points.start)||points.start,points.startOffset);restored.setEnd(replacements.get(points.end)||points.end,points.endOffset);
    article.focus({preventScroll:true});const selection=getSelection();selection.removeAllRanges();selection.addRange(restored);textRange=restored.cloneRange();
    toc();changed();updateFormat();
  });
  document.addEventListener('selectionchange',updateFormat);
  function importProject(candidate) {
    if(candidate.schema_version!==1 || candidate.project_id!==project.project_id || !candidate.document?.html || !candidate.document?.markdown)throw new Error('The file belongs to another lesson or is invalid.');
    const ids=new Set(project.figures.map(f=>f.id));
    if(!Array.isArray(candidate.figures) || new Set(candidate.figures.map(f=>f.id)).size!==candidate.figures.length ||
       candidate.figures.some(f=>!ids.has(f.id) && (f.kind!=='image'||!/^user-figure-[\w-]+$/.test(f.id))))throw new Error('The project figures do not match.');
    const revision=project.revision;project=structuredClone(candidate);project.revision=revision;project.document.html=sanitize(project.document.html);hydrate();changed();
  }
  modeButton.addEventListener('click',()=>setEditing(!editing));
  saveButton.addEventListener('click',()=>save());
  exportButton.addEventListener('click',()=>download(capture(),'lecture_project.json'));
  importButton.addEventListener('click',()=>importInput.click());
  importInput.addEventListener('change',async()=>{try{if(importInput.files[0])importProject(JSON.parse(await importInput.files[0].text()));}catch(e){setStatus(e.message,true);}finally{importInput.value='';}});
  audioButton.addEventListener('click',openAudio);
  article.addEventListener('input',event=>{if(!event.target.closest('figure,[data-latex],.lecture-placeholder,.ndr')){changed();toc();updateFormat();}});
  function touchesStructuredContent(range) {
    return !range.collapsed&&[...article.querySelectorAll('figure,[data-latex],.lecture-placeholder,.ndr')].some(node=>range.intersectsNode(node));
  }
  article.addEventListener('paste',event=>{
    if(!editing)return;event.preventDefault();
    const selection=getSelection();if(!selection.rangeCount)return;
    const range=selection.getRangeAt(0);
    if(!article.contains(range.startContainer)||!article.contains(range.endContainer))return;
    if(touchesStructuredContent(range)){setStatus('Right-click to edit or delete figures, formulas, and structured notes.',true);return;}
    range.deleteContents();
    const fragment=document.createDocumentFragment();const lines=event.clipboardData.getData('text/plain').split('\n');
    lines.forEach((line,i)=>{if(i)fragment.append(document.createElement('br'));fragment.append(document.createTextNode(line));});
    const last=fragment.lastChild;range.insertNode(fragment);if(last){range.setStartAfter(last);range.collapse(true);selection.removeAllRanges();selection.addRange(range);}changed();
  });
  article.addEventListener('drop',event=>event.preventDefault());
  article.addEventListener('beforeinput',event=>{
    if(!/^(delete|insert)/.test(event.inputType||''))return;
    const selection=getSelection();if(!selection.rangeCount)return;
    const ranges=[selection.getRangeAt(0)];
    for(const target of event.getTargetRanges?.()||[]){const range=document.createRange();range.setStart(target.startContainer,target.startOffset);range.setEnd(target.endContainer,target.endOffset);ranges.push(range);}
    if(ranges.some(touchesStructuredContent)){event.preventDefault();setStatus('Right-click to edit or delete figures, formulas, and structured notes.',true);}
  });
  document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();save();}if(event.key==='Escape')closeDrawer();});
  window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
  hydrate();
  setStatus(connected?`Saved to your computer · revision ${project.revision}`:'File mode · export the project to keep your changes');
  try {
    const raw=localStorage.getItem(storageKey);
    if(raw){const draft=JSON.parse(raw);if(draft.baseRevision===project.revision && draft.changedAt>project.updated_at){project=draft.project;hydrate();dirty=true;editVersion++;setStatus('Local draft restored. Saving…');if(connected)saveTimer=setTimeout(save,1800);}else if(draft.baseRevision!==project.revision){const recover=element('button',{type:'button'},'Export previous draft');recover.addEventListener('click',()=>download(draft.project,'lecture_project_recovered.json'));toolbar.append(recover);}}
  }catch(error){setStatus('Browser storage is unavailable. Use Save or Export.',true);}
  function installInsertions(){
    insertions=window.LectureInsertions.init({article,drawer,element,connected,uid,
      getProject:()=>project,capture,hydrate,changed,setStatus,setEditing,drawerHeader,closeDrawer,openFigure});
    insertions.refresh();
  }
  if(window.LectureInsertions)installInsertions();
  else if(editorSource){const script=element('script',{src:new URL('insertions.js',editorSource).href});script.onload=installInsertions;script.onerror=()=>setStatus('The insertion menu is unavailable: reopen the lesson from the app.',true);document.head.append(script);}
  window.lectureEditor={getProject:capture,save,setEditing,importProject,isDirty:()=>dirty,getTargets:()=>insertions?.targets()||[]};
})();
