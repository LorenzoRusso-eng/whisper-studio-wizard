/* Structured edits stay attached to stable IDs; captions and labels are data. */
window.LectureInsertions = (() => {
  'use strict';
  function init(api) {
    const {article,drawer,element:el,uid}=api;
    const names={figure:'Figure',equation:'Equation',table:'Table',other:'Element'};
    const prefixes={figure:'fig',equation:'eq',table:'tab',other:'item'};
    const menu=el('div',{id:'lecture-context-menu',class:'lecture-context-menu',role:'menu',hidden:''});document.body.append(menu);
    let position=null,clicked=null,moving=null;
    let ready=!api.connected,deletionsReady=!api.connected;
    const health=api.connected?fetch('/api/health').then(r=>r.json()).then(data=>{ready=data.editor_features?.includes('structured-insertions')===true;deletionsReady=data.editor_features?.includes('structured-deletions')===true;}).catch(()=>{}):Promise.resolve();
    const project=()=>api.getProject();
    function normalizeLabel(value,kind,fallback='') {
      let label=String(value||fallback).trim();
      if(!label)throw new Error('Inserisci una label per questo elemento.');
      if(!label.includes(':'))label=prefixes[kind]+':'+label;
      if(!/^[A-Za-z][A-Za-z0-9:_-]{0,99}$/.test(label)||label.endsWith(':')||!label.startsWith(prefixes[kind]+':'))throw new Error('Usa una label con prefisso '+prefixes[kind]+': e lettere, numeri, trattini o underscore.');
      return label;
    }
    function targets() {
      const counters={figure:0,equation:0,table:0,other:0},result=[];
      for(const node of article.querySelectorAll('figure[data-figure-id],.lecture-placeholder,[data-latex]')) {
        const f=node.matches('figure')?project().figures.find(f=>f.id===node.dataset.figureId):null;
        const kind=f?'figure':node.hasAttribute('data-latex')?'equation':node.dataset.placeholderKind;
        if(!names[kind])continue;
        const number=++counters[kind];
        if(!f&&!node.dataset.label)continue;
        const id=f?f.id:node.id;
        result.push({id,kind,number,label:f?(f.label||'fig:'+f.id):node.dataset.label,
          title:f?f.title:(node.dataset.description||node.dataset.latex||''),node,text:names[kind]+' '+number});
      }
      return result;
    }
    function assertLabel(label,id) {
      if(targets().some(t=>t.label===label&&t.id!==id))throw new Error('Questa label è già usata. Scegline una diversa.');
    }
    function refresh() {
      for(const node of article.querySelectorAll('.lecture-placeholder')) {
        node.contentEditable='false';node.replaceChildren();
        node.append(el('span',{class:'placeholder-kind'},(names[node.dataset.placeholderKind]||'Element')+' to insert'),
          el('strong',{class:'placeholder-label'},node.dataset.label),el('p',{},node.dataset.description||'Content to be supplied manually.'));
        if(node.dataset.source)node.append(el('p',{class:'placeholder-source'},'Source: '+node.dataset.source));
        const edit=el('button',{type:'button',class:'editor-button','data-editor-ui':''},'Modifica segnaposto');
        edit.addEventListener('click',()=>placeholder(node.dataset.placeholderKind,node));node.append(edit);
      }
      for(const node of article.querySelectorAll('.ndr')) {
        node.contentEditable='false';node.querySelectorAll('[data-editor-ui]').forEach(n=>n.remove());
        const inline=node.tagName==='SPAN';node.classList.toggle('ndr-inline',inline);
        const edit=el('button',{type:'button',class:'editor-button','data-editor-ui':'','aria-label':'Modifica NDR',title:'Modifica NDR'},inline?'✎':'Modifica NDR');
        edit.addEventListener('click',()=>ndr(node));node.append(edit);
      }
      const all=targets(),byId=new Map(all.map(t=>[t.id,t]));
      for(const target of all.filter(t=>t.kind==='equation'&&t.node.hasAttribute('data-latex'))) {
        const node=target.node;node.querySelectorAll('.equation-number[data-editor-ui]').forEach(n=>n.remove());
        node.title=target.text+' · '+target.label;
        if(node.dataset.mathDisplay!=='inline')node.append(el('span',{class:'equation-number','data-editor-ui':''},'('+target.number+')'));
      }
      for(const reference of article.querySelectorAll('a[data-reference-target]')) {
        const target=byId.get(reference.dataset.referenceTarget);reference.contentEditable='false';
        reference.classList.toggle('reference-missing',!target);
        if(target){reference.textContent=target.text;reference.href='#'+target.id;reference.dataset.referenceKind=target.kind;reference.title=target.label;}
        else reference.textContent='[Missing reference]';
      }
      for(const t of all.filter(t=>t.kind==='figure'&&!t.node.classList.contains('lecture-placeholder'))) {
        const f=project().figures.find(f=>f.id===t.id);
        const label=t.node.querySelector('.figure-number');if(label)label.textContent=t.label+' · '+(f.source||'');
        const controls=t.node.querySelector('.figure-editor-actions');
        if(controls&&!controls.querySelector('[data-move-figure]')) {
          const move=el('button',{type:'button',class:'editor-button','data-move-figure':t.id},'Sposta');
          move.addEventListener('click',()=>selectMove(t.node));controls.append(move);
        }
      }
    }
    function closeMenu(){menu.hidden=true;}
    function placeMenu(x,y){const box=menu.getBoundingClientRect();menu.style.left=Math.max(6,Math.min(x,innerWidth-box.width-6))+'px';menu.style.top=Math.max(6,Math.min(y,innerHeight-box.height-6))+'px';}
    function pointRange(event) {
      let range;
      if(event.clientX||event.clientY) {
        if(document.caretRangeFromPoint)range=document.caretRangeFromPoint(event.clientX,event.clientY);
        else if(document.caretPositionFromPoint){const caret=document.caretPositionFromPoint(event.clientX,event.clientY);if(caret){range=document.createRange();range.setStart(caret.offsetNode,caret.offset);}}
      }
      if(!range){const selection=getSelection();if(selection.rangeCount)range=selection.getRangeAt(0).cloneRange();}
      if(!range||!article.contains(range.startContainer)) {range=document.createRange();range.selectNodeContents(article);range.collapse(false);}
      range=range.cloneRange();range.collapse(true);
      const parent=range.startContainer.nodeType===1?range.startContainer:range.startContainer.parentElement;
      const atomic=parent?.closest('figure,[data-latex],.lecture-placeholder,.ndr,a[data-reference-target]');
      if(atomic&&article.contains(atomic))range.setStartAfter(atomic);
      range.collapse(true);return range;
    }
    function insertionRange(){
      if(!position||!article.contains(position.startContainer))throw new Error('Scegli nuovamente il punto nel testo con il tasto destro.');
      return position.cloneRange();
    }
    function insertBlock(node) {
      const range=insertionRange();
      if(node.contains(range.startContainer))throw new Error('Scegli una posizione esterna alla figura da spostare.');
      if(node.isConnected)node.remove();
      const parent=range.startContainer.nodeType===1?range.startContainer:range.startContainer.parentElement;
      const heading=parent?.closest('h1,h2,h3,h4');
      if(heading){heading.after(node);return;}
      const block=parent?.closest('p,li,td,th,div,blockquote,article');
      if(!block||!article.contains(block)){range.insertNode(node);return;}
      const tail=range.cloneRange();tail.setEnd(block,block.childNodes.length);
      const fragment=tail.extractContents();
      if(block.matches('p')||(block.matches('div')&&!block.querySelector('p,div,h1,h2,h3,h4,ul,ol,table,figure,blockquote'))) {
        const next=block.cloneNode(false);next.removeAttribute('id');next.removeAttribute('data-block-id');next.append(fragment);
        if(!next.textContent.trim()&&!next.querySelector('br,figure,[data-latex],.lecture-placeholder,.ndr'))next.append(el('br'));
        block.after(node,next);
      } else {block.append(node,fragment);if(block===article&&!node.nextSibling){const paragraph=el('p');paragraph.append(el('br'));block.append(paragraph);}}
    }
    function insertInline(node) {
      const range=insertionRange();
      const parent=range.startContainer.nodeType===1?range.startContainer:range.startContainer.parentElement;
      if(parent?.closest('p,li,td,th,h1,h2,h3,h4,div,blockquote'))range.insertNode(node);
      else{const paragraph=el('p');paragraph.append(node);insertBlock(paragraph);}
    }
    function replaceMathOrNote(node,target,inline) {
      if(!node){if(inline)insertInline(target);else insertBlock(target);return;}
      const wasInline=node.tagName==='SPAN';
      if(wasInline&&!inline){position=document.createRange();position.setStartBefore(node);position.collapse(true);node.remove();insertBlock(target);}
      else if(!wasInline&&inline&&!node.parentElement.closest('p,li,td,th,h1,h2,h3,h4')){
        const previous=node.previousElementSibling;
        if(previous?.matches('p')){if(previous.textContent&&!/\s$/.test(previous.textContent))previous.append(document.createTextNode(' '));previous.append(target);node.remove();}
        else{const paragraph=el('p');paragraph.append(target);node.replaceWith(paragraph);}
      }
      else node.replaceWith(target);
    }
    function commit(id) {
      const snapshot=api.capture();project().document=snapshot.document;project().title=snapshot.title;
      api.setEditing(true);api.hydrate();api.changed();position=null;
      const target=id?document.getElementById(id):null;
      if(target){const range=document.createRange(),next=target.nextElementSibling;
        if(target.matches('figure,.lecture-placeholder,blockquote.ndr,.equation')&&next?.matches('p')){range.selectNodeContents(next);range.collapse(true);}
        else{range.setStartAfter(target);range.collapse(true);}
        article.focus({preventScroll:true});const selection=getSelection();selection.removeAllRanges();selection.addRange(range);target.scrollIntoView({block:'nearest',behavior:'instant'});}
    }
    function referencesTo(node) {
      const id=node.matches('figure')?node.dataset.figureId:node.id;
      return id?[...article.querySelectorAll('a[data-reference-target]')].filter(ref=>ref.dataset.referenceTarget===id&&!node.contains(ref)):[];
    }
    function removalLabel(node,text) {
      const count=referencesTo(node).length;
      return text+(count?' e '+count+' riferiment'+(count===1?'o':'i'):'');
    }
    function removeElement(node) {
      if(!deletionsReady)throw new Error('Riapri la lezione dall’app per attivare il salvataggio delle eliminazioni.');
      if(!node||!article.contains(node))throw new Error('L’elemento da eliminare non è più presente.');
      const id=node.dataset.figureId||node.id;
      for(const ref of referencesTo(node))ref.remove();
      if(node.matches('figure'))project().figures=project().figures.filter(f=>f.id!==id);
      node.remove();
      if(moving?.id===id)moving=null;
      clicked=null;api.closeDrawer();commit();
    }
    function field(id,label,value='',multiline=false) {
      const input=el(multiline?'textarea':'input',{id,...(multiline?{}:{type:'text'})});input.value=value;
      drawer.append(el('label',{for:id},label),input);return input;
    }
    function submit(id,text,callback,primary=true) {
      const button=el('button',{id,type:'button',class:'editor-button'+(primary?' primary':'')},text);
      const feedback=el('p',{class:'editor-form-error',role:'alert'});
      button.addEventListener('click',async()=>{button.disabled=true;feedback.textContent='';try{await callback();}catch(error){feedback.textContent=error.message;api.setStatus(error.message,true);}finally{button.disabled=false;}});
      drawer.append(button,feedback);return button;
    }
    function placeholder(kind,node=null) {
      api.drawerHeader(node?'Modifica segnaposto':'Inserisci segnaposto · '+names[kind]);
      const id=node?.id||'placeholder-'+uid();
      const label=field('placeholder-label','Label',node?.dataset.label||prefixes[kind]+':manual-'+uid().slice(0,8));
      const description=field('placeholder-description','Descrizione del contenuto',node?.dataset.description||'',true);
      const source=field('placeholder-source','Fonte / pagina (facoltative)',node?.dataset.source||'');
      const action=field('placeholder-action','Azione da completare',node?.dataset.action||'Insert the missing '+names[kind].toLowerCase()+' manually.',true);
      submit('apply-placeholder',node?'Applica segnaposto':'Inserisci segnaposto',()=>{
        const value=normalizeLabel(label.value,kind);assertLabel(value,id);
        const target=node||el('div',{id,class:'lecture-placeholder'});
        Object.assign(target.dataset,{placeholderKind:kind,label:value,description:description.value,source:source.value,action:action.value});
        if(!node)insertBlock(target);
        api.closeDrawer();commit(id);
      });label.focus();
    }
    function reference() {
      api.drawerHeader('Inserisci riferimento');
      const options=targets();
      if(!options.length){drawer.append(el('p',{},'Inserisci prima una figura, una formula o un segnaposto con una label.'));return;}
      const choose=el('select',{id:'reference-target',size:Math.min(options.length,8),'aria-label':'Elemento da richiamare'});
      for(const t of options)choose.append(el('option',{value:t.id},t.text+' · '+t.label+' · '+t.title));
      choose.value=options.find(t=>t.id===(clicked?.dataset.figureId||clicked?.id))?.id||options[0].id;
      drawer.append(el('p',{class:'muted'},'Comprende figure, formule inline e display e segnaposto. I numeri seguono l’ordine nel testo; i riferimenti restano collegati anche cambiando label.'),choose);
      submit('apply-reference','Inserisci riferimento',()=>{
        const target=targets().find(t=>t.id===choose.value);if(!target)throw new Error('L’elemento non è più presente.');
        const id='reference-'+uid();
        const anchor=el('a',{id,class:'lecture-reference',href:'#'+target.id,'data-reference-target':target.id,'data-reference-kind':target.kind},target.text);
        const fragment=document.createDocumentFragment();fragment.append(document.createTextNode(' '),anchor,document.createTextNode(' '));insertInline(fragment);
        api.closeDrawer();commit(id);
      });choose.focus();
    }
    function equation(node=null,initialMode='display') {
      api.drawerHeader(node?'Modifica formula':'Inserisci formula LaTeX');
      drawer.append(el('p',{class:'muted'},'Scrivi il sorgente LaTeX. La formula e la sua label vengono conservate per l’esportazione.'));
      const id=node?.id||'equation-'+uid();
      const mode=el('select',{id:'equation-mode','aria-label':'Formato della formula'});
      mode.append(el('option',{value:'inline'},'Inline · dentro il testo'),el('option',{value:'display'},'Display · su una riga separata'));
      mode.value=node?(node.dataset.mathDisplay||(node.tagName==='SPAN'?'inline':'display')):initialMode;
      drawer.append(el('label',{for:mode.id},'Formato'),mode);
      const label=field('equation-label','Label per i riferimenti',node?.dataset.label||'eq:'+id);
      const input=field('equation-source','Formula LaTeX',node?.dataset.latex||'',true);
      input.setAttribute('aria-label','Formula LaTeX');input.spellcheck=false;
      const preview=el('div',{id:'equation-preview',class:'editor-equation-preview','aria-label':'Anteprima della formula'});
      const error=el('p',{class:'equation-error',role:'status','aria-live':'polite'});drawer.append(preview,error);
      const source=()=>{
        let value=input.value.trim();
        for(const [start,end] of [['\\[','\\]'],['\\(','\\)'],['$$','$$'],['$','$']])if(value.startsWith(start)&&value.endsWith(end)&&value.length>=start.length+end.length){value=value.slice(start.length,-end.length).trim();break;}
        return value;
      };
      function update() {
        preview.replaceChildren();error.textContent='';
        if(!source()){preview.textContent='L’anteprima appare qui.';return;}
        try{if(!window.katex)throw new Error('Visualizzazione formule non disponibile. Riapri la lezione dall’app.');
          katex.render(source(),preview,{displayMode:mode.value==='display',throwOnError:true,trust:false,maxExpand:1000,maxSize:20});
        }catch(cause){error.textContent=cause.message;}
      }
      input.addEventListener('input',update);mode.addEventListener('change',update);update();
      submit('apply-equation',node?'Applica formula':'Inserisci formula',()=>{
        const latex=source();if(!latex)throw new Error('Scrivi la formula LaTeX.');
        update();if(error.textContent)throw new Error('Formula non valida: '+error.textContent);
        const value=normalizeLabel(label.value,'equation');assertLabel(value,id);
        const inline=mode.value==='inline',target=el(inline?'span':'div');
        if(node)for(const attr of node.attributes)if(['id','class','data-block-id'].includes(attr.name))target.setAttribute(attr.name,attr.value);
        target.id=id;target.classList.toggle('equation',!inline);target.classList.toggle('equation-inline',inline);
        Object.assign(target.dataset,{latex,mathDisplay:mode.value,label:value});target.textContent=latex;
        replaceMathOrNote(node,target,inline);api.closeDrawer();commit(id);
      });
      if(node)submit('remove-equation',removalLabel(node,'Elimina formula'),()=>removeElement(node),false);input.focus();
    }
    async function fileData(file) {
      if(!file||!/^image\/(png|jpeg|webp)$/.test(file.type))throw new Error('Scegli un’immagine PNG, JPEG o WebP.');
      if(file.size>10*1024*1024)throw new Error('L’immagine supera il limite di 10 MB.');
      return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('Impossibile leggere l’immagine.'));reader.readAsDataURL(file);});
    }
    function image() {
      api.drawerHeader('Inserisci figura');
      const file=el('input',{id:'figure-file',type:'file',accept:'image/png,image/jpeg,image/webp'});
      drawer.append(el('label',{for:'figure-file'},'Immagine PNG, JPEG o WebP'),file);
      const label=field('insert-figure-label','Label','fig:image-'+uid().slice(0,8));
      const title=field('insert-figure-title','Titolo breve (facoltativo)');
      const mode=el('select',{id:'insert-figure-caption-mode','aria-label':'Gestione didascalia'});
      mode.append(el('option',{value:'manual'},'Scrivi la didascalia adesso'),el('option',{value:'generate'},'Genera durante HTML → LaTeX'));
      drawer.append(el('label',{for:mode.id},'Didascalia'),mode);
      const caption=field('insert-figure-caption','Testo della didascalia','',true);
      const guidance=field('insert-figure-caption-prompt','Indicazioni per generarla (facoltative)','',true);
      const update=()=>{caption.disabled=mode.value==='generate';guidance.hidden=guidance.previousElementSibling.hidden=mode.value!=='generate';};mode.addEventListener('change',update);update();
      submit('apply-insert-figure','Inserisci figura',async()=>{
        const value=normalizeLabel(label.value,'figure');assertLabel(value);
        const selectedMode=mode.value,selectedCaption=caption.value,selectedGuidance=guidance.value,selectedTitle=title.value.trim();
        if(selectedMode==='manual'&&!selectedCaption.trim())throw new Error('Scrivi la didascalia oppure scegli di generarla in LaTeX.');
        const id='user-figure-'+uid(),chosen=file.files[0],data=await fileData(chosen);let asset='assets/imported/embedded-'+id+'.png',embedded_data=data;
        if(api.connected){
          const response=await fetch('/api/assets/'+encodeURIComponent(project().lesson),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data})});
          const result=await response.json();if(!response.ok)throw new Error(result.error||'Caricamento non riuscito.');asset=result.asset;embedded_data=null;
        }
        if(!file.isConnected)return;
        const node=el('figure',{'data-figure-id':id});
        insertionRange();insertBlock(node);
        project().figures.push({id,kind:'image',asset,label:value,title:selectedTitle||chosen.name,source:chosen.name,
          caption:selectedCaption,caption_mode:selectedMode,caption_prompt:selectedGuidance,notes:[],...(embedded_data?{embedded_data}:{})});
        api.closeDrawer();commit(id);
      });file.focus();
    }
    function ndr(node=null,initialMode='inline') {
      api.drawerHeader(node?'Modifica NDR':'Inserisci NDR');
      drawer.append(el('p',{class:'muted'},'Nota del redattore: visibile nella revisione HTML ed esclusa dal PDF finale.'));
      const mode=el('select',{id:'ndr-mode','aria-label':'Formato della NDR'});
      mode.append(el('option',{value:'inline'},'Inline · nel punto del testo'),el('option',{value:'block'},'Blocco · su una riga separata'));
      mode.value=node?(node.tagName==='SPAN'?'inline':'block'):initialMode;drawer.append(el('label',{for:mode.id},'Formato'),mode);
      const text=field('ndr-text','Testo della nota',node?.querySelector('.ndr-text')?.textContent||'',true);
      submit('apply-ndr',node?'Applica NDR':'Inserisci NDR',()=>{
        if(!text.value.trim())throw new Error('Scrivi il testo della nota.');
        const inline=mode.value==='inline',target=el(inline?'span':'blockquote',{id:node?.id||'ndr-'+uid(),class:'review-only editorial-note ndr'+(inline?' ndr-inline':'')});
        const content=inline?target:el('p');content.append(el('strong',{},'NDR: '),el('span',{class:'ndr-text'},text.value));if(!inline)target.append(content);
        replaceMathOrNote(node,target,inline);api.closeDrawer();commit(target.id);
      });
      if(node)submit('remove-ndr','Elimina NDR',()=>removeElement(node),false);text.focus();
    }
    function selectMove(node) {
      moving={id:node.dataset.figureId||node.id,figure:node.matches('figure')};closeMenu();
      const target=targets().find(t=>t.id===moving.id);
      api.setStatus((target?.label||'Elemento')+' selezionato: tasto destro nel punto desiderato, poi “Sposta qui”.');
    }
    function moveHere() {
      const node=moving?.figure?[...article.querySelectorAll('figure[data-figure-id]')].find(n=>n.dataset.figureId===moving.id):document.getElementById(moving?.id);
      if(!node||!article.contains(node))throw new Error('L’elemento da spostare non è più presente.');
      if(node===clicked)throw new Error('Scegli un altro punto nel testo.');
      const id=moving.id;insertBlock(node);moving=null;commit(id);
    }
    function item(id,text,callback) {
      const button=el('button',{id,type:'button',role:'menuitem'},text);
      button.addEventListener('click',()=>{closeMenu();try{callback();}catch(error){api.setStatus(error.message,true);}});menu.append(button);return button;
    }
    article.addEventListener('contextmenu',async event=>{
      event.preventDefault();position=pointRange(event);clicked=event.target.closest('figure,.lecture-placeholder,.ndr,[data-latex],a[data-reference-target]');
      await health;
      if(!ready){api.setStatus('Riapri la lezione dall’app per attivare il nuovo menu e il salvataggio degli inserimenti.',true);return;}
      menu.replaceChildren();
      if(clicked?.matches('figure')){item('context-edit-figure','Note, label e didascalia…',()=>api.openFigure(clicked.dataset.figureId));item('context-move-figure','Sposta questa figura',()=>selectMove(clicked));}
      else if(clicked?.matches('.lecture-placeholder')){item('context-edit-placeholder','Modifica questo segnaposto…',()=>placeholder(clicked.dataset.placeholderKind,clicked));item('context-move-placeholder','Sposta questo segnaposto',()=>selectMove(clicked));}
      else if(clicked?.matches('.ndr'))item('context-edit-ndr','Modifica questa NDR…',()=>ndr(clicked));
      else if(clicked?.hasAttribute('data-latex'))item('context-edit-equation','Modifica questa formula…',()=>equation(clicked));
      if(clicked&&article.contains(clicked)){
        const node=clicked;
        const label=node.matches('figure')?'Elimina questa figura':node.matches('.lecture-placeholder')?'Elimina questo segnaposto':node.matches('.ndr')?'Elimina questa NDR':node.hasAttribute('data-latex')?'Elimina questa formula':'Elimina questo riferimento';
        const remove=item('context-delete-element',removalLabel(node,label),()=>removeElement(node));remove.classList.add('context-delete');
        remove.disabled=!deletionsReady;
        if(!deletionsReady)remove.title='Riapri la lezione dall’app per attivare il salvataggio delle eliminazioni.';
      }
      if(moving)item('context-move-here','Sposta qui l’elemento selezionato',moveHere);
      item('context-equation-inline','Inserisci formula inline…',()=>equation(null,'inline'));
      item('context-equation-display','Inserisci formula display…',()=>equation(null,'display'));
      item('context-placeholder-figure','Segnaposto figura…',()=>placeholder('figure'));
      item('context-placeholder-equation','Segnaposto equazione…',()=>placeholder('equation'));
      item('context-placeholder-table','Segnaposto tabella…',()=>placeholder('table'));
      item('context-placeholder-other','Altro segnaposto…',()=>placeholder('other'));
      item('context-reference','Inserisci riferimento…',reference);
      item('context-image','Inserisci immagine…',image);
      item('context-ndr','Inserisci NDR inline…',()=>ndr());
      item('context-ndr-block','Inserisci NDR a blocco…',()=>ndr(null,'block'));
      menu.hidden=false;
      const rect=position.getBoundingClientRect();
      placeMenu(event.clientX||rect.left,event.clientY||rect.top);
      menu.querySelector('button')?.focus({preventScroll:true});
    });
    document.addEventListener('pointerdown',event=>{if(!menu.contains(event.target))closeMenu();});
    document.addEventListener('keydown',event=>{if(event.key==='Escape'){closeMenu();moving=null;}if(menu.hidden)return;
      if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();const buttons=[...menu.querySelectorAll('button')],i=buttons.indexOf(document.activeElement);buttons[(i+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();}});
    window.addEventListener('resize',()=>{if(!menu.hidden)placeMenu(parseFloat(menu.style.left)||6,parseFloat(menu.style.top)||6);});
    return {refresh,targets,equation,normalizeLabel,assertLabel,isReady:()=>ready};
  }
  return {init};
})();
