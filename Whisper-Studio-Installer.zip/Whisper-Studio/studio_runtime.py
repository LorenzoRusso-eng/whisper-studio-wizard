"""Small, dependency-free platform and installation helpers."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INSTALLATION = ROOT / '.state/installation.json'
PROVIDERS = {
    'codex': {'name': 'Codex CLI', 'package': '@openai/codex',
              'docs': 'https://developers.openai.com/codex/cli/', 'login': ['login']},
    'claude': {'name': 'Claude Code', 'package': '@anthropic-ai/claude-code',
               'docs': 'https://code.claude.com/docs/en/setup', 'login': ['auth', 'login']},
    'gemini': {'name': 'Gemini CLI', 'package': '@google/gemini-cli',
               'docs': 'https://geminicli.com/docs/get-started/installation/', 'login': []},
}


def configure_tools_path():
    directories = [ROOT / '.tools', ROOT / '.tools/bin']
    if sys.platform=='darwin':directories.append(Path('/Library/TeX/texbin'))
    if os.name=='nt':
        for variable,relative in [('LOCALAPPDATA','Programs/MiKTeX/miktex/bin/x64'),
                                  ('PROGRAMFILES','MiKTeX/miktex/bin/x64')]:
            if os.environ.get(variable):directories.append(Path(os.environ[variable])/relative)
    runtime = ROOT / '.tools/runtime'
    if runtime.is_dir():
        for candidate in sorted(runtime.glob('node-*'), reverse=True):
            directories.append(candidate if os.name == 'nt' else candidate / 'bin')
    existing = os.environ.get('PATH', '').split(os.pathsep)
    os.environ['PATH'] = os.pathsep.join([str(p) for p in directories if p.is_dir() and str(p) not in existing] + existing)


configure_tools_path()


def load_installation():
    try:
        data = json.loads(INSTALLATION.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_installation(data):
    INSTALLATION.parent.mkdir(parents=True, exist_ok=True)
    temporary = INSTALLATION.with_suffix('.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(temporary, INSTALLATION)
    finally:
        temporary.unlink(missing_ok=True)


def venv_python(root=ROOT, *, windowless=False):
    root = Path(root)
    if os.name == 'nt':
        return root / '.venv/Scripts' / ('pythonw.exe' if windowless else 'python.exe')
    return root / '.venv/bin/python'


def hidden_process_options():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def open_path(path):
    path = str(Path(path).resolve())
    if os.name == 'nt':
        os.startfile(path)
    else:
        subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', path])


def provider_id(value=None):
    value = value or load_installation().get('ai_provider', 'codex')
    if value not in PROVIDERS:
        raise ValueError('Assistente non valido: scegli codex, claude o gemini')
    return value


def configure_progress_style(style):
    element='Wizard.Progressbar.pbar'
    if element not in style.element_names():
        style.element_create(element,'from','default','Horizontal.Progressbar.pbar')
    name='Wizard.Horizontal.TProgressbar'
    style.layout(name,[('Horizontal.Progressbar.trough',{'sticky':'nsew','children':[
        (element,{'side':'left','sticky':'ns'})]})])
    style.configure(name,background='#6554D9',troughcolor='#EEEAF9',borderwidth=0,thickness=9)
    return name
