"""Whisper Studio desktop interface. All Tk calls stay on the main thread."""

from __future__ import annotations

import ctypes
import hashlib
import json
import logging
import logging.handlers
import os
import queue
import shutil
import subprocess
import sys
import threading
import traceback
import uuid
from ctypes import wintypes
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
AUDIO_ROOT = PROJECT_ROOT / "Audio"
OUTPUT_ROOT = PROJECT_ROOT / "outputs"
STATE_ROOT = PROJECT_ROOT / ".state"
LOGGER = logging.getLogger("whisper_studio")


def configure_tk_environment() -> None:
    if os.name != "nt":
        return
    # Use Tcl/Tk belonging to this interpreter, never another Python installation.
    tcl_root = Path(sys.base_prefix) / "tcl"
    for variable, directory in (("TCL_LIBRARY", "tcl8.6"), ("TK_LIBRARY", "tk8.6")):
        if (tcl_root / directory).is_dir():
            os.environ[variable] = str(tcl_root / directory)
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except (OSError, AttributeError):
        pass


configure_tk_environment()


def setup_logging() -> None:
    directory = PROJECT_ROOT / ".logs"
    directory.mkdir(parents=True, exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(
        directory / "whisper-studio.log",
        maxBytes=2_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    logging.getLogger().addHandler(handler)
    logging.getLogger().setLevel(logging.INFO)


def show_startup_error(message: str) -> None:
    if os.name == "nt":
        ctypes.windll.user32.MessageBoxW(0, message, "Whisper Studio", 0x10)
    else:
        print(message, file=sys.stderr)


STARTUP_IMPORT_ERROR = None
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from job_queue import JobQueue
    from transcribe import (
        KNOWN_EXTENSIONS,
        build_output_base,
        hidden_process_options,
        output_file,
    )
except Exception as exc:
    STARTUP_IMPORT_ERROR = exc


def list_audio_files() -> list[Path]:
    if not AUDIO_ROOT.exists():
        return []
    return sorted(
        (
            p
            for p in AUDIO_ROOT.rglob("*")
            if p.is_file() and p.suffix.lower() in KNOWN_EXTENSIONS
        ),
        key=lambda p: str(p).casefold(),
    )


def relative_output_base(audio_path: Path) -> Path:
    return build_output_base(audio_path, OUTPUT_ROOT, create=False)


def transcript_paths(audio_path: Path) -> list[Path]:
    base = relative_output_base(audio_path)
    paths = [output_file(base, extension) for extension in ("txt", "srt", "json")]
    # Discover older exports too, including the former dotted-filename bug.
    legacy = (
        OUTPUT_ROOT
        / audio_path.relative_to(AUDIO_ROOT).parent
        / audio_path.stem
        / audio_path.stem
    )
    paths += [legacy.with_suffix(extension) for extension in (".txt", ".srt", ".json")]
    return list(dict.fromkeys(paths))


def transcript_status(audio_path: Path) -> str:
    paths = transcript_paths(audio_path)
    for path in paths:
        if path.suffix != ".json" or not path.is_file():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict) or not isinstance(
                payload.get("segments"), list
            ):
                return 'Invalid output'
            if not payload.get("segments"):
                return 'Empty: retry needed'
            if payload.get("schema_version", 1) < 2 or not payload.get("model"):
                return 'Legacy output: review needed'
            stat = audio_path.stat()
            if (
                payload.get("input_size_bytes") != stat.st_size
                or payload.get("input_mtime_ns") != stat.st_mtime_ns
            ):
                return 'Audio changed'
            checksums = payload.get("output_sha256", {})
            if not isinstance(checksums, dict):
                return 'Invalid output'
            for name, expected_hash in checksums.items():
                output = path.parent / name
                if (
                    Path(name).name != name
                    or not output.is_file()
                    or hashlib.sha256(output.read_bytes()).hexdigest() != expected_hash
                ):
                    return 'Partial or modified output'
            return 'Needs review' if payload.get("warnings") else 'Transcribed'
        except (OSError, ValueError, TypeError):
            return 'Invalid output'
    return 'Partial output' if any(p.is_file() for p in paths) else 'Not transcribed'


def has_transcript(audio_path: Path) -> bool:
    return transcript_status(audio_path) == 'Transcribed'


def safe_copy_to_audio(source_path: Path, cancel_event=None) -> Path:
    source_path = source_path.resolve()
    if not source_path.is_file() or source_path.suffix.lower() not in KNOWN_EXTENSIONS:
        raise ValueError(f"Unsupported format: {source_path.name}")
    try:
        source_path.relative_to(AUDIO_ROOT.resolve())
        return source_path
    except ValueError:
        pass
    AUDIO_ROOT.mkdir(parents=True, exist_ok=True)
    temporary = AUDIO_ROOT / f".import-{uuid.uuid4().hex}.tmp"
    try:
        with source_path.open("rb") as source, temporary.open("xb") as target:
            while True:
                if cancel_event and cancel_event.is_set():
                    raise InterruptedError('Import canceled')
                block = source.read(4 * 1024 * 1024)
                if not block:
                    break
                target.write(block)
        shutil.copystat(source_path, temporary)
        counter = 0
        while True:
            name = (
                source_path.name
                if not counter
                else f"{source_path.stem} ({counter}){source_path.suffix}"
            )
            target = AUDIO_ROOT / name
            try:
                # On Windows rename refuses to replace an existing file.
                if os.name == "nt":
                    temporary.rename(target)
                else:
                    os.link(temporary, target)
                    temporary.unlink()
                return target
            except FileExistsError:
                counter += 1
    finally:
        if temporary.exists():
            temporary.unlink()


STATUS_LABELS = {
    "queued": 'Waiting',
    "running": 'Running',
    "cancelling": 'Canceling',
    "done": 'Completed',
    "warning": 'Needs review',
    "failed": 'Error',
    "cancelled": 'Canceled',
}


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Whisper Studio")
        self.root.geometry("1220x820")
        self.root.minsize(940, 660)
        self.root.report_callback_exception = self.report_callback_exception
        self.closing = False
        self.import_cancel = threading.Event()
        self.background_events = queue.Queue()
        self.import_thread = None
        self.gpu_poll_running = False
        self.display_job_id = None
        self.files = {}
        self.output_entries = {}
        self.current_output_dir = OUTPUT_ROOT
        self._window_proc = self._old_wndproc = None
        self._drop_hwnd = None
        self.library_cache = {}
        self.last_queue_view = None
        self.settings = self.load_settings()
        self.preset = tk.StringVar(value=self.settings.get("preset", "balanced"))
        self.language = tk.StringVar(value=self.settings.get("language", "auto"))
        self.device = tk.StringVar(value=self.settings.get("device", "auto"))
        self.task = tk.StringVar(value=self.settings.get("task", "transcribe"))
        self.model = tk.StringVar(value=self.settings.get("model", "auto"))
        self.no_vad = tk.BooleanVar(value=self.settings.get("no_vad", False))
        self.word_timestamps = tk.BooleanVar(
            value=self.settings.get("word_timestamps", False)
        )
        self.audio_review = tk.BooleanVar(value=self.settings.get("audio_review", True))
        self.status = tk.StringVar(value='Select one or more files to transcribe.')
        self.phase = tk.StringVar(value='Waiting')
        self.current_file = tk.StringVar(value='No transcription running')
        self.gpu_text = tk.StringVar(value='GPU idle')
        self.progress_text = tk.StringVar(value="0%")
        self.queue_text = tk.StringVar(value='Queue empty')
        self.output_dir_text = tk.StringVar(value="outputs")
        self.build_ui()
        self.controller = JobQueue(STATE_ROOT / "queue.json", OUTPUT_ROOT)
        if self.controller.snapshot()["paused"]:
            self.status.set('Queue recovered. Click Resume queue to continue.')
        self.refresh_library_views()
        self.install_file_drop()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(100, self.poll_events)
        self.root.after(1000, self.schedule_gpu_poll)

    def load_settings(self) -> dict:
        try:
            data = json.loads(
                (STATE_ROOT / "settings.json").read_text(encoding="utf-8")
            )
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def options(self) -> dict:
        return {
            "preset": self.preset.get(),
            "language": None if self.language.get() == "auto" else self.language.get(),
            "device": self.device.get(),
            "task": self.task.get(),
            "model": None if self.model.get() == "auto" else self.model.get(),
            "no_vad": self.no_vad.get(),
            "word_timestamps": self.word_timestamps.get(),
            "audio_review": self.audio_review.get(),
            "initial_prompt": self.prompt.get("1.0", "end").strip(),
        }

    def save_settings(self) -> None:
        from transcribe import write_json_output

        settings = self.options()
        settings["language"] = settings["language"] or "auto"
        settings["model"] = settings["model"] or "auto"
        write_json_output(STATE_ROOT / "settings.json", settings)

    def build_ui(self) -> None:
        self.root.configure(bg="#f3eef8")
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#f3eef8")
        style.configure("TLabel", background="#f3eef8", foreground="#332042")
        style.configure("TButton", padding=(10, 7))
        style.configure("Treeview", rowheight=29, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 10))
        style.configure(
            "Purple.Horizontal.TProgressbar",
            background="#7c3aed",
            troughcolor="#e8dff0",
        )
        container = ttk.Frame(self.root, padding=18)
        container.pack(fill="both", expand=True)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(2, weight=1)
        hero = tk.Frame(container, bg="#4f2d74", padx=22, pady=16)
        hero.grid(row=0, column=0, sticky="ew")
        tk.Label(
            hero,
            text="Whisper Studio",
            bg="#4f2d74",
            fg="white",
            font=("Segoe UI Semibold", 24),
        ).pack(anchor="w")
        tk.Label(
            hero,
            text='Local transcription · multilingual · GPU or CPU',
            bg="#4f2d74",
            fg="#eadcff",
            font=("Segoe UI", 11),
        ).pack(anchor="w", pady=(5, 0))
        toolbar = ttk.Frame(container, padding=(0, 12))
        toolbar.grid(row=1, column=0, sticky="ew")
        toolbar.columnconfigure(6, weight=1)
        self.import_button = ttk.Button(
            toolbar, text='Import audio/video', command=self.upload_files
        )
        self.import_button.grid(row=0, column=0, padx=(0, 7))
        ttk.Button(
            toolbar, text='Transcribe selected', command=self.queue_selected_files
        ).grid(row=0, column=1, padx=7)
        ttk.Button(toolbar, text='Refresh', command=self.refresh_library_views).grid(
            row=0, column=2, padx=7
        )
        ttk.Button(
            toolbar,
            text='Show queue',
            command=lambda: self.tabs.select(self.queue_tab),
        ).grid(row=0, column=3, padx=7)
        ttk.Label(toolbar, textvariable=self.queue_text).grid(
            row=0, column=6, sticky="e"
        )
        self.tabs = ttk.Notebook(container)
        self.tabs.grid(row=2, column=0, sticky="nsew")
        self.library_tab = ttk.Frame(self.tabs, padding=12)
        self.queue_tab = ttk.Frame(self.tabs, padding=12)
        self.settings_tab = ttk.Frame(self.tabs, padding=20)
        self.tabs.add(self.library_tab, text='Library and output')
        self.tabs.add(self.queue_tab, text='Queue and history')
        self.tabs.add(self.settings_tab, text='Settings')
        self.build_library()
        self.build_queue()
        self.build_settings()
        footer = ttk.Frame(container, padding=(0, 12, 0, 0))
        footer.grid(row=3, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)
        ttk.Label(
            footer,
            textvariable=self.current_file,
            font=("Segoe UI Semibold", 11),
            wraplength=720,
        ).grid(row=0, column=0, sticky="w")
        ttk.Label(footer, textvariable=self.progress_text).grid(
            row=0, column=1, sticky="e", padx=10
        )
        self.progress_bar = ttk.Progressbar(
            footer, maximum=100, style="Purple.Horizontal.TProgressbar"
        )
        self.progress_bar.grid(row=1, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Label(footer, textvariable=self.phase, wraplength=720).grid(
            row=2, column=0, sticky="w"
        )
        ttk.Label(footer, textvariable=self.gpu_text).grid(row=2, column=1, sticky="e")
        ttk.Label(footer, textvariable=self.status, wraplength=1000).grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(5, 0)
        )

    def make_tree(self, parent, columns, headings, widths):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        tree = ttk.Treeview(
            frame, columns=columns, show="headings", selectmode="extended"
        )
        for column, heading, width in zip(columns, headings, widths):
            tree.heading(column, text=heading)
            tree.column(column, width=width, minwidth=80)
        tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        tree.tag_configure("done", foreground="#6d28d9")
        tree.tag_configure("warning", foreground="#965500")
        tree.tag_configure("failed", foreground="#b42318")
        return tree

    def build_library(self):
        panes = ttk.Panedwindow(self.library_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        audio_panel, output_panel = ttk.Frame(panes, padding=6), ttk.Frame(
            panes, padding=6
        )
        panes.add(audio_panel, weight=1)
        panes.add(output_panel, weight=1)
        ttk.Label(
            audio_panel, text='Audio library', font=("Segoe UI Semibold", 12)
        ).pack(anchor="w")
        ttk.Label(
            audio_panel,
            text='Double-click to enqueue. You can drag files into the window.',
            wraplength=460,
        ).pack(anchor="w", pady=(5, 10))
        self.audio_tree = self.make_tree(
            audio_panel, ("name", "status"), ("File", 'Transcription'), (290, 175)
        )
        self.audio_tree.bind("<Double-1>", self.queue_selected_files)
        self.audio_tree.bind("<Button-3>", self.show_audio_menu)
        self.audio_tree.bind("<<TreeviewSelect>>", self.audio_selected)
        output_toolbar = ttk.Frame(output_panel)
        output_toolbar.pack(fill="x", pady=(0, 8))
        ttk.Button(output_toolbar, text='Up', command=self.go_up_output_dir).pack(
            side="left"
        )
        ttk.Button(
            output_toolbar, text='Open folder', command=self.open_output_folder
        ).pack(side="left", padx=8)
        ttk.Label(output_panel, textvariable=self.output_dir_text, wraplength=440).pack(
            anchor="w", pady=(0, 10)
        )
        self.output_tree = self.make_tree(
            output_panel, ("name", "type"), ("Output", 'Type'), (320, 100)
        )
        self.output_tree.bind("<Double-1>", self.open_output_entry)
        self.audio_menu = tk.Menu(self.root, tearoff=False)
        self.audio_menu.add_command(
            label='Transcribe selected', command=self.queue_selected_files
        )
        self.audio_menu.add_command(
            label='Open linked output', command=self.open_related_output
        )
        self.output_menu = tk.Menu(self.root, tearoff=False)
        self.output_menu.add_command(label='Open', command=self.open_output_entry)
        self.output_menu.add_command(
            label='Open folder', command=self.open_output_folder
        )
        self.output_tree.bind("<Button-3>", self.show_output_menu)

    def build_queue(self):
        toolbar = ttk.Frame(self.queue_tab)
        toolbar.pack(fill="x", pady=(0, 10))
        self.pause_button = ttk.Button(
            toolbar, text='Pause queue', command=self.toggle_pause
        )
        self.pause_button.pack(side="left")
        ttk.Button(
            toolbar, text='Cancel selected', command=self.cancel_selected
        ).pack(side="left", padx=8)
        ttk.Button(toolbar, text='Cancel current', command=self.cancel_current).pack(
            side="left", padx=8
        )
        ttk.Button(
            toolbar, text='Retry selected', command=self.retry_selected
        ).pack(side="left", padx=8)
        ttk.Button(toolbar, text='Clear history', command=self.clear_history).pack(
            side="left", padx=8
        )
        self.queue_tree = self.make_tree(
            self.queue_tab,
            ("name", "preset", "status", "message"),
            ("File", "Preset", 'Status', 'Details'),
            (260, 90, 120, 480),
        )
        self.queue_tree.bind("<Double-1>", self.open_job_output)

    def build_settings(self):
        self.settings_tab.columnconfigure(1, weight=1)
        choices = [
            ("Preset", self.preset, ("speed", "balanced", "max")),
            (
                'Spoken language',
                self.language,
                ("auto", "it", "en", "fr", "de", "es", "pt", "ja", "zh", "ar", "ru"),
            ),
            ('Processing', self.device, ("auto", "cuda", "cpu")),
            ('Task', self.task, ("transcribe", "translate")),
            (
                'Model',
                self.model,
                (
                    "auto",
                    "tiny",
                    "base",
                    "small",
                    "medium",
                    "large-v3-turbo",
                    "large-v3",
                    "distil-large-v3",
                    "distil-large-v3.5",
                ),
            ),
        ]
        for row, (label, variable, values) in enumerate(choices):
            ttk.Label(self.settings_tab, text=label).grid(
                row=row, column=0, sticky="w", padx=(0, 20), pady=6
            )
            combo = ttk.Combobox(
                self.settings_tab,
                textvariable=variable,
                values=values,
                width=24,
                state=(
                    "normal" if label in {'Model', 'Spoken language'} else "readonly"
                ),
            )
            combo.grid(row=row, column=1, sticky="w", pady=6)
        ttk.Label(
            self.settings_tab,
            text='speed: small · balanced: turbo · max: medium on a 4 GB GPU.\nTranslation produces English text using a compatible multilingual model.',
            wraplength=780,
        ).grid(row=5, column=0, columnspan=2, sticky="w", pady=(12, 8))
        ttk.Checkbutton(
            self.settings_tab,
            text='Disable voice activity detection (VAD)',
            variable=self.no_vad,
        ).grid(row=6, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Checkbutton(
            self.settings_tab,
            text='Save word timings and probabilities in JSON',
            variable=self.word_timestamps,
        ).grid(row=7, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Checkbutton(
            self.settings_tab,
            text='Second audio pass on uncertain intervals (separate comparison)',
            variable=self.audio_review,
        ).grid(row=8, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Label(
            self.settings_tab, text='Context and technical terms (optional)'
        ).grid(row=9, column=0, columnspan=2, sticky="w", pady=(12, 5))
        self.prompt = tk.Text(
            self.settings_tab, height=3, wrap="word", font=("Segoe UI", 10)
        )
        self.prompt.grid(row=10, column=0, columnspan=2, sticky="ew")
        self.prompt.insert("1.0", self.settings.get("initial_prompt", ""))
        ttk.Label(
            self.settings_tab,
            text='Settings are saved and applied to new queue entries.\nModels download on first use; audio processing stays on your computer.',
            wraplength=780,
        ).grid(row=11, column=0, columnspan=2, sticky="w", pady=12)

    def selected_audio_paths(self):
        return [
            self.files[item]
            for item in self.audio_tree.selection()
            if item in self.files
        ]

    def audio_selected(self, _event=None):
        selected = self.selected_audio_paths()
        if selected:
            self.status.set(
                f"Selected {len(selected)} files · settings are in the Settings tab"
            )

    def refresh_files(self):
        selected = set(self.selected_audio_paths())
        self.audio_tree.delete(*self.audio_tree.get_children())
        self.files = {}
        for index, path in enumerate(list_audio_files()):
            item = str(index)
            self.files[item] = path
            outputs = transcript_paths(path)
            key = (
                path.stat().st_mtime_ns,
                tuple(
                    (str(p), p.stat().st_mtime_ns, p.stat().st_size)
                    for p in outputs
                    if p.is_file()
                ),
            )
            cached = self.library_cache.get(path)
            state = (
                cached[1] if cached and cached[0] == key else transcript_status(path)
            )
            self.library_cache[path] = (key, state)
            tags = (
                ("done",)
                if state == 'Transcribed'
                else (("warning",) if state != 'Not transcribed' else ())
            )
            self.audio_tree.insert(
                "",
                "end",
                iid=item,
                values=(str(path.relative_to(AUDIO_ROOT)), state),
                tags=tags,
            )
            if path in selected:
                self.audio_tree.selection_add(item)

    def refresh_output_browser(self):
        OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
        if not self.current_output_dir.is_dir():
            self.current_output_dir = OUTPUT_ROOT
        self.output_dir_text.set(
            str(self.current_output_dir.relative_to(OUTPUT_ROOT))
            if self.current_output_dir != OUTPUT_ROOT
            else 'Available transcripts'
        )
        self.output_tree.delete(*self.output_tree.get_children())
        self.output_entries = {}
        entries = sorted(
            (
                p
                for p in self.current_output_dir.iterdir()
                if not p.name.startswith(".")
            ),
            key=lambda p: (not p.is_dir(), p.name.casefold()),
        )
        for index, entry in enumerate(entries):
            item = str(index)
            self.output_entries[item] = entry
            self.output_tree.insert(
                "",
                "end",
                iid=item,
                values=(
                    entry.name,
                    'Folder' if entry.is_dir() else entry.suffix.lstrip(".").upper(),
                ),
            )

    def refresh_library_views(self):
        self.refresh_files()
        self.refresh_output_browser()

    def queue_selected_files(self, _event=None):
        paths = self.selected_audio_paths()
        if not paths:
            self.status.set('Select at least one file in the library.')
            return
        self.enqueue_files(paths)

    def enqueue_files(self, paths, options=None):
        options = options or self.options()
        added = self.controller.enqueue(paths, options)
        self.save_settings()
        self.status.set(
            f"Added {added} files to the queue."
            if added
            else 'These files are already queued or being processed.'
        )
        self.refresh_queue()

    def upload_files(self):
        chosen = filedialog.askopenfilenames(
            title='Import audio/video',
            filetypes=[
                ('Audio and video', " ".join("*" + ext for ext in KNOWN_EXTENSIONS)),
                ('All files', "*.*"),
            ],
        )
        if chosen:
            self.import_files([Path(p) for p in chosen])

    def import_files(self, paths):
        if self.import_thread and self.import_thread.is_alive():
            self.status.set('An import is already running. Wait for it to finish.')
            return
        options = self.options()
        self.import_button.state(["disabled"])
        self.status.set(f"Importing {len(paths)} files…")

        def worker():
            copied, errors = [], []
            for path in paths:
                if self.import_cancel.is_set():
                    break
                try:
                    copied.append(safe_copy_to_audio(path, self.import_cancel))
                except (OSError, ValueError) as exc:
                    errors.append(str(exc))
                    LOGGER.exception("Import failed")
            self.background_events.put(
                ("import_done", {"paths": copied, "errors": errors, "options": options})
            )

        self.import_thread = threading.Thread(
            target=worker, name="whisper-import", daemon=True
        )
        self.import_thread.start()

    def install_file_drop(self):
        if os.name != "nt":
            return
        try:
            self.root.update_idletasks()
            user32, shell32 = ctypes.windll.user32, ctypes.windll.shell32
            user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
            user32.GetAncestor.restype = wintypes.HWND
            hwnd = user32.GetAncestor(self.root.winfo_id(), 2)
            self._drop_hwnd = hwnd
            lresult, wparam, lparam = (
                ctypes.c_ssize_t,
                ctypes.c_size_t,
                ctypes.c_ssize_t,
            )
            callback_type = ctypes.WINFUNCTYPE(
                lresult, wintypes.HWND, wintypes.UINT, wparam, lparam
            )
            user32.CallWindowProcW.argtypes = [
                ctypes.c_void_p,
                wintypes.HWND,
                wintypes.UINT,
                wparam,
                lparam,
            ]
            user32.CallWindowProcW.restype = lresult
            user32.SetWindowLongPtrW.argtypes = [
                wintypes.HWND,
                ctypes.c_int,
                ctypes.c_void_p,
            ]
            user32.SetWindowLongPtrW.restype = ctypes.c_void_p
            shell32.DragAcceptFiles.argtypes = [wintypes.HWND, wintypes.BOOL]
            shell32.DragQueryFileW.argtypes = [
                ctypes.c_void_p,
                wintypes.UINT,
                wintypes.LPWSTR,
                wintypes.UINT,
            ]
            shell32.DragQueryFileW.restype = wintypes.UINT
            shell32.DragFinish.argtypes = [ctypes.c_void_p]
            shell32.DragFinish.restype = None

            def window_proc(hwnd, message, wp, lp):
                if message == 0x0233:
                    paths = []
                    try:
                        count = shell32.DragQueryFileW(wp, 0xFFFFFFFF, None, 0)
                        for index in range(count):
                            length = shell32.DragQueryFileW(wp, index, None, 0)
                            buffer = ctypes.create_unicode_buffer(length + 1)
                            shell32.DragQueryFileW(wp, index, buffer, length + 1)
                            path = Path(buffer.value)
                            if (
                                path.is_file()
                                and path.suffix.lower() in KNOWN_EXTENSIONS
                            ):
                                paths.append(path)
                    finally:
                        shell32.DragFinish(wp)
                    if paths and not self.closing:
                        self.root.after_idle(lambda: self.import_files(paths))
                    return 0
                return user32.CallWindowProcW(self._old_wndproc, hwnd, message, wp, lp)

            self._window_proc = callback_type(window_proc)
            self._old_wndproc = user32.SetWindowLongPtrW(hwnd, -4, self._window_proc)
            if not self._old_wndproc:
                raise OSError('Could not install the drag-and-drop handler')
            shell32.DragAcceptFiles(hwnd, True)
        except Exception:
            LOGGER.exception("Drag-and-drop unavailable")

    def show_audio_menu(self, event):
        item = self.audio_tree.identify_row(event.y)
        if item:
            if item not in self.audio_tree.selection():
                self.audio_tree.selection_set(item)
            try:
                self.audio_menu.tk_popup(event.x_root, event.y_root)
            finally:
                self.audio_menu.grab_release()

    def show_output_menu(self, event):
        item = self.output_tree.identify_row(event.y)
        if item:
            self.output_tree.selection_set(item)
            try:
                self.output_menu.tk_popup(event.x_root, event.y_root)
            finally:
                self.output_menu.grab_release()

    def open_path(self, path):
        try:
            if os.name == "nt":
                os.startfile(path)
            else:
                subprocess.Popen(
                    ["open" if sys.platform == "darwin" else "xdg-open", str(path)]
                )
        except OSError as exc:
            self.status.set(f"Could not open: {exc}")

    def open_related_output(self):
        selected = self.selected_audio_paths()
        if selected:
            paths = [p for p in transcript_paths(selected[0]) if p.exists()]
            if paths:
                self.current_output_dir = paths[0].parent
                self.refresh_output_browser()

    def go_up_output_dir(self):
        if self.current_output_dir != OUTPUT_ROOT:
            self.current_output_dir = self.current_output_dir.parent
            self.refresh_output_browser()

    def open_output_entry(self, _event=None):
        selected = self.output_tree.selection()
        if selected:
            path = self.output_entries.get(selected[0])
            if path and path.is_dir():
                self.current_output_dir = path
                self.refresh_output_browser()
            elif path:
                self.open_path(path)

    def open_output_folder(self):
        self.open_path(self.current_output_dir)

    def open_job_output(self, _event=None):
        selected = set(self.queue_tree.selection())
        for job in self.controller.snapshot()["jobs"]:
            if job["id"] in selected and job.get("output_dir"):
                self.open_path(Path(job["output_dir"]))
                return

    def toggle_pause(self):
        self.controller.set_paused(not self.controller.snapshot()["paused"])
        self.refresh_queue()

    def cancel_selected(self):
        self.controller.cancel(list(self.queue_tree.selection()))
        self.refresh_queue()

    def cancel_current(self):
        active = self.controller.snapshot()["active_id"]
        if active:
            self.controller.cancel([active])
            self.status.set(
                'Cancellation requested; waiting for the current processing stage to finish.'
            )
            self.refresh_queue()

    def retry_selected(self):
        self.controller.retry(list(self.queue_tree.selection()))
        self.refresh_queue()

    def clear_history(self):
        self.controller.clear_history()
        self.refresh_queue()

    def refresh_queue(self):
        snapshot = self.controller.snapshot()
        if snapshot == self.last_queue_view:
            return
        self.last_queue_view = snapshot
        selected = set(self.queue_tree.selection())
        self.queue_tree.delete(*self.queue_tree.get_children())
        for job in snapshot["jobs"]:
            tag = (
                "failed"
                if job["status"] == "failed"
                else (
                    "warning"
                    if job["status"] == "warning"
                    else "done" if job["status"] == "done" else ""
                )
            )
            self.queue_tree.insert(
                "",
                "end",
                iid=job["id"],
                values=(
                    Path(job["path"]).name,
                    job["options"].get("preset", "balanced"),
                    STATUS_LABELS.get(job["status"], job["status"]),
                    job.get("message", ""),
                ),
                tags=(tag,) if tag else (),
            )
            if job["id"] in selected:
                self.queue_tree.selection_add(job["id"])
        count = sum(job["status"] == "queued" for job in snapshot["jobs"])
        self.queue_text.set(
            f"{count} waiting · {'1 active' if snapshot['active_id'] else 'none active'}"
        )
        self.pause_button.configure(
            text='Resume queue' if snapshot["paused"] else 'Pause queue'
        )

    def schedule_gpu_poll(self):
        if self.closing:
            return
        active = self.controller.snapshot()["active_id"]
        if active and not self.gpu_poll_running:
            self.gpu_poll_running = True

            def worker():
                try:
                    result = subprocess.run(
                        [
                            "nvidia-smi",
                            "--query-gpu=utilization.gpu,memory.used,memory.total",
                            "--format=csv,noheader,nounits",
                        ],
                        capture_output=True,
                        text=True,
                        check=True,
                        timeout=3,
                        **hidden_process_options(),
                    )
                    utilization, used, total = [
                        p.strip()
                        for p in result.stdout.strip().splitlines()[0].split(",")
                    ]
                    text = f"GPU {utilization}% · VRAM {used}/{total} MB"
                except (OSError, ValueError, IndexError, subprocess.SubprocessError):
                    text = 'GPU monitor unavailable'
                self.background_events.put(("gpu", {"id": active, "text": text}))

            threading.Thread(
                target=worker, name="whisper-gpu-monitor", daemon=True
            ).start()
        elif not active:
            self.gpu_text.set('GPU idle')
        self.root.after(1500, self.schedule_gpu_poll)

    def poll_events(self):
        if self.closing:
            return
        for event_queue in (self.controller.events, self.background_events):
            for _ in range(200):
                try:
                    event_type, payload = event_queue.get_nowait()
                except queue.Empty:
                    break
                self.handle_event(event_type, payload)
        self.refresh_queue()
        self.root.after(100, self.poll_events)

    def handle_event(self, event_type, payload):
        if event_type == "import_done":
            self.import_button.state(["!disabled"])
            self.refresh_files()
            if payload["paths"]:
                self.enqueue_files(payload["paths"], payload["options"])
            if payload["errors"]:
                self.status.set('Import: ' + "; ".join(payload["errors"]))
            return
        if event_type == "gpu":
            self.gpu_poll_running = False
            if payload["id"] == self.controller.snapshot()["active_id"]:
                self.gpu_text.set(payload["text"])
            return
        if event_type == "queue_error":
            self.status.set(payload["message"])
            return
        if event_type == "job_started":
            self.display_job_id = payload["id"]
            self.current_file.set(Path(payload["path"]).name)
            self.progress_bar["value"] = 0
            self.progress_text.set("0%")
            self.phase.set('Preparation')
            return
        if payload.get("id") != self.display_job_id:
            return
        if event_type == "phase":
            self.phase.set(payload["message"])
        elif event_type == "config":
            config = payload["config"]
            self.status.set(
                f"{config['model']} · {config['device']} · language {config['language'] or 'auto'}"
            )
        elif event_type == "progress":
            percent = max(
                float(self.progress_bar["value"]), min(100, payload["percent"])
            )
            self.progress_bar["value"] = percent
            self.progress_text.set(f"{percent:.0f}%")
        elif event_type == "job_finished":
            self.phase.set(STATUS_LABELS.get(payload["status"], payload["status"]))
            self.status.set(payload["message"])
            if payload["status"] in {"done", "warning"}:
                self.refresh_library_views()
            self.display_job_id = None

    def report_callback_exception(self, exc_type, exc_value, exc_traceback):
        LOGGER.error("Interface error", exc_info=(exc_type, exc_value, exc_traceback))
        self.status.set(f"Error: {exc_value}. Details in .logs/whisper-studio.log")

    def close(self):
        if self.closing:
            return
        try:
            self.save_settings()
        except OSError:
            LOGGER.exception("Could not save settings on close")
        self.closing = True
        self.import_cancel.set()
        self.controller.shutdown()
        if self._old_wndproc and self._drop_hwnd:
            ctypes.windll.shell32.DragAcceptFiles(self._drop_hwnd, False)
            ctypes.windll.user32.SetWindowLongPtrW(
                self._drop_hwnd, -4, self._old_wndproc
            )
        self._window_proc = None
        self.root.report_callback_exception = lambda *_args: None
        self.root.destroy()
        # Dispose Tk variables on the UI thread, before any worker can collect
        # abandoned interface cycles (PyAV also invokes the garbage collector).
        for name, value in list(vars(self).items()):
            if isinstance(value, tk.Variable):
                setattr(self, name, None)


def main():
    app = None
    try:
        setup_logging()
        if STARTUP_IMPORT_ERROR is not None:
            raise STARTUP_IMPORT_ERROR
        root = tk.Tk()
        if "--transcription-only" in sys.argv:
            app = App(root)
        else:
            from lecture_ui import LectureApp
            app = LectureApp(root)
        root.mainloop()
    except Exception as exc:
        details = traceback.format_exc()
        try:
            (PROJECT_ROOT / "open-audio-selector-error.log").write_text(
                details, encoding="utf-8"
            )
            LOGGER.exception("Startup failed")
        except OSError:
            pass
        show_startup_error(
            f"Cannot start Whisper Studio.\nRun the installation wizard and check open-audio-selector-error.log.\n\n{exc}"
        )
    finally:
        if app is not None:
            app.controller.shutdown()
            # The window closes immediately; wait for cooperative cancellation
            # before letting Python tear down CUDA and its worker thread.
            if app.controller.thread is not None:
                app.controller.thread.join()


if __name__ == "__main__":
    main()
