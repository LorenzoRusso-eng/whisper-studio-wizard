"""Portable installation backend; uses only the Python standard library."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import urllib.request
import zipfile
from pathlib import Path

from studio_runtime import (ROOT, PROVIDERS, configure_tools_path, hidden_process_options,
                            save_installation, venv_python)

PYTHON_HELP = 'https://www.python.org/downloads/'


class InstallationCancelled(Exception):
    pass


def check_python():
    if not ((3, 11) <= sys.version_info[:2] <= (3, 13) and sys.maxsize > 2**32):
        raise RuntimeError('64-bit Python 3.11, 3.12, or 3.13 is required. ' + PYTHON_HELP)


def validate_transcript_file(source):
    path=Path(source).expanduser()
    if not path.is_file() or path.suffix.lower() not in {'.txt','.md','.srt','.json'}:
        raise ValueError('Choose an existing TXT, MD, SRT, or JSON transcript.')
    try:
        text=path.read_text(encoding='utf-8-sig')
        if not text.strip():raise ValueError('The transcript is empty.')
        if path.suffix.lower()=='.json':
            item=json.loads(text)
            segments=item.get('segments') if isinstance(item,dict) else None
            if not isinstance(segments,list) or not segments or not all(isinstance(s,dict) and isinstance(s.get('text'),str) for s in segments) or not any(s['text'].strip() for s in segments):
                raise ValueError('The JSON must contain segments: a list of objects with nonempty text.')
        if path.suffix.lower()=='.srt' and not re.search(r'\d+:\d+:\d+[,.]\d+\s*-->\s*\d+:\d+:\d+[,.]\d+',text):
            raise ValueError('The SRT file does not contain recognizable timestamps.')
    except UnicodeError as exc:
        raise ValueError('Export the transcript as UTF-8 and try again.') from exc
    return str(path.resolve())


def check_cancel(cancel):
    if cancel.is_set():
        raise InstallationCancelled('Installation canceled. Reopen the wizard to try again.')


def run_checked(command, log, cancel, *, cwd=ROOT):
    check_cancel(cancel)
    log('> ' + subprocess.list2cmdline([str(x) for x in command]))
    options=hidden_process_options()
    if os.name != 'nt':options['start_new_session']=True
    process = subprocess.Popen(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding='utf-8', errors='replace', **options)
    lines=[]
    def reader():
        for line in process.stdout:
            lines.append(line); log(line.rstrip())
    worker=threading.Thread(target=reader,daemon=True);worker.start()
    try:
        while process.poll() is None:
            if cancel.wait(.2):
                if os.name=='nt':
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,
                                   timeout=15,**hidden_process_options())
                else:
                    import signal
                    os.killpg(process.pid,signal.SIGTERM)
                try:process.wait(timeout=5)
                except subprocess.TimeoutExpired:process.kill()
                raise InstallationCancelled('Installation canceled; reopen the wizard to try again.')
        worker.join(5)
        if process.returncode:
            raise RuntimeError(f'Command failed with exit code {process.returncode}: '+''.join(lines)[-2000:])
    finally:
        if process.poll() is None:process.kill();process.wait(timeout=10)
        worker.join(3);process.stdout.close()


def fetch(url, destination, log, cancel, *, limit=150_000_000):
    log('Download da ' + url)
    with urllib.request.urlopen(url, timeout=30) as response, Path(destination).open('wb') as target:
        size=0
        while True:
            check_cancel(cancel)
            chunk=response.read(512*1024)
            if not chunk:break
            size+=len(chunk)
            if size>limit:raise RuntimeError('The download exceeds the expected size')
            target.write(chunk)


def install_node(log, cancel):
    """Install the official Node 24 LTS distribution locally; verify its published SHA-256."""
    machine=platform.machine().lower()
    arch={'amd64':'x64','x86_64':'x64','arm64':'arm64','aarch64':'arm64'}.get(machine)
    system={'Windows':'win','Darwin':'darwin','Linux':'linux'}.get(platform.system())
    if not arch or not system:raise RuntimeError('Unrecognized Node architecture: install Node.js 22+ from https://nodejs.org/')
    suffix=f'{system}-{arch}.'+('zip' if system=='win' else 'tar.xz')
    runtime=ROOT/'.tools/runtime';runtime.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.node-download-',dir=runtime) as temporary:
        temporary=Path(temporary);checksums=temporary/'SHASUMS256.txt'
        base='https://nodejs.org/dist/latest-v24.x/'
        fetch(base+'SHASUMS256.txt',checksums,log,cancel,limit=1_000_000)
        entries=[line.split() for line in checksums.read_text(encoding='utf-8').splitlines() if line.endswith(suffix)]
        if len(entries)!=1:raise RuntimeError('Node.js LTS distribution not found')
        expected,filename=entries[0]
        if Path(filename).name!=filename or not filename.startswith('node-v24.'):
            raise RuntimeError('Invalid Node download filename')
        archive=temporary/filename;fetch(base+filename,archive,log,cancel)
        with archive.open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if actual!=expected:
            raise RuntimeError('Node.js checksum mismatch: download rejected')
        extracted=temporary/'unpacked';extracted.mkdir()
        def target(name):
            path=(extracted/name).resolve()
            if not path.is_relative_to(extracted.resolve()):raise RuntimeError('Invalid path in the Node archive')
            return path
        if system=='win':
            with zipfile.ZipFile(archive) as packed:
                for entry in packed.infolist():
                    check_cancel(cancel);path=target(entry.filename)
                    if entry.is_dir():path.mkdir(parents=True,exist_ok=True)
                    else:
                        path.parent.mkdir(parents=True,exist_ok=True)
                        with packed.open(entry) as source,path.open('wb') as output:shutil.copyfileobj(source,output)
        else:
            with tarfile.open(archive) as packed:
                for entry in packed:
                    check_cancel(cancel);path=target(entry.name)
                    if entry.isdir():path.mkdir(parents=True,exist_ok=True)
                    elif entry.isfile():
                        path.parent.mkdir(parents=True,exist_ok=True)
                        with packed.extractfile(entry) as source,path.open('wb') as output:shutil.copyfileobj(source,output)
                        path.chmod(entry.mode & 0o777)
                    # npm is invoked through its JS entry point; archive symlinks aren't needed.
        folder=next(extracted.iterdir());destination=runtime/folder.name
        if destination.exists():
            raise RuntimeError('A Node runtime is already present but cannot start. Check .tools/runtime or install Node.js from the official website.')
        folder.rename(destination)
    configure_tools_path()
    log('Node.js LTS verified and installed in the application folder.')


def npm_command():
    node=shutil.which('node')
    if not node:return None
    node=Path(node).resolve()
    for candidate in [node.parent/'node_modules/npm/bin/npm-cli.js',node.parent.parent/'lib/node_modules/npm/bin/npm-cli.js']:
        if candidate.is_file():return [str(node),str(candidate)]
    npm=shutil.which('npm.cmd' if os.name=='nt' else 'npm')
    if npm:
        path=Path(npm)
        if os.name!='nt':return [str(path)]
        candidate=path.parent/'node_modules/npm/bin/npm-cli.js'
        if candidate.is_file():return [str(node),str(candidate)]
    return None


def ensure_cli(provider, log, cancel):
    import ai_providers
    try:
        executable=ai_providers.locate(provider)
        command=ai_providers.executable_command(executable,provider)
        run_checked(command+['--version'],log,cancel)
        log(PROVIDERS[provider]['name']+' is already available; reusing the existing installation.')
        return
    except (OSError,RuntimeError):
        pass
    command=npm_command()
    node=shutil.which('node')
    version=subprocess.run([node,'--version'],capture_output=True,text=True,timeout=10,**hidden_process_options()) if node else None
    if not command or not version or version.returncode or int(version.stdout.strip().lstrip('v').split('.')[0])<22:
        install_node(log,cancel);command=npm_command()
    if not command:raise RuntimeError('npm is unavailable; install Node.js from https://nodejs.org/')
    run_checked(command+['install','--global','--prefix',str(ROOT/'.tools'),PROVIDERS[provider]['package']+'@latest'],log,cancel)
    configure_tools_path()
    executable=ai_providers.locate(provider)
    run_checked(ai_providers.executable_command(executable,provider)+['--version'],log,cancel)


def install(config, log, progress, cancel):
    check_python()
    python=venv_python()
    progress(1,'Creating an isolated Python environment')
    if not python.is_file():run_checked([sys.executable,'-m','venv',str(ROOT/'.venv')],log,cancel)
    run_checked([str(python),'-c','import sys; assert (3,11)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32'],log,cancel)
    progress(2,'Installing the editor, PDF support, and figure tools')
    run_checked([str(python),'-m','pip','install','-r','requirements-base.txt'],log,cancel)
    if config['transcription_mode']=='whisper':
        progress(3,'Installing Whisper for local transcription')
        run_checked([str(python),'-m','pip','install','-r','requirements-whisper.txt'],log,cancel)
        if config.get('device')=='cuda':
            if sys.platform=='darwin' or platform.machine().lower() not in {'amd64','x86_64'}:
                raise RuntimeError('NVIDIA acceleration requires Windows/Linux x64. Use the CPU on this computer.')
            run_checked([str(python),'-m','pip','install','-r','requirements-nvidia.txt'],log,cancel)
    else:
        progress(3,'External transcript: skipping Whisper and the second audio pass')
        log('This mode does not download an ASR engine, NVIDIA libraries, or speech models.')
    progress(4,'Configuring '+PROVIDERS[config['ai_provider']]['name'])
    ensure_cli(config['ai_provider'],log,cancel)
    progress(5,'Checking dependencies and the interface')
    run_checked([str(python),'-m','pip','check'],log,cancel)
    code='import tkinter, lecture_pipeline, lecture_ui, pypdf, pypdfium2, PIL, resvg_py; r=tkinter.Tk(); r.withdraw(); r.destroy(); print("Editor and interface: OK")'
    if config['transcription_mode']=='whisper':code+='; import transcribe; transcribe.require_asr(); print("Whisper: OK")'
    if config.get('device')=='cuda':
        code+='; m=transcribe.ctranslate2.get_cuda_device_count(); assert m>0, "No CUDA GPU available: check the NVIDIA driver or choose CPU"'
    run_checked([str(python),'-c',code],log,cancel)
    check_cancel(cancel)
    save_installation({**config,'schema_version':1,'installed':True,'platform':platform.system(),
                       'python':platform.python_version(),'cli_authentication':'pending'})
    progress(6,'Installation complete. Sign in to your assistant or try the demo.')


def terminal_command(command, *, cwd=ROOT):
    """Launch an interactive terminal only for login / administrator package managers."""
    if os.name=='nt':
        return subprocess.Popen(command,cwd=cwd,creationflags=subprocess.CREATE_NEW_CONSOLE)
    script='cd '+shlex.quote(str(cwd))+' && '+shlex.join(command)
    if sys.platform=='darwin':
        return subprocess.Popen(['osascript','-e','tell application "Terminal" to do script '+json.dumps(script)])
    for name in ('x-terminal-emulator','gnome-terminal','konsole','xterm'):
        executable=shutil.which(name)
        if executable:
            separator=['--'] if name=='gnome-terminal' else ['-e']
            return subprocess.Popen([executable,*separator,'sh','-c',script+'; printf "\\nPress Enter to close"; read answer'])
    raise RuntimeError('No graphical terminal found. Run this in your terminal: '+shlex.join(command))


def login(provider):
    import ai_providers
    command=ai_providers.executable_command(ai_providers.locate(provider),provider)
    return terminal_command(command+PROVIDERS[provider]['login'])


def pdf_install_command():
    if os.name=='nt':
        if shutil.which('winget'):return ['winget','install','--id','MiKTeX.MiKTeX','--exact','--interactive']
    elif sys.platform=='darwin':
        if shutil.which('brew'):return ['brew','install','--cask','mactex-no-gui']
    else:
        if shutil.which('apt-get'):return ['sudo','apt-get','install','texlive-latex-extra','texlive-fonts-recommended','texlive-science','latexmk']
        if shutil.which('dnf'):return ['sudo','dnf','install','texlive-scheme-medium','latexmk']
    return None
