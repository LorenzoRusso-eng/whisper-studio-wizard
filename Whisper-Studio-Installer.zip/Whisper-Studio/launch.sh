#!/bin/sh
# Shared Unix launcher. All paths remain relative to the extracted project.
set -eu
STUDIO_ROOT=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
cd "$STUDIO_ROOT"
ACTION=${1:-app}
if [ "$#" -gt 0 ]; then shift; fi

find_python() {
    for candidate in "$STUDIO_ROOT/.venv/bin/python" python3.13 python3.12 python3.11 \
        /opt/homebrew/opt/python@3.13/bin/python3.13 /usr/local/opt/python@3.13/bin/python3.13 python3; do
        if "$candidate" -c 'import sys; sys.exit(0 if (3,11)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32 else 1)' >/dev/null 2>&1; then
            STUDIO_PYTHON=$candidate
            return 0
        fi
    done
    return 1
}

if ! find_python; then
    printf '%s\n' '64-bit Python 3.11, 3.12, or 3.13 with Tcl/Tk and venv is required.'
    if [ "$(uname -s)" = Darwin ] && command -v brew >/dev/null 2>&1; then
        printf 'Install Python 3.13 and Tk with Homebrew? [y/N]: '
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then brew install python@3.13 python-tk@3.13; fi
    elif command -v apt-get >/dev/null 2>&1; then
        printf 'Install Python, Tk, and venv from the system repositories? [y/N]: '
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then sudo apt-get update; sudo apt-get install python3 python3-tk python3-venv; fi
    elif command -v dnf >/dev/null 2>&1; then
        printf 'Install Python and Tk from the system repositories? [y/N]: '
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then sudo dnf install python3 python3-tkinter; fi
    fi
    if ! find_python; then
        printf '%s\n' 'Install Python 3.11–3.13 from https://www.python.org/downloads/ and try again.' \
            'If your distribution provides an older Python, install a separate Python 3.11–3.13 version.'
        exit 1
    fi
fi

if ! "$STUDIO_PYTHON" -c 'import tkinter, venv, ensurepip' >/dev/null 2>&1; then
    printf '%s\n' 'This Python installation is missing Tcl/Tk or the virtual environment modules.'
    if [ "$(uname -s)" = Darwin ] && command -v brew >/dev/null 2>&1; then
        STUDIO_PY_VERSION=$("$STUDIO_PYTHON" -c 'import sys; print("%s.%s" % sys.version_info[:2])')
        printf 'Install Tk support for Python %s with Homebrew? [y/N]: ' "$STUDIO_PY_VERSION"
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then brew install "python-tk@$STUDIO_PY_VERSION"; fi
    elif command -v apt-get >/dev/null 2>&1; then
        printf 'Install Tk and venv from the system repositories? [y/N]: '
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then sudo apt-get install python3-tk python3-venv; fi
    elif command -v dnf >/dev/null 2>&1; then
        printf 'Install Tk and pip from the system repositories? [y/N]: '
        read -r answer
        if [ "$answer" = y ] || [ "$answer" = Y ]; then sudo dnf install python3-tkinter python3-pip; fi
    fi
    if ! "$STUDIO_PYTHON" -c 'import tkinter, venv, ensurepip' >/dev/null 2>&1; then
        printf '%s\n' 'Tk and venv must match your Python version.' \
            'See QUICKSTART.md or use the complete Python installer from python.org.'
        exit 1
    fi
fi

case "$ACTION" in
    setup) TARGET=setup_wizard.py ;;
    demo) TARGET=studio_demo.py ;;
    app) TARGET=studio.py ;;
    *) printf '%s\n' 'Usage: sh launch.sh setup|app|demo [options]'; exit 2 ;;
esac
if [ "$ACTION" != setup ] && [ ! -f "$STUDIO_ROOT/.venv/bin/python" ]; then TARGET=setup_wizard.py; fi
exec "$STUDIO_PYTHON" "$STUDIO_ROOT/$TARGET" "$@"
