#!/bin/sh
# Shared Unix launcher. All paths remain relative to the extracted project.
set -eu
STUDIO_ROOT=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
cd "$STUDIO_ROOT"
ACTION=${1:-app}
if [ "$#" -gt 0 ]; then shift; fi

find_python() {
    for candidate in "$STUDIO_ROOT/.venv/bin/python" python3.13 python3.12 python3.11 \
        /opt/homebrew/opt/python@3.13/bin/python3.13 /usr/local/opt/python@3.13/bin/python3.13 python3; do
        if "$candidate" -c 'import sys; sys.exit(0 if (3,11)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32 else 1)' >/dev/null 2>&1; then
            STUDIO_PYTHON=$candidate
            return 0
        fi
    done
    return 1
}

if ! find_python; then
    printf '%s\n' 'Serve Python 3.11, 3.12 o 3.13 a 64 bit con Tcl/Tk e venv.'
    if [ "$(uname -s)" = Darwin ] && command -v brew >/dev/null 2>&1; then
        printf 'Installare Python 3.13 e Tk con Homebrew? [s/N]: '
        read -r answer
        if [ "$answer" = s ]; then brew install python@3.13 python-tk@3.13; fi
    elif command -v apt-get >/dev/null 2>&1; then
        printf 'Installare Python, Tk e venv dai repository del sistema? [s/N]: '
        read -r answer
        if [ "$answer" = s ]; then sudo apt-get update; sudo apt-get install python3 python3-tk python3-venv; fi
    elif command -v dnf >/dev/null 2>&1; then
        printf 'Installare Python e Tk dai repository del sistema? [s/N]: '
        read -r answer
        if [ "$answer" = s ]; then sudo dnf install python3 python3-tkinter; fi
    fi
    if ! find_python; then
        printf '%s\n' 'Installa Python 3.11–3.13 da https://www.python.org/downloads/ e riprova.' \
            'Se la tua distribuzione offre un Python più vecchio, serve una versione 3.11–3.13 separata.'
        exit 1
    fi
fi

if ! "$STUDIO_PYTHON" -c 'import tkinter, venv, ensurepip' >/dev/null 2>&1; then
    printf '%s\n' 'A Python mancano Tcl/Tk o i moduli per creare il virtualenv.'
    if [ "$(uname -s)" = Darwin ] && command -v brew >/dev/null 2>&1; then
        STUDIO_PY_VERSION=$("$STUDIO_PYTHON" -c 'import sys; print("%s.%s" % sys.version_info[:2])')
        printf 'Installare il supporto Tk per Python %s con Homebrew? [s/N]: ' "$STUDIO_PY_VERSION"
        read -r answer
        if [ "$answer" = s ]; then brew install "python-tk@$STUDIO_PY_VERSION"; fi
    elif command -v apt-get >/dev/null 2>&1; then
        printf 'Installare Tk e venv dai repository del sistema? [s/N]: '
        read -r answer
        if [ "$answer" = s ]; then sudo apt-get install python3-tk python3-venv; fi
    elif command -v dnf >/dev/null 2>&1; then
        printf 'Installare Tk e pip dai repository del sistema? [s/N]: '
        read -r answer
        if [ "$answer" = s ]; then sudo dnf install python3-tkinter python3-pip; fi
    fi
    if ! "$STUDIO_PYTHON" -c 'import tkinter, venv, ensurepip' >/dev/null 2>&1; then
        printf '%s\n' 'Tk e venv devono corrispondere alla stessa versione di Python.' \
            'Consulta INIZIA-QUI.md oppure usa Python completo da python.org.'
        exit 1
    fi
fi

case "$ACTION" in
    setup) TARGET=setup_wizard.py ;;
    demo) TARGET=studio_demo.py ;;
    app) TARGET=studio.py ;;
    *) printf '%s\n' 'Uso: sh launch.sh setup|app|demo [opzioni]'; exit 2 ;;
esac
if [ "$ACTION" != setup ] && [ ! -f "$STUDIO_ROOT/.venv/bin/python" ]; then TARGET=setup_wizard.py; fi
exec "$STUDIO_PYTHON" "$STUDIO_ROOT/$TARGET" "$@"
