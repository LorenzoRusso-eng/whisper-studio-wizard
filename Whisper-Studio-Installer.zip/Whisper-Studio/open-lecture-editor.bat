@echo off
setlocal
set "STUDIO_DIR=%~dp0"
if not exist "%STUDIO_DIR%.venv\Scripts\pythonw.exe" (
  echo Run Install-Windows.bat first to create the Python environment.
  pause
  exit /b 1
)
start "" "%STUDIO_DIR%.venv\Scripts\pythonw.exe" "%STUDIO_DIR%review_editor.py" open %*
endlocal
