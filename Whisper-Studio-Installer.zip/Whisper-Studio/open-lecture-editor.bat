@echo off
setlocal
set "STUDIO_DIR=%~dp0"
if not exist "%STUDIO_DIR%.venv\Scripts\pythonw.exe" (
  echo Esegui prima setup.ps1 per creare l'ambiente Python.
  pause
  exit /b 1
)
start "" "%STUDIO_DIR%.venv\Scripts\pythonw.exe" "%STUDIO_DIR%review_editor.py" open %*
endlocal
