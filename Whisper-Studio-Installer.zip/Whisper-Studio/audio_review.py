"""A second, targeted ASR pass. Proposals never overwrite the source transcript."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import math
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

import transcribe as engine
from faster_whisper.audio import decode_audio


def alternate_model(first_model: str, language: str = "en", device: str = "cuda",
                    task: str = "transcribe") -> str:
    if device == "cpu":
        return first_model
    return ("distil-large-v3.5" if first_model == "large-v3" and language == "en"
            and task == "transcribe" else "large-v3")


def normalized_words(text: str) -> list[str]:
    return re.findall(r"[\w]+(?:['’-][\w]+)*", text.casefold())


def plan_review(payload: dict, requested: list[dict] | None = None,
                max_ratio: float = 0.35) -> dict:
    """Prioritize explicit issues; bound automatic work without discarding repeats."""
    duration = float(payload["duration_seconds"])
    if not math.isfinite(duration) or duration <= 0 or not 0 < max_ratio <= 1:
        raise ValueError('Invalid duration or second-pass limit')
    candidates = []

    def add(start, end, reason, issue=None, manual=False):
        start, end = float(start), float(end)
        if not math.isfinite(start + end) or end <= start:
            raise ValueError('Invalid review interval')
        start, end = max(0, start - 4), min(duration, end + 4)
        if end <= start:
            return
        if end - start < 12:
            middle = (start + end) / 2
            start, end = max(0, middle - 6), min(duration, middle + 6)
        candidates.append(dict(start=start, end=end, reason=reason,
                               issue=issue, manual=manual))

    for item in requested or []:
        add(item["start"], item["end"], item.get("reason", "Passaggio segnalato"),
            item.get("id"), True)
    segments = sorted(payload.get("segments", []), key=lambda s: s["start"])
    for i, segment in enumerate(segments):
        reasons = []
        if (segment.get("avg_logprob") or 0) < -1:
            reasons.append("Bassa confidenza ASR")
        if (segment.get("no_speech_prob") or 0) > 0.6:
            reasons.append("Uncertain speech")
        if (segment.get("compression_ratio") or 0) > 2.4:
            reasons.append('Possible ASR repetition (review needed)')
        words = normalized_words(segment.get("text", ""))
        if len(words) >= 15 and max(Counter(tuple(words[j:j+4]) for j in range(len(words)-3)).values(), default=0) >= 3:
            reasons.append("Sequenza ripetuta: conservata e segnalata")
        if reasons:
            add(segment["start"], segment["end"], "; ".join(reasons), f"S{i:04d}")
    previous = 0.0
    for segment in segments:
        if segment["start"] - previous >= 20:
            add(previous, segment["start"], 'Interval without text: this does not prove speech was omitted')
        previous = max(previous, segment["end"])
    if duration - previous >= 20:
        add(previous, duration, 'Recording tail without text')

    merged = []
    for item in sorted(candidates, key=lambda x: x["start"]):
        if merged and item["start"] <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], item["end"])
        else:
            merged.append([item["start"], item["end"]])
    windows = []
    for start, end in merged:
        cursor = start
        while cursor < end:
            finish = min(cursor + 30, end)
            if end - finish < 6:
                finish = end
            causes = [c for c in candidates if c["start"] < finish and c["end"] > cursor]
            windows.append(dict(start=round(cursor, 3), end=round(finish, 3),
                reasons=sorted({c["reason"] for c in causes}),
                issue_ids=sorted({c["issue"] for c in causes if c["issue"]}),
                manual=any(c["manual"] for c in causes)))
            if finish >= end:
                break
            cursor = finish - 4
    selected, deferred, spent = [], [], 0.0
    for window in sorted(windows, key=lambda w: (not w["manual"], w["start"])):
        cost = window["end"] - window["start"]
        if window["manual"] or spent + cost <= duration * max_ratio:
            selected.append(window)
            spent += cost
        else:
            remaining = duration * max_ratio - spent
            if remaining >= 6:
                finish = round(window["start"] + remaining, 3)
                selected.append({**window, "end": finish})
                deferred.append({**window, "start": finish})
                spent += finish - window["start"]
            else:
                deferred.append(window)
    selected.sort(key=lambda w: w["start"])
    for i, window in enumerate(selected, 1):
        window["id"] = f"R{i:04d}"
    return {"windows": selected, "deferred": deferred,
            "candidate_windows": len(windows), "processed_window_seconds": round(spent, 3),
            "automatic_budget_ratio": max_ratio,
            "policy": "Explicit issues are always retained; only automatic candidates are budget-limited."}


def review_transcript(payload: dict, model, *, model_name: str,
                      report_path: Path, requested: list[dict] | None = None,
                      initial_prompt: str | None = None, max_ratio: float = 0.35,
                      phase_callback=None, progress_callback=None, cancel_event=None,
                      source_path: Path | None = None, audio=None) -> dict:
    phase = phase_callback or (lambda message: None)
    input_path = Path(payload["input"])
    stat = input_path.stat()
    for key, current in (("input_size_bytes", stat.st_size), ("input_mtime_ns", stat.st_mtime_ns)):
        if key in payload and payload[key] != current:
            raise ValueError('The audio has changed since transcription: review stopped')
    language = payload.get("requested_language") or payload.get("language") or "en"
    engine.validate_model_task(model_name, language, payload.get("task", "transcribe"))
    plan = plan_review(payload, requested, max_ratio)
    report = dict(schema_version=1, completed=False, created_at=datetime.now(timezone.utc).isoformat(),
        source_transcript=str(source_path) if source_path else None, input=str(input_path),
        first_model=payload.get("model"), second_model=model_name, language=language,
        initial_prompt=initial_prompt, decoding={"beam_size": 5, "vad_filter": False,
            "condition_on_previous_text": False, "temperatures": [0, 0.2]},
        source_fingerprint=hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
        plan=plan, cases=[], interpretation="ASR comparison, not human listening or ground-truth verification. Proposals require contextual review.")
    if audio is None and plan["windows"]:
        phase("Second audio pass: decoding audio")
        audio = decode_audio(str(input_path))
    actual_duration = len(audio) / 16000 if audio is not None else float(payload["duration_seconds"])
    if abs(actual_duration - float(payload["duration_seconds"])) > 1:
        raise ValueError('Audio duration differs from the transcript duration')
    started = time.perf_counter()
    engine.write_json_output(report_path, report)
    try:
        for i, window in enumerate(plan["windows"], 1):
            engine.check_cancelled(cancel_event)
            phase(f"Second audio pass: interval {i}/{len(plan['windows'])}")
            start, end = window["start"], window["end"]
            clip = audio[int(start * 16000):int(end * 16000)]
            rms = float(np.sqrt(np.mean(clip * clip))) if len(clip) else 0.0
            original = [{"id": f"S{j:04d}", **s} for j, s in enumerate(payload["segments"])
                        if s["start"] < end and s["end"] > start]
            first_text = " ".join(s["text"].strip() for s in original)
            retry_segments = []
            if rms >= 0.0001 or window["manual"]:
                iterator, info = model.transcribe(clip, language=language,
                    task=payload.get("task", "transcribe"), beam_size=5,
                    temperature=(0.0, 0.2), vad_filter=False,
                    condition_on_previous_text=False, initial_prompt=initial_prompt,
                    word_timestamps=False, without_timestamps=False)
                for segment in iterator:
                    engine.check_cancelled(cancel_event)
                    item = {"start": round(start + segment.start, 3),
                            "end": round(min(end, start + segment.end), 3),
                            "text": segment.text.strip()}
                    for key in ("avg_logprob", "no_speech_prob", "compression_ratio"):
                        value = getattr(segment, key, None)
                        if value is not None and math.isfinite(value):
                            item[key] = value
                    retry_segments.append(item)
            second_text = " ".join(s["text"] for s in retry_segments)
            difference = 1 - difflib.SequenceMatcher(None, normalized_words(first_text), normalized_words(second_text), autojunk=False).ratio()
            report["cases"].append({**window, "first_text": first_text,
                "second_text": second_text, "second_segments": retry_segments,
                "source_segment_ids": [s["id"] for s in original], "rms": round(rms, 7),
                "difference_ratio": round(difference, 4),
                "status": "proposal" if difference > 0.12 or not second_text else "similar",
                "decision": "pending", "decision_note": ""})
            engine.write_json_output(report_path, report)
            if progress_callback:
                progress_callback(i / max(1, len(plan["windows"])) * 100, end, actual_duration)
    finally:
        report["elapsed_seconds"] = round(time.perf_counter() - started, 3)
        report["completed"] = len(report["cases"]) == len(plan["windows"])
        report["summary"] = {"reviewed": len(report["cases"]),
            "different": sum(c["status"] == "proposal" for c in report["cases"]),
            "deferred": len(plan["deferred"])}
        engine.write_json_output(report_path, report)
    rows = ["# Second-pass audio review", "", report["interpretation"], ""]
    for case in report["cases"]:
        rows += [f"## {case['id']} - {case['start']:.2f}-{case['end']:.2f}s", "",
                 "Issues: " + ", ".join(case["issue_ids"]), "",
                 "**First pass:** " + case["first_text"], "",
                 "**Second pass:** " + (case["second_text"] or "[No text recognized]"), "",
                 "**Decision:** pending contextual review.", ""]
    engine.atomic_write_text(report_path.with_suffix(".md"), "\n".join(rows))
    return report


def attach_review(result: dict, acquire_model, *, device="cuda", model_name=None,
                  phase_callback=None, progress_callback=None, cancel_event=None):
    """Shared queue/CLI orchestration; acquire_model releases the previous model."""
    payload = result["payload"]
    language = payload.get("requested_language") or payload.get("language") or "en"
    name = model_name or alternate_model(payload["model"], language, device, payload.get("task", "transcribe"))
    path = engine.output_file(result["output_base"], "review.json")
    source_fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    started = time.perf_counter()
    try:
        engine.validate_model_task(name, language, payload.get("task", "transcribe"))
        reviewer = acquire_model(name) if plan_review(payload)["windows"] else None
        report = review_transcript(payload, reviewer, model_name=name,
            report_path=path, initial_prompt=payload.get("initial_prompt"),
            phase_callback=phase_callback, progress_callback=progress_callback,
            cancel_event=cancel_event)
        payload["audio_review"] = {"file": path.name, "model": name,
            "completed": report["completed"], **report["summary"]}
        if report["summary"]["different"]:
            payload["warnings"].append(f"Second audio pass: {report['summary']['different']} intervals contain differences to review; comparison saved to {path.name}.")
    except engine.TranscriptionCancelled:
        raise
    except Exception as exc:
        payload["audio_review"] = {"file": path.name, "model": name,
            "completed": False, "error": str(exc)}
        payload["warnings"].append(f"Transcript saved; second pass incomplete: {exc}")
        fingerprint = source_fingerprint
        failed = {"schema_version": 1, "first_model": payload["model"],
                  "second_model": name, "cases": [], "source_fingerprint": fingerprint}
        if path.exists():
            try:
                previous = json.loads(path.read_text(encoding="utf-8"))
                if previous.get("source_fingerprint") == fingerprint:
                    failed = previous
            except (ValueError, OSError):
                pass
        failed.update(completed=False, error=str(exc))
        engine.write_json_output(path, failed)
    payload["first_pass_elapsed_seconds"] = payload["elapsed_seconds"]
    payload["elapsed_seconds"] += time.perf_counter() - started
    result["elapsed_seconds"], result["warnings"] = payload["elapsed_seconds"], payload["warnings"]
    if "json" in payload.get("formats", []):
        engine.write_json_output(engine.output_file(result["output_base"], "json"), payload)
    return result


def main():
    parser = argparse.ArgumentParser(description='Targeted second audio pass that preserves the original transcript.')
    parser.add_argument("transcript", type=Path)
    parser.add_argument("--model")
    parser.add_argument("--device", default="cuda", choices=("cuda", "cpu"))
    parser.add_argument("--issues", type=Path)
    parser.add_argument("--prompt-file", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-ratio", type=float, default=0.35)
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    payload = json.loads(args.transcript.read_text(encoding="utf-8-sig"))
    issues = json.loads(args.issues.read_text(encoding="utf-8")) if args.issues else []
    if args.plan_only:
        print(json.dumps(plan_review(payload, issues, args.max_ratio), ensure_ascii=False, indent=2))
        return
    name = args.model or alternate_model(payload.get("model", ""), payload.get("language", "en"),
                                         args.device, payload.get("task", "transcribe"))
    model = (engine.create_model(name, args.device, engine.normalize_compute_type(args.device))
             if plan_review(payload, issues, args.max_ratio)["windows"] else None)
    try:
        result = review_transcript(payload, model, model_name=name,
            report_path=args.output or args.transcript.with_suffix(".review.json"),
            requested=issues, max_ratio=args.max_ratio, source_path=args.transcript,
            initial_prompt=args.prompt_file.read_text(encoding="utf-8") if args.prompt_file else payload.get("initial_prompt"),
            phase_callback=lambda message: print(message, flush=True))
        print(json.dumps(result["summary"], ensure_ascii=False))
    finally:
        if model is not None:
            engine.unload_model(model)


if __name__ == "__main__":
    main()
