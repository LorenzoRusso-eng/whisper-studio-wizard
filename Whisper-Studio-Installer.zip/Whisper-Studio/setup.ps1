param(
    [string]$PythonCommand = "",
    [switch]$CheckOnly
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $ProjectRoot

function Invoke-NativeChecked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed (exit code $LASTEXITCODE): $Executable $($Arguments -join ' ')"
    }
}

function Resolve-PythonCommand {
    param([string]$PreferredCommand)
    $candidates = @()
    if ($PreferredCommand) {
        if ($PreferredCommand -match '^py\s+(-3\.(11|12|13))$') {
            $candidates += [pscustomobject]@{ Executable = 'py'; Arguments = @($Matches[1]) }
        } else {
            $candidates += [pscustomobject]@{ Executable = $PreferredCommand; Arguments = @() }
        }
    } else {
        foreach ($selector in @('-3.13', '-3.12', '-3.11')) {
            $candidates += [pscustomobject]@{ Executable = 'py'; Arguments = @($selector) }
        }
        $candidates += [pscustomobject]@{ Executable = 'python'; Arguments = @() }
    }
    foreach ($candidate in $candidates) {
        try {
            $candidateArguments = @($candidate.Arguments)
            & $candidate.Executable @candidateArguments -c 'import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] <= (3,13) and sys.maxsize > 2**32 else 1)' 2>$null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        } catch { }
    }
    throw 'A 64-bit Python 3.11, 3.12 or 3.13 installation was not found.'
}

try {
    $VenvPython = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $VenvPython)) {
        if ($CheckOnly) { throw 'Virtual environment missing. Run setup.ps1 without -CheckOnly.' }
        $pythonSpec = Resolve-PythonCommand -PreferredCommand $PythonCommand
        $venvArguments = @($pythonSpec.Arguments) + @('-m', 'venv', '.venv')
        Invoke-NativeChecked -Executable $pythonSpec.Executable -Arguments $venvArguments
    }
    Invoke-NativeChecked -Executable $VenvPython -Arguments @('-c', 'import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] <= (3,13) and sys.maxsize > 2**32 else 1)')
    if (-not $CheckOnly) {
        Invoke-NativeChecked -Executable $VenvPython -Arguments @('-m', 'pip', 'install', '-r', 'requirements.txt')
    }
    Invoke-NativeChecked -Executable $VenvPython -Arguments @('-m', 'pip', 'check')
    Invoke-NativeChecked -Executable $VenvPython -Arguments @('-B', '-c', "import tkinter, transcribe, job_queue, lecture_pipeline, lecture_ui, pypdf, pypdfium2, PIL, resvg_py; root=tkinter.Tk(); root.withdraw(); root.destroy(); print('Python, Tkinter, PDF and lecture pipeline dependencies: OK')")
    Write-Host 'Setup verified. Open the app with .\open-audio-selector.bat'
} catch {
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
}
